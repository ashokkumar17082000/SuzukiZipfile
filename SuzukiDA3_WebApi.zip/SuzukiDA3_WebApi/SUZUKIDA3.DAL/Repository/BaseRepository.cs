﻿using Microsoft.EntityFrameworkCore;
using NLog.LayoutRenderers;
using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.DAL.Repository
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        
        private ApplicationDbContext _dbContext;
        private readonly DbSet<T> _dbSet;

        public BaseRepository(ApplicationDbContext context)
        {
            _dbContext = context;
            _dbSet = _dbContext.Set<T>();

        }

        public async virtual Task Add(T entity)
        {
           await _dbSet.AddAsync(entity);
        }

        public async Task<IEnumerable<T>> GetAll()
        {
            return await _dbContext.Set<T>().ToListAsync();
        }


        public async Task<T> GetById(int id)
        {
            return await _dbSet.FindAsync(id);
        }

        public async Task Remove(T entity)
        {
            _dbSet.Remove(entity);
        }

        public async Task Update(T entity)
        {
            _dbSet.Update(entity);
        }

    }
}
