﻿using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.DAL.Repository
{
    public class SoftwareUpdateRepository : BaseRepository<SoftwareUpdate>, ISoftwareUpdate
    {

        private ApplicationDbContext _dbcontext;

        public SoftwareUpdateRepository(ApplicationDbContext dbcontext):base(dbcontext) 
        {
            _dbcontext = dbcontext;
        }

    }
}
