﻿using Microsoft.EntityFrameworkCore;
using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.DAL.Repository
{
    public class TempLoginRepository : BaseRepository<TempLogin>, ITempLogin
    {
        private ApplicationDbContext _dbContext;
        public TempLoginRepository(ApplicationDbContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<bool> ValidateUserIdAsync(string userId)
        {
            var item =  await _dbContext.TempLoginDbSet.FirstOrDefaultAsync(x => x.UserId.ToLower() == userId.ToLower());
           if (item != null)
            {
                return true;
            }
            return false;
        }

        public async Task<TempLogin> findItem(string userId)
        {
            return await _dbContext.TempLoginDbSet.FirstOrDefaultAsync(x => x.UserId.ToLower() == userId.ToLower());
        }
    }
}
