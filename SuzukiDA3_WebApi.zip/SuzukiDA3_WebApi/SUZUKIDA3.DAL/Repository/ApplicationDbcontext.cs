﻿using Microsoft.EntityFrameworkCore;
using SUZUKIDA3.DAL.Data;
using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.CommonModels;
using SUZUKIDA3.Model.DataModel;
using System.Reflection;

namespace SUZUKIDA3.DAL.Repository;

public partial class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }
    public virtual DbSet<NLogTable> NLogsTable { get; set; }
   

    public virtual DbSet<TempLogin> TempLoginDbSet { get; set; }



    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.ApplyConfiguration(new TempLoginSeed());

        base.OnModelCreating(modelBuilder);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {

        base.OnConfiguring(optionsBuilder);
    }

    public override int SaveChanges()
    {
        UpdateModifiedDates();
        return base.SaveChanges();
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        UpdateModifiedDates();
        return base.SaveChangesAsync(cancellationToken);
    }


    private void UpdateModifiedDates()
    {
        var modifiedEntries = ChangeTracker.Entries()
            .Where(e => e.State == EntityState.Modified);

        foreach (var entry in modifiedEntries)
        {
            if (HasProperty(entry.Entity, "ModifiedAt"))
            {
                if (entry.Entity is EntityBase row)
                {
                    row.ModifiedAt = DateTime.UtcNow;
                }
            }
        }
    }


    private static bool HasProperty(object obj, string propertyName)
    {
        // Use reflection to get the type of the object
        Type type = obj.GetType();

        // Check if the type has the specified property
        PropertyInfo property = type.GetProperty(propertyName);

        return property != null;
    }



}
