﻿using Azure.Data.Tables;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.CommonModels;

namespace SUZUKIDA3.DAL.Repository
{
    public class AzureTableBaseRepository<T> : IAzureTableRepository<T> where T : class
    {
        private readonly IConfiguration _configuration;
        public AzureTableBaseRepository(IConfiguration configuration)
        {
            _configuration = configuration;

        }

        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_USERCODE]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        public async Task<bool> AddAsync(T entity)
        {
            TableClient tableClient = await this.GetTableClient();
            //tableClient.AddEntity(entity);
            // var response = await tableClient.AddEntityAsync(entity);
            //return !response.isError;
            throw new NotImplementedException();
        }

        public async Task<bool> DeleteAsync(string partitionKey, string rowKey)
        {
            var item = GetAsync(partitionKey, rowKey);
            if (item == null)
            {
                return false;
            }

            TableClient tableClient = await this.GetTableClient();
            var response = await tableClient.DeleteEntityAsync(partitionKey, rowKey);
            return !response.IsError;
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            TableClient tableClient = await this.GetTableClient();
            throw new NotImplementedException();
        }

        public async Task<T> GetAsync(string partitionKey, string rowKey)
        {
            TableClient tableClient = await this.GetTableClient();
            IList<T> Items = new List<T>();
            var tableItems = tableClient.QueryAsync<AzureTableEntityBase>(x => x.PartitionKey == partitionKey && x.RowKey == rowKey);
            await foreach (var itm in tableItems)
            {
                Items.Add(itm as T);

            }
            return Items.FirstOrDefault();
        }

        public async Task<IEnumerable<T>> GetByPartitionKeyAsync(string partitionKey)
        {
            TableClient tableClient = await this.GetTableClient();
            throw new NotImplementedException();
        }

        public async Task UpdateAsync(T entity)
        {
            TableClient tableClient = await this.GetTableClient();
            throw new NotImplementedException();
        }
    }
}
