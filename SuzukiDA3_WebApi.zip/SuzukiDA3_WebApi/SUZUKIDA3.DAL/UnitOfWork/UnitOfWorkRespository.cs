﻿using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Interfaces.Repository;
using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.DAL.Repository;
using Microsoft.EntityFrameworkCore;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.DAL.UnitOfWork
{
    public class UnitOfWorkRespository : IUnitOfWorkRepository

    {
        private readonly ApplicationDbContext _dbContext;
        private ISoftwareUpdate _softwareUpdate;
        private ITempLogin _tempLogin;


        ISoftwareUpdate IUnitOfWorkRepository.SoftwareUpdate { get { return _softwareUpdate ?? new SoftwareUpdateRepository(_dbContext); } }

        ITempLogin IUnitOfWorkRepository.TempLogin { get { return _tempLogin ?? new TempLoginRepository(_dbContext); } }

        public UnitOfWorkRespository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public int Save()
        {
            return _dbContext.SaveChanges();

        }
        public async void SaveAsync()
        {
            await _dbContext.SaveChangesAsync();
        }

    }
}
