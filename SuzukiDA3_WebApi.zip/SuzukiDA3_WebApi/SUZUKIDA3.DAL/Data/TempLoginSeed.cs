﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SUZUKIDA3.Model.DataModel;


namespace SUZUKIDA3.DAL.Data
{
    internal class TempLoginSeed : IEntityTypeConfiguration<TempLogin>
    {
        public void Configure(EntityTypeBuilder<TempLogin> builder)
        {
            builder.HasData(GetTempLoginData());
        }

        private static TempLogin[] GetTempLoginData()
        {


            TempLogin[] TempIds = [
                            new TempLogin { Id = 1, UserId = "123456" },
                            new TempLogin { Id = 2, UserId = "123457" },
                            new TempLogin { Id = 3, UserId = "456789" }

                        ];
            return TempIds;
        }
    }
}
