﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IZipEncryptionHelper
    {
        Task<Stream> EncryptZipContents(Stream stream);
    }
}
