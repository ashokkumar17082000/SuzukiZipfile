﻿using Microsoft.AspNetCore.Http;
using SUZUKIDA3.Model.Dto.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IAzureBlobStorage
    {
        Task<BlobResponseDto> UploadAsync(IFormFile file);
        Task<BlobDto> DownloadAsync(string blobFilename);

        Task<BlobResponseDto> DeleteAsync(string blobFilename);


        Task<List<BlobDto>> ListAsync();

        Task<List<BlobDto>> ListFileFromFolder(string folderName);

        Task<BlobResponseDto> UploadToAsync(IFormFile file, string? Folder);
        Task<string> UploadZipFromUrlAsync(string sourceUrl, string containerName, string blobName, string connectionString);
        Task<BlobResponseDto> SoftwareUpdate(IFormFile file);
    }
}
