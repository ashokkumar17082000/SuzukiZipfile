﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IMtlsCertifcateValidator
    {
        X509Certificate2 GetClientCertificate();
        bool IsClientCertificateValid(X509Certificate2 certificate);
        bool ValidateCertificate(HttpRequestMessage httpRequestMessage, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors);
        bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors);

    }
}
