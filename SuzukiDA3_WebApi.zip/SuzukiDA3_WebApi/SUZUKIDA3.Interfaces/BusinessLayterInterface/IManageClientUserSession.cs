﻿using SUZUKIDA3.Model.Dto.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IManageClientUserSession
    {
        string getClientSessionID();
        void setClientSessionId(string clientSessionID);

        List<KeyValuePair<string, string>> getCredentials();

        HttpClient CreateHttpClient();

        void handle_MTLS_validation(bool begin);
        ClientAccessReqDto GetClientConnectData();

        string getFileNameFromContentDisposition(System.Net.Http.Headers.ContentDispositionHeaderValue contentDisposition);
    }
}
