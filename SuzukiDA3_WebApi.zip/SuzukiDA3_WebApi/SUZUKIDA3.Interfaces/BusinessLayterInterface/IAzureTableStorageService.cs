﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IAzureTableStorageService<T> where T : class
    {
        Task<T> GetAsync(string partitionKey, string rowKey);
        Task<IEnumerable<T>> GetAllAsync();
        Task<IEnumerable<T>> GetByPartitionKeyAsync(string partitionKey);
        Task AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task DeleteAsync(string partitionKey, string rowKey);
    }
}
