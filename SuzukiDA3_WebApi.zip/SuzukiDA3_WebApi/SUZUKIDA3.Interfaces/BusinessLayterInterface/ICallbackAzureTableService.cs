﻿using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface ICallbackAzureTableService
    {
        Task<bool> AddCallbackResponse( CallbackResponse callbackResponse,string id,string errorMessage);
        Task<bool> AddLogsData(string module, string id, string status, string logs);
        Task<bool> AddSessionValidation(string EmailId, string AuthInstant, string SessionKey);
        Task<AzureTableSession> GetSessionResponse(string emailId, string sessionKey);
        Task<AzureTableCallback> GetCallbackResponse(string UserCode);
        Task<AzureTableCallbackError> GetCallbackError(string status, string errorKey);
        public Task<bool> UpdateCallbackresponse(string id, string InventoryDescription, string CallBackReceivedFromHarman, string DownloadStartFromHarman, string Environment, string UploadToBlob);

    }
}
