﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IAsymetricCryptographicService
    {
        Task<Stream> EncryptFile(IFormFile file);

        Task<Stream> DecryptFile(IFormFile file);

        Task<byte[]> EncryptStream(Stream mStream);
    }
}
