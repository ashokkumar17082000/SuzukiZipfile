﻿using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IUserCodeValidationAzureTableService
    {
        Task<AzureTableUserCode?> GetUser( string usercode);
        Task<List<AzureTableUserCode>> GetAllUser();
        Task<List<AzureTableUserCode>> GetByPartitionKey();
        Task<bool> AddUser(string UserCode);
        Task<bool> UpdateUser(string oldUserCode, string UserCode);
        Task<bool> DeleteUser(string userCode);
        Task<bool> SendMail(string ToMail, string upperTemplate, string lowerTemplate, string fromMail,string mailSubject, string connectionStringACS);
    }
}
