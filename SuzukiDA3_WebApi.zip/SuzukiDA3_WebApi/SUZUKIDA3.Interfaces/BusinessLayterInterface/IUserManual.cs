﻿using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IUserManual
    {
        Task<List<AzureTableUserManual>> GetUserManualList();
        Task<List<AzureTableUserManualCountry>> GetCountryList();
        Task<List<AzureTableUserManualList>> GetUserManualDataList();
        Task<List<AzureTableUserManualCountryModel>> GetCountryModelList(int destinationId, int countryId);
        Task<List<AzureTableUserManualModel>> GetModelCodeList(int destinationId, string[] modelCode);
        Task<List<AzureTableUserManualDestination>> GetUserManualDataList(int userManualId, int destinationId);
    }
}
