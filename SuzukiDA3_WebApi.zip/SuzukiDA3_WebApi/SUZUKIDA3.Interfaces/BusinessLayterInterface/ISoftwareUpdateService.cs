﻿using Microsoft.AspNetCore.Http;
using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface ISoftwareUpdateService : IGenericServiceBL<SoftwareUpdate>
    {
        //Task<bool> CheckSoftwareUpdateExists(IFormFile file);
        //Task<Stream> DownloadLatestSoftware(IFormFile file);
        //Task<bool> ReportUpdate(IFormFile file);
    }
}
