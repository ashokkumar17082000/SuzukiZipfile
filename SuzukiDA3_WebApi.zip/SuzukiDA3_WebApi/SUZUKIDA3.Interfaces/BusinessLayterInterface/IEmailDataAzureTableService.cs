﻿using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.BusinessLayterInterface
{
    public interface IEmailDataAzureTableService
    {
        //Task<bool> AddEmail();
        Task<AzureTableEmail> GetEmailData(string memberName);
        Task<AzureTableEmail> GetEmailList(string memberValue);
    }
}
