﻿using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Interfaces.DataLayerInterface;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.Repository
{
    public interface IUnitOfWorkRepository
    {
        ISoftwareUpdate SoftwareUpdate { get; }
        ITempLogin TempLogin { get; }
        int Save();
        void SaveAsync();
    }
}
