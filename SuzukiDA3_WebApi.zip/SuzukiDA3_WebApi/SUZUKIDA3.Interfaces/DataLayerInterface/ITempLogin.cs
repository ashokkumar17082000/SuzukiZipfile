﻿using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.Interfaces.DataLayerInterface
{
    public interface ITempLogin : IBaseRepository<TempLogin>
    {
        Task<bool> ValidateUserIdAsync(string userId);

        Task<TempLogin> findItem(string userId);
    }
}
