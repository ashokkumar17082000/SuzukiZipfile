﻿using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.Interfaces.DataLayerInterface
{
    public interface ISoftwareUpdate : IBaseRepository<SoftwareUpdate>
    {
    
     
    }
}
