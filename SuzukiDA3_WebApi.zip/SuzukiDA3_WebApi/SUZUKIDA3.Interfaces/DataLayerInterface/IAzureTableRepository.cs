﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces.DataLayerInterface
{
    public interface IAzureTableRepository <T> where T : class
    {
        Task<T> GetAsync(string partitionKey, string rowKey);
        Task<IEnumerable<T>> GetAllAsync();
        Task<IEnumerable<T>> GetByPartitionKeyAsync(string partitionKey);
        Task<bool> AddAsync(T entity);
        Task UpdateAsync(T entity);
        Task<bool> DeleteAsync(string partitionKey, string rowKey);
    }
}
