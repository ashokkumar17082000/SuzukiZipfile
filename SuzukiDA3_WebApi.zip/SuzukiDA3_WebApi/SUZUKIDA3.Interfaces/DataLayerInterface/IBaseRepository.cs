﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SUZUKIDA3.Model.CommonModels;
using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.Interfaces.DataLayerInterface
{
    public interface IBaseRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAll();
        Task <T> GetById(int id);
        Task Add(T entity);
        Task Update(T entity);
        Task Remove(T entity);
    }
    
}
