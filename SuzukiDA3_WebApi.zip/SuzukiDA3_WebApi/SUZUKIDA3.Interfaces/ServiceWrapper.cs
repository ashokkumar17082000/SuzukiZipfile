﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Interfaces
{
    public class ServiceWrapper<H, B>
    {
        /// <summary>
        /// The packet
        /// </summary>
        private Response<H, B> Response = new Response<H, B>();
        public Response<H, B> response
        {
            get { return Response; }
            set { Response = value; }
        }

    }

    /// <summary>
    /// Class Response.
    /// </summary>
    /// <typeparam name="H">The Header</typeparam>
    /// <typeparam name="B">The Body</typeparam>
    /// 
    public class Response<H, B>
    {
        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>The header.</value>
        public H Header { get; set; }

        /// <summary>
        /// Gets or sets the body.
        /// </summary>
        /// <value>The body.</value>
        public B Body { get; set; }
        public Response()
        {
        }
    }

    /// <summary>
    /// Class Header.
    /// </summary>
    /// 
    public class Header
    {
        /// <summary>
        /// Gets or sets the response code.
        /// </summary>
        /// <value>The response code.</value>
        public string? ResponseCode { get; set; }

        public string? ResponseMessage { get; set; }
        /// <summary>
        /// More info on Error, mostly required to developer
        /// </summary>
        public string? Details { get; set; } = string.Empty;

    }

}
