﻿using AutoMapper;
using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.Model.Dto;

namespace SUZUKIDA3.WebApi.Mapper
{
    public class AutoMapper : Profile
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapper"/> class.
        /// </summary>
        public AutoMapper()
        {
            CreateMap<TempLogin, TempLoginReqDto>().ReverseMap();
        }
    }
}
