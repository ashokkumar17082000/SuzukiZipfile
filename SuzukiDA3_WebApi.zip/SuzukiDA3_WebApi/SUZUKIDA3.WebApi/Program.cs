using NLog;
using NLog.Fluent;
using SUZUKIDA3.WebApi.Helpers;
using System.Text.Json.Serialization;
using NLog.Web;
using Microsoft.OpenApi.Models;
using EnvironmentName = Microsoft.Extensions.Hosting.EnvironmentName;
using Microsoft.Extensions.Logging;
using SUZUKIDA3.Common.Constants;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Sustainsys.Saml2;
using Sustainsys.Saml2.AspNetCore2;
using Sustainsys.Saml2.Metadata;
using Sustainsys.Saml2.WebSso;

namespace SUZUKIDA3.WebApi
{
    public class Program
    {

        /// <summary>
        /// Defines the entry point of the api.
        /// </summary>
        /// <param name="args">The arguments.</param>
        public static void Main(string[] args)
        {
            string envToken = Environment.GetEnvironmentVariable(DA3Config.ASPNET_ENVIRONMENT_WORKING);
            bool isProd = (!string.IsNullOrWhiteSpace(envToken) && envToken == EnvironmentName.Production) ? true : false;
            var logger = LogManager.Setup().LoadConfigurationFromFile(string.Concat(Directory.GetCurrentDirectory(), isProd ? "./nlog.config" : "./nlog.debug.config")).GetCurrentClassLogger();
            try
            {
                logger.Debug("Suzuki DA 3 Project initiated main !!! ");
                var builder = WebApplication.CreateBuilder(args);
                builder.Services.AddAuthentication(options =>
                {
                    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = Saml2Defaults.Scheme;
                })
                .AddCookie()
                .AddSaml2(options =>
                {
                    options.SPOptions.EntityId = new EntityId("https://bosch.UAT.com/sp");
                   
                    options.IdentityProviders.Add(new IdentityProvider(
                        new EntityId("https://auth.bizapps.suzuki/saml/idp/sso"), options.SPOptions)
                    {
                        MetadataLocation = Environment.CurrentDirectory+@"\DA3WebPortal-IDP-metadata.xml",
                        LoadMetadata = true,
                        AllowUnsolicitedAuthnResponse = true, // Allow POST-based responses
                        Binding = Saml2BindingType.HttpPost // Ensure POST binding is supported
                    });
                })
                .AddJwtBearer(options =>
                {
                    options.Authority = "https://auth.bizapps.suzuki/saml/idp/sso";  // Set your identity provider or issuer here
                    options.Audience = "bosch-api"; // Set your audience
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("YourSecretKeyHere")) // Use a secure key
                    };
                });
                // Add services to the container.

                builder.Services.AddAuthorization();

                builder.Services.AddControllers().AddJsonOptions(x =>
                    x.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles);

                builder.Services.AddEndpointsApiExplorer();
                builder.Services.AddAutoMapper(typeof(Program));
                builder.Services.AddDIServices(builder.Configuration);
                builder.Logging.ClearProviders();
                builder.Logging.AddConsole();
                builder.Logging.SetMinimumLevel
                                (Microsoft.Extensions.Logging.LogLevel.Trace);
                builder.Host.UseNLog();
                builder.Services.AddHttpClient();
                builder.Services.AddSwaggerGen(options =>
                {
                    options.CustomSchemaIds(type => type.ToString());
                });

                var app = builder.Build();

                // Configure the HTTP request pipeline.
                if (app.Environment.IsDevelopment())
                {
                    app.UseSwagger();
                    app.UseSwaggerUI(c => { });
                }
                else
                {
                    // remove in production
                    app.UseSwagger();
                    app.UseSwaggerUI(c => { });

                    app.UseHsts();
                    app.UseHttpsRedirection();
                }


                // change for production 
                //app.UseCors("AllowEverything");
                app.UseCors(DA3Constants.DA3_SITE_ORIGIN_TITLE);
                //app.UseCors("AllowStaticWebAppSuzukiDA3SiteOriginOnly-DEV");

                app.UseMiddleware<ErrorHandlerMiddleware>();
                //app.UseIpWhitelist();
                //Enable if Authentication is used.
                // app.UseAuthentication();
                app.UseAuthentication();
                app.UseAuthorization();
                app.MapControllers();
                app.Run();
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                LogManager.Shutdown();
            }

        }
    }
}
