﻿using kedzior.io.ConnectionStringConverter;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Azure;
using Microsoft.IdentityModel.Tokens;
using NLog;
using SUZUKIDA3.BAL.BusinessService;
using SUZUKIDA3.BAL.Helper;
using SUZUKIDA3.BAL.Implementation;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.DAL.Repository;
//using SUZUKIDA3.DAL.UnitOfWork;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Interfaces.Repository;
using System.Reflection;
using System.Text;

namespace SUZUKIDA3.WebApi.Helpers
{
    /// <summary>
    ///  service extension class
    /// </summary>
    public static class ServiceExtentions
    {
        /// <summary>
        /// Adds the di services.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <param name="configuration">The configuration.</param>
        /// <returns></returns>
        /// <exception cref="SUZUKIDA3.Model.DataModel.NLogTable.Exception">AKV Uri not configured.</exception>
        public static IServiceCollection AddDIServices(this IServiceCollection services, IConfiguration configuration)
        {
            //LogManager.Configuration.Variables[DA3Config.NLOG_DBCONNECTION_VAR_NAME] = configuration.GetValue<string>(DA3Config.DBConnectionString);
            services.AddMemoryCache();
            services.AddAutoMapper(Assembly.GetExecutingAssembly());
            ConfigurationHelper.Initilize(configuration);
            string AKVPath = configuration.GetValue<string>(DA3Config.AkvVariable);
            string CROSS_ORIGIN_PATH = configuration.GetValue<string>(DA3Constants.DA3_SITE_ORIGIN_ONLY_FOR_CROSS_ORIGIN_VAR);
            string OTA_BASE_PATH = configuration.GetValue<string>(DA3Constants.ClientBaseURIKey);

            if (Uri.TryCreate(AKVPath, UriKind.Absolute, out Uri uri))
            {
                services.AddAzureClients(azureClientFactoryBuilder =>
                {
                    azureClientFactoryBuilder.AddSecretClient(uri);
                });
            }
            else
            {
                throw new Exception("AKV Uri not configured.");
            }
            services.AddLogging(builder =>
            {
                builder.AddConsole(); // Add console logging
            });
            var handler = new HttpClientHandler
            {
                MaxConnectionsPerServer = 10000,
            };
            services.AddHttpClient(DA3Constants.DA3_HTTP_CLIENT_NAME, client =>
            {
                //client = ClientHttpConnectionService.Instance;
                if (OTA_BASE_PATH != null)
                {
                    client.BaseAddress = new Uri(OTA_BASE_PATH);
                }
                client.Timeout = TimeSpan.FromMinutes(60);
                client.MaxResponseContentBufferSize = int.MaxValue;
            });


            services.AddSingleton<IKeyVaultManager, KeyVaultManager>();
            services.AddScoped<IMtlsCertifcateValidator, MtlsCertificateValidator>();
            services.AddScoped<IAsymetricCryptographicService, AsymetricEncryptionService>();
            services.AddScoped<IManageClientUserSession, ManageClientUserSession>();
            services.AddScoped<IZipEncryptionHelper, ZipEncryptionService>();
            services.AddScoped<IUserCodeValidationAzureTableService, UserCodeValidationService>();
            services.AddScoped<IEmailDataAzureTableService, EmailDataService>();
            services.AddScoped<ILanguageDataAzureTableService, LanguageDataService>();
            services.AddScoped<IModelList, ModelDataService>();
            services.AddScoped<IDCManufacturerDataAzureTableService, DCManufacturerDataService>();
            services.AddScoped<IUserManual,UserManualDataService>();
            services.AddScoped<IAzureBlobStorage, AzureStorageService>();
            services.AddScoped<IDeviceDataAzureTableService, DeviceDataService>();
            services.AddScoped<IOSDataAzureTableService, OSDataService>();
            services.AddScoped<IDeviceOSFeatureAzureTableService, DeviceOSFeatureDataService>();
            services.AddScoped<ICertificateDataAzureTableService, CertificateDataService>();
            services.AddScoped<IOssDataAzureTableService,OssDataService>();
            services.AddScoped<IFaqDataAzureTableService, FaqDataService>();
            services.AddScoped<ICallbackAzureTableService, CallbackService>();
            services.AddScoped<IAdminUserValidationAzureTableService, AdminUserValidationService>();
            services.AddScoped<IReleaseNotes, ReleaseNotesDataService>();

            services.AddCors(options =>
            {
                if (string.IsNullOrWhiteSpace(CROSS_ORIGIN_PATH))
                {
                    options.AddPolicy(DA3Constants.DA3_SITE_ORIGIN_TITLE,
                        builder =>
                        {
                            builder.AllowAnyOrigin()
                                .AllowAnyHeader()
                                .AllowAnyMethod().WithExposedHeaders("Content-Disposition");
                        });
                }
                else
                {
                    options.AddPolicy(DA3Constants.DA3_SITE_ORIGIN_TITLE,
                        builder =>
                        {
                            builder.WithOrigins(CROSS_ORIGIN_PATH)
                                        .AllowAnyHeader()
                                        .AllowAnyMethod()
                                        .AllowCredentials().WithExposedHeaders("Content-Disposition");
                        });
                }
            });
            return services;
        }
    }
}
