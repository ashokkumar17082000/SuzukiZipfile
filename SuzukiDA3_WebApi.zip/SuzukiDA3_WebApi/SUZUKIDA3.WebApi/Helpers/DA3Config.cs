﻿namespace SUZUKIDA3.WebApi.Helpers
{
    /// <summary>
    /// DA3 Config helper class
    /// </summary>
    internal static class DA3Config
    {
        internal const string DBConnectionString = "DBCONNECTION";
        internal const string AppSettingsFileName = "appsettings.json";
        internal const string StartingProjectName = "SUZUKIDA3.WebApi";
        internal const string AkvVariable = "AZURE_KEYVAULT_RESOURCEENDPOINT";
        internal const string AuthSecretKey = "AuthAccountsKey";
        internal const string CERT_PASSWORD = "CertificatePassword";
        internal const string Cert_path = "CertificatePath";
        internal const string ASPNET_ENVIRONMENT_WORKING = "ASPNETCORE_ENVIRONMENT";
        internal const string CERT_PATH = "C:\\Hari\\Projects\\SUZUKIDA3\\MTLS test\\Certificates\\client-cert.pfx";
        internal const string MYSQL_DATABASE = "MYSQLCONNSTR_localdb";
        internal const string NLOG_DBCONNECTION_VAR_NAME = "myConnectionstring";
        internal const string Azure_MY_SQL_CONNECTION_VARIABLE = "MYSQLCONNSTR_localdb";
    }
}
