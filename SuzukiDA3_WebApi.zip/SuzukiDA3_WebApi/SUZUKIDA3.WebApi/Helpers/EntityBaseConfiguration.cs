﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SUZUKIDA3.Model.CommonModels;

namespace SUZUKIDA3.WebApi.Helpers
{
    /// <summary>
    /// EntityBaseConfiguration class
    /// </summary>
    /// <typeparam name="TEntity">The type of the entity.</typeparam>
    /// <seealso cref="Microsoft.EntityFrameworkCore.IEntityTypeConfiguration&lt;TEntity&gt;" />
    public abstract class EntityBaseConfiguration<TEntity> : IEntityTypeConfiguration<TEntity>
        where TEntity : EntityBase
    {
        /// <summary>
        /// Configures the entity of type <typeparamref name="TEntity" />.
        /// </summary>
        /// <param name="builder">The builder to be used to configure the entity type.</param>
        public void Configure(EntityTypeBuilder<TEntity> builder)
        {
            builder.HasKey(p =>  p.RefId);
            builder.Property(p => p.CreatedAt).IsRequired(false);
            builder.Property(p => p.ModifiedAt).IsRequired(false);
            builder.Property(p => p.EntityStatus).IsRequired(false);
            ConfigureEntity(builder);
        }

        public abstract void ConfigureEntity(EntityTypeBuilder<TEntity> builder);
    }
}
