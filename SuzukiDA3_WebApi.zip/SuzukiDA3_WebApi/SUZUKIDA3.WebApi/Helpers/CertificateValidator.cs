﻿using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace SUZUKIDA3.WebApi.Helpers
{
    /// <summary>
    /// Certificate validation helper
    /// </summary>
    /// <seealso cref="SUZUKIDA3.Interfaces.BusinessLayterInterface.IMtlsCertifcateValidator" />
    public class CertificateValidator : IMtlsCertifcateValidator
    {
        #region Private Fields
        private readonly ILogger<CertificateValidator> _logger;
        private readonly IConfiguration _configuration;
        #endregion

        
        /// <summary>
        /// Initializes a new instance of the <see cref="CertificateValidator"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="configuration">The configuration.</param>
        public CertificateValidator(ILogger<CertificateValidator> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }
        #region Public Methods
        /// <summary>
        /// Gets the client certificate.
        /// </summary>
        /// <returns></returns>
        public X509Certificate2 GetClientCertificate()
        {

            X509Certificate2 clientcertifcate = new X509Certificate2(DA3Config.CERT_PATH, _configuration.GetValue<string>(DA3Config.CERT_PASSWORD));
            bool isCertifcateValid = IsClientCertificateValid(clientcertifcate);
            if (!isCertifcateValid) return null;

            return clientcertifcate;
        }

        /// <summary>
        /// Determines whether [is client certificate valid] [the specified certificate].
        /// </summary>
        /// <param name="certificate">The certificate.</param>
        /// <returns>
        ///   <c>true</c> if [is client certificate valid] [the specified certificate]; otherwise, <c>false</c>.
        /// </returns>
        public bool IsClientCertificateValid(X509Certificate2 certificate)
        {
            if (certificate == null)
            {
                return false;
            }
            if (certificate.NotAfter < DateTime.UtcNow)
            {
                return false;
            }



            return true;
        }

        /// <summary>
        /// Validates the certificate.
        /// </summary>
        /// <param name="httpRequestMessage">The HTTP request message.</param>
        /// <param name="certificate">The certificate.</param>
        /// <param name="chain">The chain.</param>
        /// <param name="sslPolicyErrors">The SSL policy errors.</param>
        /// <returns></returns>
        public bool ValidateCertificate(HttpRequestMessage httpRequestMessage, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {

            if (certificate == null)
            {
                return false;
            }
            if (certificate.Issuer == "")
            {
                return false;
            }

            var allowedThumbprints = _configuration.GetSection("Certificates").Get<Dictionary<string, string>>();

            if (allowedThumbprints.Count == 0)
            {
                _logger.LogInformation("No Certificates Present.");
                return false;
            }

            if (!allowedThumbprints.Values.Contains(certificate.GetPublicKeyString()))
            {
                _logger.LogInformation("InValid");
                return false;
            }
            _logger.LogInformation("Certificate is Valid");
            return true;

        }


        /// <summary>
        /// Validates the server certificate.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="certificate">The certificate.</param>
        /// <param name="chain">The chain.</param>
        /// <param name="sslPolicyErrors">The SSL policy errors.</param>
        /// <returns></returns>
        public bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (certificate == null)
            {
                return false;
            }
            if (certificate.Issuer == "")
            {
                return false;
            }

            var allowedThumbprints = _configuration.GetSection("Certificates").Get<Dictionary<string, string>>();

            if (allowedThumbprints.Count == 0)
            {
                _logger.LogInformation("No Certificates Present.");
                return false;
            }

            if (!allowedThumbprints.Values.Contains(certificate.GetPublicKeyString()))
            {
                _logger.LogInformation("InValid");
                return false;
            }
            _logger.LogInformation("Certificate is Valid");
            return true;

        }
        #endregion
    }
}
