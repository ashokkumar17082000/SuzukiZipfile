﻿using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Helpers
{
    /// <summary>
    /// ClientHttpConnectionService helper class
    /// </summary>
    public class ClientHttpConnectionService
    {
        private readonly IManageClientUserSession _managedClientSession;
        private readonly IConfiguration _config;
        public ClientHttpConnectionService(IManageClientUserSession _managedClient, IConfiguration config)
        {
            _managedClientSession = _managedClient;
            _config = config;
        }
        private static readonly Lazy<HttpClient> httpClient = new Lazy<HttpClient>(() => CreateHttpClient());

        public static HttpClient Instance => httpClient.Value;


        public static HttpClient CreateHttpClient()
        {
            //string base_url = _config.GetValue<string>(DA3Contatns.ClientBaseURIKey);
            var handler = new HttpClientHandler
            {
                MaxConnectionsPerServer = 10000,
            };
            HttpClient client;
            client = new HttpClient(handler);
            //client.BaseAddress = new Uri(base_url);
            client.Timeout = TimeSpan.FromMinutes(60);
            client.MaxResponseContentBufferSize = int.MaxValue;
            return client;
        }
    }
}
