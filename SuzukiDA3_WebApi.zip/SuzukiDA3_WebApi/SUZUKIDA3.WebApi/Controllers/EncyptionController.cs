﻿//using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using System.Text.Json;
using SUZUKIDA3.Common.Helpers;
namespace SUZUKIDA3.WebApi.Controllers
{

    /// <summary>
    /// Controller for Encryption and decryption
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class EncryptionController : ControllerBase
    {
        #region Private Fields
        private readonly IAsymetricCryptographicService _encryptionHelper;
        private readonly ILogger<SoftwareUpdateController> _logger;
       // private readonly IMapper _mapper;
        private readonly IManageClientUserSession _userClientSession;
        private bool IsMTLSRequired = false;
        private string clientAPIbaseUrl = string.Empty;
        private string clientExternalStorageUrl = string.Empty;

        #endregion
        public EncryptionController(IAsymetricCryptographicService encryptionHelper, ILogger<SoftwareUpdateController> logger, IManageClientUserSession userClientSession)
        {
            _encryptionHelper = encryptionHelper;
            _logger = logger;
            //_mapper = mapper;
            _userClientSession = userClientSession;
        }

        [HttpPost(nameof(EncryptFile))]
        public async Task<ActionResult> EncryptFile(IFormFile file)
        {
            if (file == null)
            {
                return BadRequest("File is required!");
            }
            var stream = await _encryptionHelper.EncryptFile(file);

            if (stream != null && stream.Length > 0)
            {
                string fileName = "Encrypted_" + file.FileName;
                Response.Headers.Add("Content-Disposition", "attachment; filename=" + fileName);
                Response.Headers.Add("Content-Type", "application/octet-stream");
                await stream.CopyToAsync(Response.Body);
                return new EmptyResult();
            }
            else
            {
                return BadRequest("InValid File!");
            }
        }

        #region Public Methods
        /// <summary>
        /// Decrypts the file.
        /// </summary>
        /// <param name="file">The file.</param>
        /// <returns></returns>
        [HttpPost(nameof(DecryptFile))]
        public async Task<ActionResult> DecryptFile(IFormFile file)
        {
            if (file == null)
            {
                return BadRequest("File is required!");
            }
            var stream = await _encryptionHelper.DecryptFile(file);
            if (stream != null && stream.Length > 0)
            {
                string fileName = "Decrypted_" + file.FileName;
                Response.Headers.Add("Content-Disposition", "attachment; filename=" + fileName);
                Response.Headers.Add("Content-Type", "application/octet-stream");
                await stream.CopyToAsync(Response.Body);
                return new EmptyResult();
            }
            else
            {
                return BadRequest("InValid File!");
            }

        }

        /// <summary>
        /// Softwares the update with decrypt file.
        /// </summary>
        /// <param name="file">The file.</param>
        /// <returns></returns>
        [HttpPost(nameof(SoftwareUpdateWithDecryptFile))]
        public async Task<IActionResult> SoftwareUpdateWithDecryptFile(IFormFile file)
        {
            if (file == null)
            {
                return BadRequest("Inventory file is required.");
            }

            string sessionID = string.Empty;
            string pakcageID = string.Empty;
            string loginUrl = clientAPIbaseUrl + "api/login";
            string check_for_update_url = clientExternalStorageUrl + "createPackageByInventory";
            string software_download_url = clientExternalStorageUrl;

            try
            {

                if (IsMTLSRequired)
                {
                    _userClientSession.handle_MTLS_validation(true);
                }

                using (HttpClient client = _userClientSession.CreateHttpClient())
                {
                    client.Timeout = TimeSpan.FromMinutes(25);
                    sessionID = _userClientSession.getClientSessionID();

                    if (string.IsNullOrWhiteSpace(sessionID))
                    {
                        //get login credentials
                        var creds = _userClientSession.getCredentials();
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        using (HttpResponseMessage login_response = await client.PostAsync(loginUrl, new FormUrlEncodedContent(creds)))
                        {
                            if (login_response.IsSuccessStatusCode)
                            {
                                string jsonResponse = await login_response.Content.ReadAsStringAsync();
                                LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);
                                sessionID = loginResponse?.sessionId;
                                if (!string.IsNullOrWhiteSpace(sessionID))
                                    _userClientSession.setClientSessionId(sessionID);
                            }
                        }
                    }
                    if (sessionID == string.Empty)
                    {
                        return BadRequest("Failed!");
                    }
                    Stream decrypted_file_stream = await _encryptionHelper.DecryptFile(file);

                    var formData = new MultipartFormDataContent();

                    StreamContent streamcontent = new StreamContent(decrypted_file_stream);
                    formData.Add(streamcontent, "file", file.FileName);



                    client.DefaultRequestHeaders.Add("sessionId", sessionID);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    using (HttpResponseMessage update_check_response = await client.PostAsync(check_for_update_url, formData))
                    {
                        if (update_check_response.IsSuccessStatusCode)
                        {
                            string jsonResponse = await update_check_response.Content.ReadAsStringAsync();
                            var packageUpdateResponse = JsonSerializer.Deserialize<SoftwareUpdatePackageResDto>(jsonResponse);
                            pakcageID = packageUpdateResponse?.id;
                        }
                    }

                    if (pakcageID == string.Empty)
                    {
                        return Ok("Update Not avaialble for your Infotainment Package.");
                    }
                    int package_ready_counter = 0;

                    do
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.Add("sessionId", sessionID);
                        package_ready_counter++;
                        using (HttpResponseMessage response_download_ready = await client.GetAsync(software_download_url + pakcageID))
                        {
                            if (response_download_ready.IsSuccessStatusCode)
                            {
                                string jsonResponse = await response_download_ready.Content.ReadAsStringAsync();
                                PackageDownloadReadyResponseObject packageAvailableResponse = JsonSerializer.Deserialize<PackageDownloadReadyResponseObject>(jsonResponse);
                                if (packageAvailableResponse != null && packageAvailableResponse.status == "SUCCESS")
                                { package_ready_counter = 100; }
                                else if (packageAvailableResponse != null && packageAvailableResponse.status == "FAILED")
                                {
                                    package_ready_counter = 100;
                                    return Ok("Software Update is not available.");


                                }
                                else
                                {
                                    Task.Delay(TimeSpan.FromSeconds(2)).Wait();
                                }
                            }
                            else
                            {
                                Task.Delay(TimeSpan.FromSeconds(2)).Wait();
                            }
                        }
                    } while (package_ready_counter < 15);
                    software_download_url += string.Format("{0}/download", pakcageID);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("sessionId", sessionID);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    using (HttpResponseMessage download_response = await client.GetAsync(software_download_url, HttpCompletionOption.ResponseHeadersRead))
                    {
                        if (download_response.IsSuccessStatusCode)
                        {
                            Response.Headers.Add("Content-Disposition", "attachment; filename=SUZUKI_Updated_Software.zip");
                            Response.Headers.Add("Content-Type", "application/octet-stream");
                            await download_response.Content.CopyToAsync(Response.Body);
                            return new EmptyResult();
                        }
                    }
                    return BadRequest("Software Download failed.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("software report failed.", ex.Message);
                return BadRequest(ex.Message);
            }
            finally
            {
                if (IsMTLSRequired)
                {
                    _userClientSession.handle_MTLS_validation(false);
                }
            }
        }
        #endregion
    }

}
