﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.Model.Dto;

namespace SUZUKIDA3.WebApi.Controllers
{

    public class TempLoginController : BaseController
    {
        private readonly ILogger<TempLoginController> _logger;
        private readonly IMapper _mapper;
        private IBusinesServiceUnit _uow;
        public TempLoginController(IBusinesServiceUnit uow, ILogger<TempLoginController> logger, IMapper mapper)
        {
            _uow = uow;
            _logger = logger;
            _mapper = mapper;
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<IActionResult> GetAllEntries()
        {
            try
            {
                var result = await this._uow.TempLoginService.GetAll();
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> AddItem(TempLoginReqDto TempLoginData)
        {
            try
            {
                var result = await this._uow.TempLoginService.Add(_mapper.Map<TempLogin>(TempLoginData));
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpGet("{userId}")]
        public async Task<IActionResult> ValidateItem(string userId)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(userId))
                {
                    var result = await this._uow.TempLoginService.ValidateUserIdServiceAsync(userId);
                    return Ok(result);
                }
                return BadRequest("Failed");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }
        }


    }
}
