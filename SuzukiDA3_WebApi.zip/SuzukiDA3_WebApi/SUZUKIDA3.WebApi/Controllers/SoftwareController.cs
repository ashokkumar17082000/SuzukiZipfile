﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System.Runtime.Serialization.Json;
using System.Text.Json;
using System.Net.Http.Headers;
using SUZUKIDA3.Common.Helpers;
using System.Text;
using SUZUKIDA3.Model.DataModel;
namespace SUZUKIDA3.WebApi.Controllers
{

    public class SoftwareController : BaseController
    {
        private readonly ILogger<SoftwareController> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IAsymetricCryptographicService _encryptionDecryptionService;
        private readonly IManageClientUserSession _userClientSession;
        private readonly IZipEncryptionHelper _zipEncryptionService;
        private readonly ICallbackAzureTableService _callbackAzureTableService;
        public SoftwareController(ILogger<SoftwareController> logger, IHttpClientFactory httpClientFactory, ICallbackAzureTableService callbackAzureTableService, IAsymetricCryptographicService encryptionDecryptionService, IManageClientUserSession userClientSession, IZipEncryptionHelper zipEncryptionService)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _encryptionDecryptionService = encryptionDecryptionService;
            _userClientSession = userClientSession;
            _zipEncryptionService = zipEncryptionService;
            _callbackAzureTableService= callbackAzureTableService;
        }

        [AllowAnonymous]
        [HttpPost(nameof(DownloadUpdate))]
        public async Task<IActionResult> DownloadUpdate(string packageID)
        {
            try
            {
                using (HttpClient client = _httpClientFactory.CreateClient(DA3Constants.DA3_HTTP_CLIENT_NAME))
                {
                    string sessionID = await handleAuthentiocationSessionID(client);
                    if (sessionID == string.Empty)
                    {
                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:Not able to login to OTA CLIENT : ");
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.ServerAuthFail, Message = "Internal Server Error!" });
                    }
                    bool isPackageAvailable = await PackageReadyforDownload(client, packageID);
                    if (!isPackageAvailable)
                    {
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Software Update is not available." });
                    }

                    updateClientHeaders(client, sessionID);
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, string.Format(DA3Constants.DA3_CLIENT_API_DOWNLOADSOFTWARE, packageID));
                    using (HttpResponseMessage fileDownloadResponse = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).ConfigureAwait(true))
                    {
                        _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:" + fileDownloadResponse.IsSuccessStatusCode);
                        if (fileDownloadResponse.IsSuccessStatusCode)
                        {
                            var datastream = await fileDownloadResponse.Content.ReadAsStreamAsync();
                            _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:Started:");
                            string contentType = fileDownloadResponse.Content?.Headers.ContentType?.MediaType?.ToString();

                            if (string.IsNullOrEmpty(contentType))
                            {
                                contentType = "application/octet-stream";
                            }
                            ContentDispositionHeaderValue contentDisposition = fileDownloadResponse.Content?.Headers?.ContentDisposition;
                            string fileName = contentDisposition != null ? _userClientSession.getFileNameFromContentDisposition(contentDisposition) : "SoftwareUpdate.zip";

                            _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:" + fileDownloadResponse.Content?.Headers.ToString());
                            Response.Headers.Add("Content-Type", contentType);
                            Response.Headers.Add("Content-Disposition", $"attachment; filename={fileName}");
                            Response.Headers.Add("FileName", fileName);
                            await datastream.CopyToAsync(Response.Body);
                            await Response.Body.FlushAsync();
                            await Response.CompleteAsync();
                            _logger.LogInformation(string.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: COMPLETED: FOR PACKAGEID: {0}, FileName: {1}", packageID, fileName));
                            datastream.Close();
                            return new EmptyResult();
                        }
                        else
                        {
                            _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response STATUS CODE: {0}", fileDownloadResponse.StatusCode), "");
                            _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response Reason Parse: {0}", fileDownloadResponse.ReasonPhrase), "");
                            string errorContent = await fileDownloadResponse.Content.ReadAsStringAsync();
                            _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response Reason Parse:{0}", errorContent), "");
                            return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.DownloadFailed, Message = "SOFTWARE REQUEST RESPONSE DOWNLOAD." + errorContent });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("software report failed.", ex.Message);
                return BadRequest(ex.Message);
            }
            finally
            {
                //if (IsMTLSRequired)
                //{
                //    _userClientSession.handle_MTLS_validation(false);
                //}
            }
        }


        [AllowAnonymous]
        [HttpPost(nameof(CheckSoftwareUpdateAvailable))]
        public async Task<IActionResult> CheckSoftwareUpdateAvailable(IFormFile file)
        {
            string pakcageID = string.Empty;

            if (file == null)
            {
                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FileNotFound, Message = "File should be uploaded." });
            }

            try
            {
                _logger.LogInformation("SOFTWARE UPDATE PAGE Info:Request available update for file: " + file.Name);
                Stream decrypted_file_stream = await _encryptionDecryptionService.DecryptFile(file);
                if (decrypted_file_stream == null)
                {
                    _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:File Decryption failed : " + file.Name);
                    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.CorruptedFile, Message = "InValid file format." });
                }
                using (HttpClient client = _httpClientFactory.CreateClient(DA3Constants.DA3_HTTP_CLIENT_NAME))
                {
                    string sessionID = await handleAuthentiocationSessionID(client);
                    if (sessionID == string.Empty)
                    {
                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:Not able to login to OTA CLIENT : ");
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.ServerAuthFail, Message = "Internal Server Error!" });
                    }
                    var formData = new MultipartFormDataContent();
                    StreamContent streamcontent = new StreamContent(decrypted_file_stream);
                    formData.Add(streamcontent, "file", file.FileName);
                    updateClientHeaders(client, sessionID);
                    using (HttpResponseMessage update_check_response = await client.PostAsync(DA3Constants.DA3_CLIENT_API_CREATEPACKAGE, formData))
                    {
                        if (update_check_response.IsSuccessStatusCode)
                        {
                            string jsonResponse = await update_check_response.Content.ReadAsStringAsync();
                            var packageUpdateResponse = JsonSerializer.Deserialize<SoftwareUpdatePackageResDto>(jsonResponse);
                            pakcageID = packageUpdateResponse?.id;
                        }
                        else
                        {
                            _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:Not able to login to OTA CLIENT : ");
                            return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
                        }
                    }
                    if (pakcageID == string.Empty || pakcageID == null)
                    {
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
                    }
                    bool isPackageAvailable = await PackageReadyforDownload(client, pakcageID);
                    if (isPackageAvailable)
                    {
                        var response = new PackageAvailbilityResponse() { PackageID = pakcageID };
                        return Ok(response);
                    }
                    else
                    {
                        NotFound(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to authenticate to client Server.", ex.Message);
                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FetchCredentialsFailed, Message = "Failed client Authentication!" });
            }

            return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
        }


        [AllowAnonymous]
        [HttpPost]
        [Route("callback")]
        public async Task<IActionResult> callback(Guid Id, [FromBody] CallbackResponse callbackResponse)//string str)
        {
            try
            {
                string requestBody;
                string errorMessage = null;
                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestBody = await reader.ReadToEndAsync();

                }
                _logger.LogInformation("Starting callback");
                _logger.LogInformation("Unique Id received is :" + Id.ToString());
                // _logger.LogInformation($"{requestBody}");

                var downURL = callbackResponse.downloadFileUrl;
                _logger.LogInformation("DownURL is : " + downURL);
                if (callbackResponse.errorKey != null && callbackResponse.status != null)
                    errorMessage = await CallbackError(callbackResponse.errorKey, callbackResponse.status);
                var callbackSaved = await CreateCallBackResponse(callbackResponse, Id.ToString(), errorMessage);
                if (callbackSaved == true)
                    _logger.LogInformation("Callback Saved Successfully - " + Id.ToString());
                else
                    _logger.LogInformation("Saving of Callback failed.");
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Api");
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }

        }
        [NonAction]
        public async Task<bool> CreateCallBackResponse(CallbackResponse callbackResponse, string id, string errorMessage)
        {
            try
            {
                if (callbackResponse == null)
                { return false; }
                var response = await _callbackAzureTableService.AddCallbackResponse(callbackResponse, id, errorMessage);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Save");
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }
        [NonAction]
        public async Task<AzureTableCallback> GetCallBackResponse(string id)
        {
            try
            {
                if (id == null)
                { return null; }
                var response = await _callbackAzureTableService.GetCallbackResponse(id);
                if (response == null)
                    return null;
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Fetch");
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }
        [NonAction]
        public async Task<string> CallbackError(string errorKey, string status)
        {
            try
            {

                var response = await _callbackAzureTableService.GetCallbackError(status, errorKey);
                if (response != null)
                    return response.UserErrorMessage;
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Error ");
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }

        private async Task<bool> PackageReadyforDownload(HttpClient client, string packageID)
        {
            bool isPackageAvailabforDownload = false;
            int package_ready_counter = 0;
            string sessionID = await handleAuthentiocationSessionID(client);
            do
            {
                updateClientHeaders(client, sessionID);
                package_ready_counter++;
                using (HttpResponseMessage response_download_ready = await client.GetAsync(string.Format(DA3Constants.DA3_CLIENT_API_UPDATEAVAIALBE, packageID)))
                {
                    if (response_download_ready.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response_download_ready.Content.ReadAsStringAsync();
                        PackageDownloadReadyResponseObject packageAvailableResponse = JsonSerializer.Deserialize<PackageDownloadReadyResponseObject>(jsonResponse);
                        if (packageAvailableResponse != null && packageAvailableResponse.status == "SUCCESS")
                        {
                            package_ready_counter = 200;
                            isPackageAvailabforDownload = true;
                            _logger.LogInformation("SOFTWARE DOWNLOAD PAGE:Sucessfully Completed packaging in OTA Server: Package Status: " + packageAvailableResponse.status);
                        }
                        else if (packageAvailableResponse != null && packageAvailableResponse.status == "FAILED")
                        {
                            _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Failed while packaging in OTA Server: Package Status: " + packageAvailableResponse.status);
                            package_ready_counter = 200;

                        }
                        else
                        {
                            _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Waiting for package Avaialblity:" + packageAvailableResponse?.status);
                            Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                        }
                    }
                    else
                    {
                        Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                    }
                }
            } while (package_ready_counter < 120);


            return isPackageAvailabforDownload;

        }
        private async Task<string?> handleAuthentiocationSessionID(HttpClient client)
        {
            string sessionID = string.Empty;
            sessionID = _userClientSession.getClientSessionID();
            if (string.IsNullOrWhiteSpace(sessionID))
            {
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                try
                {
                    var creds = _userClientSession.getCredentials();
                    if (creds == null)
                    {
                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:handleAuthentiocationSessionID: NOT ABLE TO FETCH CREDENTIALS.");
                    }
                    else
                    {
                        using (HttpResponseMessage login_response = await client.PostAsync(DA3Constants.DA3_CLIENT_API_LOGIN, new FormUrlEncodedContent(creds)))
                        {
                            if (login_response.IsSuccessStatusCode)
                            {
                                string jsonResponse = await login_response.Content.ReadAsStringAsync();
                                LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);
                                sessionID = loginResponse?.sessionId;
                                if (!string.IsNullOrWhiteSpace(sessionID))
                                    _userClientSession.setClientSessionId(sessionID);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError("SOFTWARE UPDATE PAGE: ERROR WHILE AUTHENTICATING TO CLIENT API " + ex.Message.ToString(), ex);
                }
            }
            return sessionID;
        }
        private void updateClientHeaders(HttpClient client, string? sessionID)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            if (!string.IsNullOrEmpty(sessionID))
            {
                client.DefaultRequestHeaders.Add("sessionId", sessionID);
            }
        }


    }

    class PackageAvailbilityResponse
    {
        public string? PackageID { get; set; }

    }
}
