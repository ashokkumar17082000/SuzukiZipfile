﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System.Runtime;
using System.Runtime.Serialization.Json;
using System.Text.Json;
using SUZUKIDA3.Common.Helpers;
using System.Net.Http.Headers;
using Newtonsoft.Json.Converters;
using AutoMapper;
using System.Net;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
using System.Xml;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Text.Json.Nodes;
using System.Net.Http;
using SUZUKIDA3.Model.DataModel;
using Castle.Components.DictionaryAdapter.Xml;
using System.IO.Compression;
using Azure.Storage.Blobs;
using static System.Net.WebRequestMethods;
using System;
using Azure.Storage.Blobs.Models;
using Azure.Storage;
using Polly;
using Polly.Retry;
using Azure.Storage.Blobs.Specialized;
using Microsoft.AspNetCore.Authentication;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Linq.Expressions;
using Azure.Data.Tables;
using System.Security.Cryptography;


namespace SUZUKIDA3.WebApi.Controllers

{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : BaseController
    {
        private readonly string encryptionKey = "Your32CharSecretKeyForAESFSM1COB"; // Must be exactly 32 characters
        private readonly ICallbackAzureTableService _callbackAzureTableService;
        CallbackResponse response = new CallbackResponse();
        public AuthController(ICallbackAzureTableService callbackAzureTableService)
        {
            _callbackAzureTableService = callbackAzureTableService;
        }

        [HttpGet("login")]
        public async Task<IActionResult> LoginAsync()
        {
            try
            {
                response.downloadFileUrl = "Inside login of auth/api";
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                ChallengeResult result = Challenge(new AuthenticationProperties { RedirectUri = "/api/auth/callback" }, "Saml2");
                response.downloadFileUrl = "Inside login of auth/api-Challenge Done";
                Guid guid2 = Guid.NewGuid();
                bool status2 = await CreateCallBackResponse(response, guid2.ToString(), "");
                return result;

            }
            catch (Exception ex)
            {
                response.downloadFileUrl = "catch block of auth/api " + ex.Message;
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                return BadRequest(ex.Message);
            }

        }
        //[HttpPost("callback")]
        //public IActionResult Callback()
        //{
        //    var result = HttpContext.AuthenticateAsync().Result;

        //    if (!result.Succeeded)
        //    {
        //        return Unauthorized("SAML authentication failed.");
        //    }

        //    // Extract user claims from the SAML response
        //    var claims = result.Principal?.Identities.FirstOrDefault()?.Claims;

        //    return Ok(new { Message = "SAML authentication successful", Claims = claims });
        //}

        [Authorize]
        [HttpGet("callbackOLD")]
        public async Task<IActionResult> CallbackAsyncOld()
        {
            try
            {
                // Extract user claims from the SAML response
                response.downloadFileUrl = "Inside Callback - Before claims";
                Guid guid2 = Guid.NewGuid();
                bool status2 = await CreateCallBackResponse(response, guid2.ToString(), "");
                var claims = User.Claims.Select(c => new { c.Type, c.Value }).ToList();
                string claimsValue = String.Empty;
                foreach (var claim in claims)
                {

                    claimsValue += claim.ToString();
                }
                response.downloadFileUrl = "Inside Callback - " + claimsValue;
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                // Generate JWT token
                //var tokenHandler = new JwtSecurityTokenHandler();
                //var key = Encoding.ASCII.GetBytes("YourSecretKeyHere"); // Use a secure key
                //var tokenDescriptor = new SecurityTokenDescriptor
                //{
                //    Subject = new ClaimsIdentity((System.Security.Principal.IIdentity?)claims),
                //    Expires = DateTime.UtcNow.AddHours(1), // Token expiration time
                //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                //};

                //var token = tokenHandler.CreateToken(tokenDescriptor);
                //var tokenString = tokenHandler.WriteToken(token);

                // Return the JWT token as part of the response
                return Ok(new { Message = "Authenticated", Claims = claims });
            }
            catch (Exception ex)
            {
                response.downloadFileUrl += ex.Message;
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                return BadRequest(ex.Message);
            }

        }



        [HttpGet("callback")]
        public async Task<IActionResult> CallbackAsync()
        {
            try
            {
                response.downloadFileUrl = "Inside Callback - Before claims";
                var claims = User.Claims.ToList();
                
                // Log all claims for debugging (remove in production)
                foreach (var claim in claims)
                {
                    Console.WriteLine($"Claim Type: {claim.Type}, Value: {claim.Value}");
                }
                response.downloadFileUrl += "Inside Callback - After claims";
                // Extract values dynamically by checking available claims
                var emailClaim = claims.FirstOrDefault(c => c.Type.Contains("nameidentifier", StringComparison.OrdinalIgnoreCase));
                var authInstantClaim = claims.FirstOrDefault(c => c.Type.Contains("authenticationinstant", StringComparison.OrdinalIgnoreCase));

                string email = emailClaim?.Value;
                string authInstant = authInstantClaim?.Value;
                response.downloadFileUrl += "Inside Callback - Email - "+email;


                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(authInstant))
                    return BadRequest("Invalid SAML response: Missing required claims.");

                // Create a unique session key
                string sessionKey = $"{email}_{authInstant}";
                string encryptedKey = Encrypt(sessionKey);
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                // Save session in Azure Table Storage

                var createSession = CreateSessionValidation(email, authInstant, encryptedKey);
                
                // Redirect user back to Angular with the encrypted session key
                //  string angularRedirectUrl = $"https://brave-island-00bc34710.4.azurestaticapps.net/dealer/dealer-home?token={Uri.EscapeDataString(encryptedKey)}";
                string angularRedirectUrl = $"https://www.suzuki-infotainment-system.com/dealer/dealer-home?token={Uri.EscapeDataString(encryptedKey)}";
                return Redirect(angularRedirectUrl);
            }

            catch (Exception ex)
            {
                response.downloadFileUrl = "catch block of auth/CallbackAPI " + ex.Message;
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                return BadRequest(ex.Message);
            }
        }

        [NonAction]
        public async Task<bool> CreateSessionValidation(string EmailId, string AuthInstant, string SessionKey)
        {
            try
            {
                var response = await _callbackAzureTableService.AddSessionValidation(EmailId, AuthInstant, SessionKey);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        /// <summary>
        /// Validate session from Angular
        /// </summary>

        [AllowAnonymous]
        [HttpPost("validate-session")]
        public async Task<IActionResult> ValidateSession([FromBody] SessionValidationRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.EncryptedKey))
                    return BadRequest("Invalid session key");

                // Decrypt session key
                string decryptedKey = Decrypt(request.EncryptedKey);
                string[] parts = decryptedKey.Split('_');

                if (parts.Length != 2)
                    return Unauthorized("Invalid session format");

                string email = parts[0];
                string authInstant = parts[1];

                var fetchSession = GetSessionResponse(email, request.EncryptedKey);
                // Fetch session details from Azure Table Storage safely
                //  var sessionEntity = await _tableClient.Query<TableEntity>(e => e.PartitionKey == email && e.RowKey == "UserSession").FirstOrDefaultAsync();

                if (fetchSession == null)
                    return Unauthorized("Session not found");
                else
                    return Ok(new { Status = "Valid", Email = fetchSession.Result.EmailId });

                //string storedKey = sessionEntity["SessionKey"].ToString();
                //if (storedKey != decryptedKey)
                //    return Unauthorized("Invalid session");

                //DateTime createdAt = DateTime.Parse(sessionEntity["CreatedAt"].ToString());

                // Validate session expiration (30 minutes expiry)
                //                if (DateTime.UtcNow - createdAt > TimeSpan.FromMinutes(30))
                //                  return Unauthorized("Session expired");


            }
            catch (Exception ex)
            {
                return Unauthorized(new { Status = "Invalid", Error = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpGet("EncryptNew")]
        public string EncryptNew(string plainText)
        {
            return this.Encrypt(plainText);
        }
        /// <summary>
        /// AES Encryption
        /// </summary>
        /// 
        [NonAction]
        private string Encrypt(string plainText)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(encryptionKey);

                // Generate a random IV
                aes.GenerateIV();
                byte[] iv = aes.IV;

                using (var encryptor = aes.CreateEncryptor(aes.Key, iv))
                {
                    byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                    byte[] encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                    // Combine IV and encrypted data
                    byte[] combined = new byte[iv.Length + encryptedBytes.Length];
                    Array.Copy(iv, 0, combined, 0, iv.Length);
                    Array.Copy(encryptedBytes, 0, combined, iv.Length, encryptedBytes.Length);

                    return Convert.ToBase64String(combined);
                }
            }
        }

        /// <summary>
        /// AES Decryption
        /// </summary>
        /// 
        [NonAction]
        private string Decrypt(string encryptedText)
        {
            byte[] combined = Convert.FromBase64String(encryptedText);

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(encryptionKey);

                // Extract IV and encrypted data
                byte[] iv = new byte[16];
                byte[] encryptedBytes = new byte[combined.Length - iv.Length];

                Array.Copy(combined, 0, iv, 0, iv.Length);
                Array.Copy(combined, iv.Length, encryptedBytes, 0, encryptedBytes.Length);

                using (var decryptor = aes.CreateDecryptor(aes.Key, iv))
                {
                    byte[] decryptedBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
        }
        [NonAction]
        public async Task<AzureTableSession> GetSessionResponse(string emailId, string sessionKey)
        {
            try
            {
                var response = await _callbackAzureTableService.GetSessionResponse(emailId, sessionKey);
                if (response == null)
                    return null;
                return response;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        

        [HttpGet("logout")]
        public async Task<IActionResult> LogoutAsync()
        {
            try
            {
                response.downloadFileUrl = "Inside logout.";
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                return SignOut(new AuthenticationProperties { RedirectUri = "/" }, "Cookies", "Saml2");
            }
            catch (Exception ex)
            {
                response.downloadFileUrl += ex.Message;
                Guid guid = Guid.NewGuid();
                bool status = await CreateCallBackResponse(response, guid.ToString(), "");
                return BadRequest(ex.Message);
            }

        }
        [NonAction]
        public static string ClaimsToString(IEnumerable<Claim>? claims)
        {
            if (claims == null || !claims.Any())
            {
                return "No claims available.";
            }

            return string.Join(Environment.NewLine, claims.Select(c => $"{c.Type}: {c.Value}"));
        }
        [NonAction]
        public async Task<bool> CreateCallBackResponse(CallbackResponse callbackResponse, string id, string errorMessage)
        {
            try
            {
                if (callbackResponse == null)
                { return false; }
                var response = await _callbackAzureTableService.AddCallbackResponse(callbackResponse, id, errorMessage);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {

                return false;
            }
        }
    }
    public class SessionValidationRequest
    {
        public string EncryptedKey { get; set; }
    }
}
