﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class FaqController : BaseController
    {
        private readonly IFaqDataAzureTableService _faqService;

        public FaqController(IFaqDataAzureTableService faqService)
        {
            _faqService = faqService;

        }
        [AllowAnonymous]
        [HttpGet(nameof(GetFaq))]
        public async Task<IActionResult> GetFaq(string languageCode)
        {
            var response = await _faqService.GetFaqData(languageCode);
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetDetail))]
        public async Task<IActionResult> GetDetail(string languageCode, string urlReference)
        {
            var response = await _faqService.GetAndroidAutoData(languageCode,urlReference);
            return Ok(response);
        }

    }
}
