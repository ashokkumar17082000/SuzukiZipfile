﻿using Azure.Storage.Blobs;
using Azure.Storage;
using Castle.Components.DictionaryAdapter.Xml;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.IO.Compression;
using System.Net;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class ModelController : BaseController
    {
        private readonly IModelList _ModelService;
        private readonly IUserManual _UserManual;
        private readonly ILogger<ModelController> _Logger;
        private readonly IAzureBlobStorage _AzureBlobStorage;
        private readonly IConfiguration _configuration;
        private readonly string _storageAccountName = "sda3container";
        private readonly string _containerName = "sda3container";
        private readonly string _storageAccountKey = "vODcQojfFruUfH/ipE+N11+sU3IjQhNwBTLRqVnRbd+i6rPxpjwHT52ZvWGmgfkQ3W4MoR0uw6iw+ASt3Ih4lQ==";

        public ModelController(IModelList modelService,IUserManual userManual, ILogger<ModelController> logger, IAzureBlobStorage azureBlobStorage)
        {
            _ModelService = modelService;
            _UserManual = userManual;
            _Logger = logger;
            _AzureBlobStorage = azureBlobStorage;
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllModelCode))]
        public async Task<IActionResult> GetAllModelCode()
        {
            var response = await _ModelService.GetModelList();
            //_Logger.LogInformation("Download of file from Harman triggered at " + DateTime.Now.ToString());
            //IFormFile fsd = DownloadFile();
            //_Logger.LogInformation("Download of file from Harman Completed at " + DateTime.Now.ToString());
            //_Logger.LogInformation("Upload of file to Blob triggered at " + DateTime.Now.ToString());
            //await _AzureBlobStorage.UploadAsync(fsd);
            //_Logger.LogInformation("Upload of file to Blob Completed at " + DateTime.Now.ToString());
           
            return Ok(response);
        }

        [AllowAnonymous]
        [HttpGet(nameof(DownloadFileByUrl))]
        public async Task<IActionResult> DownloadFileByUrl(string url)
        {

            _Logger.LogInformation("Download of file from Harman triggered at " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff"));
            IFormFile fsd = DownloadFileUrl(url);
            _Logger.LogInformation("Download of file from Harman Completed at " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff"));
            using (ZipArchive zip = ZipFile.Open(fsd.FileName, ZipArchiveMode.Read))
                foreach (ZipArchiveEntry entry in zip.Entries)
                    if (entry.Name.Contains("dc"))
                        entry.ExtractToFile("myfile");
            _Logger.LogInformation("Upload of file to Blob triggered at " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff"));
            var response=await _AzureBlobStorage.UploadAsync(fsd);
            _Logger.LogInformation("Upload of file to Blob Completed at " + DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff"));

            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllUserManual))]
        public async Task<IActionResult> GetAllUserManual()
        {
            var response = await _UserManual.GetUserManualList();
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetCountryList))]
        public async Task<IActionResult> GetCountryList()
        {
            var response = await _UserManual.GetCountryList();
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetUserManualDataList))]
        public async Task<IActionResult> GetUserManualDataList()
        {
            var response = await _UserManual.GetUserManualDataList();
            return Ok(response);
        }


        [HttpGet("download")]
        public async Task<IActionResult> Download(string fileName)
        {
            var blobServiceClient = new BlobServiceClient(
                new Uri($"https://{_storageAccountName}.blob.core.windows.net"),
                new StorageSharedKeyCredential(_storageAccountName, _storageAccountKey));

            var containerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = containerClient.GetBlobClient($"UserManualsNew/{fileName}");

            if (!await blobClient.ExistsAsync())
            {
                return NotFound("File not found in Blob Storage.");
            }

            var response = await blobClient.DownloadStreamingAsync();

            // Ensure stream is at position 0
            var stream = response.Value.Content;
            if (stream.CanSeek)
                stream.Seek(0, SeekOrigin.Begin);

            // Use actual content type if possible
            var contentType = "application/pdf"; // Change based on file type

            return File(stream, contentType, fileName);
        }

        [AllowAnonymous]
        [HttpGet(nameof(GetModelCodeByCountry))]
        public async Task<IActionResult> GetModelCodeByCountry(int DestinationId, int CountryId)
        {
            var response = await _UserManual.GetCountryModelList(DestinationId, CountryId);
            var finalResponse = new List<Model.DataModel.AzureTableUserManualModel>();
            var counter = 0;
            if (response.Count > 0)
            {
                string[] strings = new string[response.Count];
                foreach (var item in response)
                {
                    strings[counter] = item.ModelCode; counter++;
                }
                var response2 = await _UserManual.GetModelCodeList(DestinationId, strings);
                finalResponse = response2;
            }
            return Ok(finalResponse);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetUserManualData))]
        public async Task<IActionResult> GetUserManualData(int userManualId, int destinationId)
        {
            var response = await _UserManual.GetUserManualDataList(userManualId, destinationId);
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpPost(nameof(UploadFile))]
        public async Task<IActionResult> UploadFile(IFormFile fs)
        {

            var response = await _AzureBlobStorage.UploadAsync(fs);
            return Ok(response);
        }

        public static IFormFile DownloadFileUrl(string url)
        {

            using (var client = new HttpClient())
            {
                using (var s = client.GetStreamAsync(url))
                {
                    string fileName = "localFile_" + Guid.NewGuid().ToString() + ".zip";
                    using (var fs = new FileStream(fileName, FileMode.OpenOrCreate))
                    {
                        s.Result.CopyTo(fs);

                        var file = new FormFile(fs, 0, fs.Length, fileName, fs.Name);
                        return file;

                    }

                }
            }

            //return Ok();
        }
    }
}
