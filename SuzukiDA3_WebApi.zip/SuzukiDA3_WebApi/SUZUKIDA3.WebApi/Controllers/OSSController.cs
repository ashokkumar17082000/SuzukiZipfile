﻿using Castle.Components.DictionaryAdapter.Xml;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.Net;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class OSSController : BaseController
    {
        private readonly IOssDataAzureTableService _ossService;

        public OSSController(IOssDataAzureTableService ossService)
        {
            _ossService = ossService;

        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllOssFiles))]
        public async Task<IActionResult> GetAllOssFiles()
        {
            var response = await _ossService.GetOssData();
            return Ok(response);
        }
    }
}
