﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Controllers
{
    /// <summary>
    /// Controller for user code validation
    /// </summary>
    /// <seealso cref="SUZUKIDA3.WebApi.Controllers.BaseController" />
    public class UserCodeValidationController : BaseController
    {
        private readonly IUserCodeValidationAzureTableService _azureValidationCodeService;
        private readonly IEmailDataAzureTableService _emailDataService;

        public UserCodeValidationController(IUserCodeValidationAzureTableService azureValidationService, IEmailDataAzureTableService emailDataAzureTableService)
        {
            _azureValidationCodeService = azureValidationService;
            _emailDataService = emailDataAzureTableService;

        }

        /// <summary>
        /// Validates the user code.
        /// </summary>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet("{userCode}")]
        public async Task<IActionResult> ValidateUserCode(string userCode)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(userCode))
                {
                    var response = await _azureValidationCodeService.GetUser(userCode);
                    return (response == null ? Ok(false) : Ok(response.ValidationCode == userCode));
                }
                else { return BadRequest("Failed!"); }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Gets all user code.
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet(nameof(GetAllUserCode))]
        public async Task<IActionResult> GetAllUserCode()
        {
            var response = await _azureValidationCodeService.GetByPartitionKey();
            return Ok(response);
        }

        /// <summary>
        /// Gets the user code.
        /// </summary>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet(nameof(GetUserCode))]
        public async Task<IActionResult> GetUserCode(string userCode)
        {
            var response = await _azureValidationCodeService.GetUser(userCode);
            if (response == null)
            {
                return BadRequest("Failed !");
            }
            return Ok(response);
        }

        /// <summary>
        /// Updates the user code.
        /// </summary>
        /// <param name="oldcode">The oldcode.</param>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPatch(nameof(UpdateUserCode))]
        public async Task<IActionResult> UpdateUserCode(string oldcode, string userCode)
        {
            if (string.IsNullOrWhiteSpace(userCode) || string.IsNullOrWhiteSpace(oldcode))
            { return BadRequest(false); }
            var response = await _azureValidationCodeService.UpdateUser(oldcode, userCode);
            if (response == false)
            {
                return BadRequest(response);
            }
            return Ok(response);
        }

        /// <summary>
        /// Creates the user code.
        /// </summary>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> CreateUserCode(string userCode)
        {
            if (string.IsNullOrWhiteSpace(userCode))
            { return BadRequest(false); }
            var response = await _azureValidationCodeService.AddUser(userCode);
            if (response == false)
                return BadRequest(response);
            return Ok(response);
        }

        /// <summary>
        /// Deletes the user code.
        /// </summary>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpDelete(nameof(DeleteUserCode))]
        public async Task<IActionResult> DeleteUserCode(string userCode)
        {
            if (string.IsNullOrWhiteSpace(userCode))
            { return BadRequest(false); }
            var response = await _azureValidationCodeService.DeleteUser(userCode);
            if (response == false)
            {
                return BadRequest(response);
            }
            return Ok(response);
        }

        [AllowAnonymous]
        [HttpPost(nameof(SendMail))]
        public async Task<IActionResult> SendMail(string ToMail)
        {
            //await _emailDataService.AddEmail();
            var response = false;
            var EmailList = await _emailDataService.GetEmailList(ToMail.ToLower());
            if (EmailList == null)
                return BadRequest(response);
            if (string.IsNullOrWhiteSpace(ToMail))
            { return BadRequest(false); }
            var upperTemplate = (await _emailDataService.GetEmailData("EmailTemplateUpper")).MemberValue;
            var lowerTemplate = (await _emailDataService.GetEmailData("EmailTemplateLower")).MemberValue;
            var fromMail = (await _emailDataService.GetEmailData("FromMail")).MemberValue;
            var subject = (await _emailDataService.GetEmailData("Subject")).MemberValue;
            var connectionStringACS = (await _emailDataService.GetEmailData("ConnectionString")).MemberValue;
            if (upperTemplate != null && lowerTemplate != null && fromMail != null && subject != null)
            {
                response = await _azureValidationCodeService.SendMail(ToMail, upperTemplate, lowerTemplate, fromMail, subject, connectionStringACS);
            }
            if (response == false)
                return BadRequest(response);
            return Ok(response);
        }

    }
}