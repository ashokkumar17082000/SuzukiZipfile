﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System.Runtime;
using System.Runtime.Serialization.Json;
using System.Text.Json;
using SUZUKIDA3.Common.Helpers;
using System.Net.Http.Headers;
using Newtonsoft.Json.Converters;
using AutoMapper;
using System.Net;
using System.Text;
using static System.Net.Mime.MediaTypeNames;
using System.Xml;
using Newtonsoft.Json.Linq;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Text.Json.Nodes;
using System.Net.Http;
using SUZUKIDA3.Model.DataModel;
using Castle.Components.DictionaryAdapter.Xml;
using System.IO.Compression;
using Azure.Storage.Blobs;
using static System.Net.WebRequestMethods;
using System;
using Azure.Storage.Blobs.Models;
using Azure.Storage;
using Polly;
using Polly.Retry;
using Azure.Storage.Blobs.Specialized;
using System.Security.Policy;


namespace SUZUKIDA3.WebApi.Controllers

{
    public class UpdateSoftwareController : BaseController

    {

        private readonly ILogger<UpdateSoftwareController> _logger;

        private readonly IHttpClientFactory _httpClientFactory;

        private readonly IAsymetricCryptographicService _encryptionDecryptionService;

        private readonly IManageClientUserSession _userClientSession;
        private readonly HttpClient _httpClient;

        private readonly IZipEncryptionHelper _zipEncryptionService;
        private readonly IMapper _mapper;
        private readonly ICallbackAzureTableService _callbackAzureTableService;
        private readonly IAzureBlobStorage _azureBlobStorage;


        //public List<Dictionary<string, string>> _softwareInfo = new List<Dictionary<string,  string>>();
        public List<SoftwareInfo> softwareInfoList = new List<SoftwareInfo>();



        public UpdateSoftwareController(ILogger<UpdateSoftwareController> logger, IHttpClientFactory httpClientFactory, ICallbackAzureTableService callbackAzureTableService, IAsymetricCryptographicService encryptionDecryptionService, IManageClientUserSession userClientSession, IZipEncryptionHelper zipEncryptionService, IMapper mapper, IAzureBlobStorage azureBlobStorage, HttpClient httpClient)

        {

            _logger = logger;
            _callbackAzureTableService = callbackAzureTableService;
            _httpClientFactory = httpClientFactory;

            _encryptionDecryptionService = encryptionDecryptionService;

            _userClientSession = userClientSession;
            _mapper = mapper;
            _zipEncryptionService = zipEncryptionService;
            _azureBlobStorage = azureBlobStorage;
            _httpClient = httpClient;
        }

        [AllowAnonymous]

        [HttpPost(nameof(CheckSoftwareUpdateAvailable))]

        public async Task<IActionResult> CheckSoftwareUpdateAvailable(IFormFile file)

        {

            string packageID = string.Empty;
            string module = string.Empty;
            string logsData = string.Empty;
            string status=string.Empty;
            string id=string.Empty;
            if (file == null)
            {
                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FileNotFound, Message = "File should be uploaded." });

            }

            try

            {

                _logger.LogInformation("SOFTWARE UPDATE PAGE Info:Request available update for file: " + DateTime.Now.ToString());
                _logger.LogInformation("Decryption Started: " + DateTime.Now.ToString());
                logsData += "File Decryption Started at " + DateTime.Now.ToString();
                Stream decrypted_file_stream = await _encryptionDecryptionService.DecryptFile(file);

                
                //_softwareInfo.Add("deviceID", deviceId);

                _logger.LogInformation("Decryption Ended: " + DateTime.Now.ToString());

                if (decrypted_file_stream == null)
                {
                    _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:File Decryption failed : " + file.FileName);

                    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.CorruptedFile, Message = "InValid file format." });

                }
                else { logsData += ".File Decryption Finished at " + DateTime.Now.ToString(); }
                 id = Guid.NewGuid().ToString();
                _logger.LogInformation("Unique Id generated for callback - " + id);

                using (HttpClient client = _httpClientFactory.CreateClient(DA3Constants.DA3_HTTP_CLIENT_NAME))
                {
                    client.Timeout = TimeSpan.FromMinutes(15);
                    logsData += ".Session requested at " + DateTime.Now.ToString();
                    string sessionID = await handleAuthentiocationSessionID(client);
                    string EnvironmentVal = String.Empty;
                    if (client.BaseAddress.ToString().Contains("test"))
                        EnvironmentVal = "QA";
                    else
                        EnvironmentVal = "Prod";
                    logsData += "Environment - " +EnvironmentVal;
                    _logger.LogInformation("Session Requested at: " + DateTime.Now.ToString());

                    if (sessionID == string.Empty)
                    {

                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:Not able to login to OTA CLIENT : ");

                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.ServerAuthFail, Message = "Internal Server Error!" });

                    }

                    var formData = new MultipartFormDataContent();

                    StreamContent streamcontent = new StreamContent(decrypted_file_stream);


                    formData.Add(streamcontent, "file", file.FileName);

                    updateClientHeaders(client, sessionID);


                    _logger.LogInformation("Checking for Package Available " + DateTime.Now.ToString());

                    _logger.LogInformation("Device Id extraction from Inventory file");
                    logsData += ".Device Id extracted at - " + DateTime.Now.ToString();
                    string deviceId = await GetKeyFromStreamContent(streamcontent, "deviceData.deviceID");
                    _logger.LogInformation("Device Id from inventory file - " + deviceId);
                    string softwareName = string.Empty;
                    string softwareVersion = string.Empty;
                    string downloadUri = string.Empty;
                    string ErrorCodes = string.Empty;
                    string ErrorMessage = string.Empty;
                    string UserErrorMessage = string.Empty;
                    string callbackBasedUrl = DA3Constants.DA3_CLIENT_API_CREATEPACKAGE_With_Callback + id;
                    string softwareData = string.Empty;
                    int callcountattempt = 0;
                    long downloadFileSize = 0;
                    string callBackRequestToHarman = DateTime.Now.ToString();
                    logsData += ".Inventory extracted at - " + DateTime.Now.ToString();
                    string InventoryDescription = await ReadStreamContentAsStringAsync(streamcontent);
                    using (HttpResponseMessage update_check_response = await client.PostAsync(callbackBasedUrl, formData))
                    {
                        _logger.LogInformation("Update_check_response status is - " + update_check_response.IsSuccessStatusCode);
                        var InfoStatus = await GetSoftwareInfo(client, deviceId);

                        _logger.LogInformation("SoftwareInfoList count value is - " + softwareInfoList.Count);
                        if (softwareInfoList.Count > 0)
                        {
                            foreach (var softwareInfo in softwareInfoList)
                            {
                                softwareData = softwareInfo.softwareName + "_" + softwareInfo.softwareVersion;
                                softwareName = softwareInfo.softwareName;
                                softwareVersion = softwareInfo.softwareVersion;
                                _logger.LogInformation("Value of SoftwareData - " + softwareData);
                            }
                        }
                    }
                    if ((softwareName != null && softwareName != string.Empty) || (softwareVersion != null && softwareVersion != string.Empty))
                    { 
                        downloadUri = "https://suzuki-da3-be-uat.azurewebsites.net/api/UpdateSoftware/downloadZipDetail?Id=" + id;
                        logsData += ".Software Name - " +softwareName+ " Software Version - "+softwareVersion;
                    }
                    string downloadStartFromHarman = String.Empty;
                    string uploadToBlob = String.Empty;
                    AzureTableCallback value = await GetCallBackResponse(id);
                    Console.Write("Azure table callback starts at -" + DateTime.Now.ToString());
                    logsData += ".Wait for callback in First API starts at - " + DateTime.Now.ToString();
                    while (value == null && callcountattempt < 22)
                    {
                        callcountattempt++;
                        value = await GetCallBackResponse(id);
                        Thread.Sleep(5000);
                    }
                    Console.Write("Azure table callback fetched at -" + DateTime.Now.ToString());
                    if (value != null)
                    {
                        _logger.LogInformation("Response form CallbackResponse table - " + value.DownloadFileUrl);

                        if (value.DownloadFileUrl != null)
                        {
                            string url = value.DownloadFileUrl; // External URL
                            string connectionString = "DefaultEndpointsProtocol=https;AccountName=sda3blob;AccountKey=hM7PauJ+SHJXYpwa5BD034ECFVceH0GCfKASH7Sr0rKiYkVzwqLNRFm7kAQIXOlCZWjjeFbFdVYp+AStodH1rQ==;EndpointSuffix=core.windows.net"; // Azure Blob Storage connection string
                            string containerName = "softwarestorage"; // Blob container name
                            string blobName = System.IO.Path.GetFileName(url);  // The name to save the file as in blob storage
                            downloadUri = "https://suzuki-da3-be-uat.azurewebsites.net/api/UpdateSoftware/downloadZipDetail?Id=" + id;


                            //var fileToUpload = DownloadFileUrl(url, blobName);
                            //if (fileToUpload != null)
                            //{

                            //string blobUrl = await UploadFileToAzureBlobAsync(fileToUpload.Result, blobName);//DownloadAndUploadToBlobAsync(url, connectionString, containerName, blobName);
                            //string blobUrl = await DownloadAndUploadToBlobAsync(url, connectionString, containerName, blobName);
                            //downloadStartFromHarman = DateTime.Now.ToString();
                            //string blobUrl = await DownloadFileUrl(url, "teston2ndMarch"+(new Guid()).ToString());
                            //string blobUrl = await DownloadAndUploadToBlobAsync(url, containerName, blobName, connectionString);
                            //string blobUrl= await DownloadAndUploadAsync(url,connectionString,containerName, blobName);
                            //uploadToBlob = string.Empty;
                            //    _logger.LogInformation("Uploading zip to blob completed");
                            //if (blobUrl != null && blobUrl.StartsWith("http"))
                            //{
                            //    downloadUri = blobUrl;
                              //  uploadToBlob = DateTime.Now.ToString();
                            //}
                            //else
                            //{
                            //    ErrorMessage = "Failed to upload";
                            //}

                            //}
                            //else
                            //{
                            //    ErrorMessage = "Failed to download";
                            //}



                        }
                        else
                        {
                            ErrorCodes = value.ErrorKey; ErrorMessage = value.ErrorMessage; UserErrorMessage = value.UserErrorMessage;

                        }
                        downloadFileSize = value.DownloadFileSize;
                        
                    }
                    else
                    {
                        downloadFileSize = -1;
                    }

                    _logger.LogInformation("Package Available at: " + DateTime.Now.ToString());
                    //if (packageID == string.Empty || packageID == null)

                    //{

                    //    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });

                    //}

                    //bool isPackageAvailable = await PackageReadyforDownload(client, packageID);

                    //if (isPackageAvailable)
                    //{
                    var updateStatus = UpdateCallBackResponse(id, InventoryDescription, callBackRequestToHarman, downloadStartFromHarman, EnvironmentVal, uploadToBlob);
                    var logsDataUpdate = CreatelogResponse("SU-Normal", id, logsData, "Success");
                    var response = new AvailablePackageResponse() { PackageID = packageID, SoftwareName = softwareName, SoftwareVersion = softwareVersion, DownloadUri = downloadUri, ErrorCode = ErrorCodes, ErrorMessage = ErrorMessage, userErrorMessage = UserErrorMessage, downloadFileSize = downloadFileSize };

                    return Ok(response);
                    //}

                    //else
                    //{
                    //    NotFound(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
                    //}

                }

            }

            catch (Exception ex)

            {

                _logger.LogError("Failed to authenticate to client Server.", ex.Message);

                var logsDataUpdate = CreatelogResponse("SU-Normal", id, logsData, "Failure");
                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FetchCredentialsFailed, Message = "Failed client Authentication!" });

            }

            return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });

        }
        [AllowAnonymous]
        [HttpGet("downloadZip")]
        public async Task<string> DownloadZip(string Id)
        {
            AzureTableCallback azureTableCallback = await GetCallBackResponse(Id);
            int callcountattempt = 0;
            while (azureTableCallback == null && callcountattempt < 20)
            {
                callcountattempt++;
                azureTableCallback = await GetCallBackResponse(Id);
                Thread.Sleep(5000);
            }
            //if (azureTableCallback != null) {
            //    string zipUrl = azureTableCallback.DownloadFileUrl; // Suzuki's ZIP URL
            //    return zipUrl;
            //}
            //return "";
            //try
            //{
            //    // The external URL of the zip file
            //    // string externalUrl = "https://external-portal.com/zipfile.zip";

            //    // Fetch the file from the external portal
            //    _httpClient.Timeout = TimeSpan.FromMinutes(30);
            //    var response = await _httpClient.GetAsync(azureTableCallback.DownloadFileUrl, HttpCompletionOption.ResponseHeadersRead);

            //    if (response.IsSuccessStatusCode)
            //    {
            //        // Get the content as a stream
            //        var stream = await response.Content.ReadAsStreamAsync();

            //        // Return the file stream to the client
            //        return File(stream, "application/zip", "downloaded.zip");
            //    }
            //    else
            //    {
            //        return NotFound("The zip file could not be found.");
            //    }
            //}
            //catch
            //{
            //    return StatusCode(500, "An error occurred while fetching the file.");
            //}
            try
            {
                if (azureTableCallback != null)
                {
                    if (azureTableCallback.DownloadFileUrl.Contains("https://test.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL"))
                    {
                        return Path.GetFileName(azureTableCallback.DownloadFileUrl);
                    }
                    else if (azureTableCallback.DownloadFileUrl.Contains("https://www.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL"))
                    {
                        return Path.GetFileName(azureTableCallback.DownloadFileUrl);
                    }
                    else
                        return azureTableCallback.DownloadFileUrl;
                }
                else { return null; }
            }
            catch (Exception ex)
            {
                return "Error - " + ex.Message;
            }
        }
        [AllowAnonymous]
        [HttpGet("downloadZipDetail")]
        public async Task<DownloadData> downloadZipDetail(string Id)
        {
            AzureTableCallback azureTableCallback = await GetCallBackResponse(Id);
            int callcountattempt = 0;
            DownloadData downloadData = new DownloadData() { softwareSize = 0, SoftwareName = "" };

            while (azureTableCallback.DownloadFileUrl == null && callcountattempt < 20)
            {
                callcountattempt++;
                azureTableCallback = await GetCallBackResponse(Id);
                Thread.Sleep(5000);
            }

            try
            {
                if (azureTableCallback != null)
                {

                    if (!string.IsNullOrEmpty(azureTableCallback.DownloadFileUrl))
                    {
                        if (azureTableCallback.DownloadFileUrl.Contains("https://test.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL") ||
                            azureTableCallback.DownloadFileUrl.Contains("https://www.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL"))
                        {
                            downloadData.SoftwareName = Path.GetFileName(azureTableCallback.DownloadFileUrl);

                        }
                        else
                        {
                            downloadData.SoftwareName = azureTableCallback.DownloadFileUrl;
                        }
                        downloadData.softwareSize = azureTableCallback.DownloadFileSize;
                    }
                    else
                    {
                        downloadData.SoftwareName = "Download URL is empty.";
                    }

                    return downloadData;
                }
                else
                {
                    // Handle case where azureTableCallback is still null after retries
                    downloadData.SoftwareName = "AzureTableCallback is null after multiple attempts.";
                    return downloadData;
                }
            }
            catch (Exception ex)
            {
                downloadData.SoftwareName = ex.Message;
                return downloadData;
            }
        }

        //[HttpGet("downloadZipDetail")]
        //public async Task<DownloadData> downloadZipDetail(string Id)
        //{
        //    AzureTableCallback azureTableCallback = await GetCallBackResponse(Id);
        //    int callcountattempt = 0;
        //    DownloadData downloadData = new DownloadData() { softwareSize=0,SoftwareName=""};
        //    while (azureTableCallback == null && callcountattempt < 20)
        //    {
        //        callcountattempt++;
        //        azureTableCallback = await GetCallBackResponse(Id);
        //        Thread.Sleep(5000);
        //    }
        //    try
        //    {
        //        if (azureTableCallback != null)
        //        {
        //            downloadData.softwareSize=azureTableCallback.DownloadFileSize;
        //            if (azureTableCallback.DownloadFileUrl.Contains("https://test.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL"))
        //            {
        //                downloadData.SoftwareName = Path.GetFileName(azureTableCallback.DownloadFileUrl);
        //                return downloadData;
        //            }
        //            else if (azureTableCallback.DownloadFileUrl.Contains("https://www.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL"))
        //            {
        //                downloadData.SoftwareName = Path.GetFileName(azureTableCallback.DownloadFileUrl);
        //                return downloadData;
        //            }
        //            else
        //            {
        //                downloadData.SoftwareName=azureTableCallback.DownloadFileUrl;
        //                return downloadData;
        //            }
        //        }
        //        else { return null; }
        //    }
        //    catch (Exception ex)
        //    {
        //        downloadData.SoftwareName=ex.Message;
        //        return downloadData;
        //    }
        //}
        [AllowAnonymous]
        [HttpPost]
        [Route("callback")]
        public async Task<IActionResult> callback(Guid Id, [FromBody] CallbackResponse callbackResponse)//string str)
        {
            try
            {
                string requestBody;
                string errorMessage = null;
                using (StreamReader reader = new StreamReader(Request.Body, Encoding.UTF8))
                {
                    requestBody = await reader.ReadToEndAsync();

                }
                _logger.LogInformation("Starting callback");
                _logger.LogInformation("Unique Id received is :" + Id.ToString());
                // _logger.LogInformation($"{requestBody}");

                var downURL = callbackResponse.downloadFileUrl;
                _logger.LogInformation("DownURL is : " + downURL);
                if (callbackResponse.errorKey != null && callbackResponse.status != null)
                    errorMessage = await CallbackError(callbackResponse.errorKey, callbackResponse.status);
                var callbackSaved = await CreateCallBackResponse(callbackResponse, Id.ToString(), errorMessage);
                if (callbackSaved == true)
                    _logger.LogInformation("Callback Saved Successfully - " + Id.ToString());
                else
                    _logger.LogInformation("Saving of Callback failed.");
                return Ok();

            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Api");
                _logger.LogError(ex, ex.Message);
                return BadRequest(ex.Message);
            }

        }
        [NonAction]
        public async Task<string> DownloadFileUrl(string url, string fileName)
        {
            try
            {
                _httpClient.Timeout = TimeSpan.FromMinutes(30);
                // Download the file as a byte array
                var fileBytes = await _httpClient.GetByteArrayAsync(url);

                // Create a MemoryStream from the byte array
                var memoryStream = new MemoryStream(fileBytes);

                // Create an IFormFile from the MemoryStream
                var formFile = new FormFile(memoryStream, 0, memoryStream.Length, "file", fileName)
                {
                    ContentType = "application/octet-stream" // Or set the correct content type based on the file (e.g., image/png, application/pdf, etc.)
                };
                var fileUploadUrl = UploadFileToAzureBlobAsync(formFile, formFile.FileName);
                return fileUploadUrl.Result;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        private static async Task<byte[]> DownloadFileAsync(string fileUrl)
        {
            using (var httpClient = new HttpClient())
            {
                // Download the file as byte array
                byte[] fileContent = await httpClient.GetByteArrayAsync(fileUrl);
                return fileContent;
            }
        }


        private static async Task<string> UploadFileToAzureBlobAsync(IFormFile fileContent, string fileName)
        {
            // Create a BlobServiceClient
            var blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=sda3blob;AccountKey=hM7PauJ+SHJXYpwa5BD034ECFVceH0GCfKASH7Sr0rKiYkVzwqLNRFm7kAQIXOlCZWjjeFbFdVYp+AStodH1rQ==;EndpointSuffix=core.windows.net");

            // Get a reference to the container
            var containerClient = blobServiceClient.GetBlobContainerClient("softwarestorage");

            // Create the container if it doesn't exist
            await containerClient.CreateIfNotExistsAsync();

            // Create a unique name for the blob (optional)
            string blobName = fileName;

            // Get a reference to the blob
            var blobClient = containerClient.GetBlobClient(blobName);

            if (fileContent != null)
            {
                // Upload the file to the blob storage
                using (var stream = fileContent.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, overwrite: true);
                }
            }
            else
            {
                return "Null File";
            }
            // Generate the URL of the uploaded blob
            Uri blobUrl = blobClient.Uri;

            return blobUrl.ToString();
        }
        [NonAction]
        public async Task<string> DownloadAndUploadAsync(string fileUrl, string connectionString, string containerName, string blobName)
        {
            const int chunkSize = 8 * 1024 * 1024; // 8MB chunks (adjust as needed)

            try
            {
                // Create BlobServiceClient
                var blobServiceClient = new BlobServiceClient(connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient(containerName);
                await containerClient.CreateIfNotExistsAsync(); // Ensure the container exists

                var blobClient = containerClient.GetBlobClient(blobName);

                // Create a stream to upload data to the blob storage
                using (HttpClient httpClient = new HttpClient())
                using (Stream downloadStream = await httpClient.GetStreamAsync(fileUrl))
                {
                    var buffer = new byte[chunkSize];
                    int bytesRead;

                    // Create the blob upload stream (start the upload)
                    var blobUploadStream = blobClient.OpenWrite(overwrite: true);

                    while ((bytesRead = await downloadStream.ReadAsync(buffer, 0, chunkSize)) > 0)
                    {
                        // Only write the bytes actually read
                        await blobUploadStream.WriteAsync(buffer, 0, bytesRead);
                        Console.WriteLine($"Uploaded {bytesRead} bytes...");
                    }

                    // Complete the upload
                    await blobUploadStream.FlushAsync();
                    Console.WriteLine("File successfully uploaded to Blob Storage.");
                    return blobClient.Uri.ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return "Error Occured in download or upload -" + ex.Message;
            }
        }
        public static async Task<string> DownloadAndUploadToBlobAsync(string fileUrl, string containerName, string blobName, string connectionString)
        {
            // Set the block size (e.g., 4 MB)
            int blockSize = 4 * 1024 * 1024;
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
            // Get the container client from the service client
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);

            // Create the container if it doesn't exist
            await containerClient.CreateIfNotExistsAsync();

            // Get a BlobClient from the container client
            BlockBlobClient blobClient = containerClient.GetBlockBlobClient(blobName);
            //BlobClient blobClient= containerClient.GetBlobClient(blobName);
            try
            {
                var blockIds = new List<string>();

                using (HttpClient httpClient = new HttpClient())
                {
                    // Get the content length to track progress
                    var response = await httpClient.GetAsync(fileUrl, HttpCompletionOption.ResponseHeadersRead);
                    var statusrespons = response.IsSuccessStatusCode;
                    long totalBytes = response.Content.Headers.ContentLength ?? 0;

                    using (Stream contentStream = await response.Content.ReadAsStreamAsync())
                    {
                        byte[] buffer = new byte[blockSize];
                        int bytesRead;
                        long totalBytesRead = 0;

                        while ((bytesRead = await contentStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                        {
                            // Generate a unique block ID
                            string blockId = Convert.ToBase64String(Guid.NewGuid().ToByteArray());

                            // Stage the block
                            using (var memoryStream = new MemoryStream(buffer, 0, bytesRead))
                            {
                                await blobClient.StageBlockAsync(blockId, memoryStream);
                            }

                            // Add the block ID to the list
                            blockIds.Add(blockId);

                            // Update progress
                            totalBytesRead += bytesRead;
                            await blobClient.CommitBlockListAsync(blockIds);
                            Console.WriteLine($"Uploaded {totalBytesRead} of {totalBytes} bytes ({(double)totalBytesRead / totalBytes * 100:0.00}%)");
                        }
                    }
                }

                return blobClient.Uri.AbsoluteUri;

            }
            // Commit the block list to complete the upload


            //// Retry Policy: Retry up to 3 times with exponential backoff
            //var retryPolicy = Policy
            //    .Handle<Exception>(ex => ex is HttpRequestException || ex is Azure.RequestFailedException)
            //    .WaitAndRetryAsync(5, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
            //        (exception, timeSpan, retryCount, context) =>
            //        {
            //            Console.WriteLine($"Retry {retryCount} due to: {exception.Message}. Waiting {timeSpan.TotalSeconds} seconds before next retry.");
            //        });

            //// Configure HttpClient with a 30-minute timeout
            //using (HttpClient client = new HttpClient())
            //{
            //    client.Timeout = TimeSpan.FromMinutes(30); // Set timeout to 30 minutes

            //    try
            //    {
            //        // Get file size (this is optional, just to show progress)
            //        var headResponse = await client.SendAsync(new HttpRequestMessage(HttpMethod.Head, fileUrl));
            //        long fileSize = headResponse.Content.Headers.ContentLength ?? 0;
            //        Console.WriteLine($"File size: {fileSize} bytes");

            //        // Start downloading the file in chunks
            //        long bytesDownloaded = 0;
            //        using (Stream fileStream = await retryPolicy.ExecuteAsync(() => client.GetStreamAsync(fileUrl)))
            //        {
            //            BlobUploadOptions uploadOptions = new BlobUploadOptions
            //            {
            //                TransferOptions = new StorageTransferOptions
            //                {
            //                    MaximumConcurrency = 4
            //                }
            //            };

            //            // Upload file to Blob Storage in chunks
            //            byte[] buffer = new byte[blockSize];
            //            int bytesRead;
            //            while ((bytesRead = await fileStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
            //            {
            //                try
            //                {
            //                    // Upload the current chunk to the blob storage
            //                    using (MemoryStream chunkStream = new MemoryStream(buffer, 0, bytesRead))
            //                    {
            //                        chunkStream.Position = 0;
            //                        //await retryPolicy.ExecuteAsync(() => blobClient.AppendBlockAsync(chunkStream));
            //                        await blobClient.AppendBlockAsync(chunkStream);
            //                        bytesDownloaded += bytesRead;

            //                        // Optionally: Print download progress
            //                        Console.WriteLine($"Downloaded {bytesDownloaded} of {fileSize} bytes ({(double)bytesDownloaded / fileSize * 100:F2}%)");
            //                    }

            //                }
            //                catch (Exception uploadException)
            //                {
            //                    return "Exception occured in upload";
            //                }
            //            }
            //        }
            //        return blobClient.Uri.ToString();
            //    }
            catch (Exception ex)
            {
                return "Error occured " + ex.Message;
            }
        }
        [NonAction]
        public async Task<string> UploadZipFromUrlAsync(string sourceUrl, string containerName, string blobName, string connectionString)
        {
            try
            {
                BlobServiceClient _blobServiceClient = new BlobServiceClient(connectionString);
                var blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
                await blobContainerClient.CreateIfNotExistsAsync();

                var blobClient = blobContainerClient.GetBlobClient(blobName);

                // Start copying from the source URL to Blob Storage
                var copyOperation = await blobClient.StartCopyFromUriAsync(new Uri(sourceUrl));

                // Poll for copy completion
                while (true)
                {
                    var properties = await blobClient.GetPropertiesAsync();
                    if (properties.Value.CopyStatus != CopyStatus.Pending)
                        break;
                    await Task.Delay(500); // Wait before checking again
                }

                return blobClient.Uri.ToString(); // Return the uploaded Blob URL
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        private async Task<String> GetKeyFromStreamContent(StreamContent decryptedStream, string keyValue)
        {

            decryptedStream.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            string fileContent = await decryptedStream.ReadAsStringAsync();
            JObject jsonContent = JObject.Parse(fileContent);
            string requestedValue = (string)jsonContent.SelectToken(keyValue);
            return requestedValue;

        }
        [NonAction]
        public async Task<string> ReadStreamContentAsStringAsync(StreamContent streamContent)
        {
            // Read the content of StreamContent as a string
            return await streamContent.ReadAsStringAsync();
        }
        [NonAction]
        public async Task<bool> CreateCallBackResponse(CallbackResponse callbackResponse, string id, string errorMessage)
        {
            try
            {
                if (callbackResponse == null)
                { return false; }
                callbackResponse.CallBackRecivedFromHarman = DateTime.Now.ToString();
                var response = await _callbackAzureTableService.AddCallbackResponse(callbackResponse, id, errorMessage);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Save");
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        [NonAction]
        public async Task<bool> CreatelogResponse(string module,string id, string logs,string status)
        {
            try
            {
                
                var response = await _callbackAzureTableService.AddLogsData(module,id,status,logs);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Save");
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }
        [NonAction]
        public async Task<bool> UpdateCallBackResponse(string id, string InventoryDescription, string CallBackRequestToHarman, string DownloadStartFromHarman, string EnvironmentVal, string UploadToBlob)
        {
            try
            {

                var response = await _callbackAzureTableService.UpdateCallbackresponse(id, InventoryDescription, CallBackRequestToHarman, DownloadStartFromHarman, EnvironmentVal, UploadToBlob);
                if (response == false)
                    return false;
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Update");
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }
        [NonAction]
        public async Task<AzureTableCallback> GetCallBackResponse(string id)
        {
            try
            {
                if (id == null)
                { return null; }
                var response = await _callbackAzureTableService.GetCallbackResponse(id);
                if (response == null)
                    return null;
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Fetch");
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }
        
        [NonAction]
        public async Task<string> CallbackError(string errorKey, string status)
        {
            try
            {

                var response = await _callbackAzureTableService.GetCallbackError(status, errorKey);
                if (response != null)
                    return response.UserErrorMessage;
                return null;
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Error occured in Callback Error ");
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }


        private async Task<IActionResult> GetSoftwareInfo(HttpClient client, string deviceId)
        {

            var payload = new
            {
                devIdFilter = deviceId,
                operationResults = new[] { "OP_EXTERNAL_STORAGE_PACKAGE_DELIVERED" }
            };
            var jsonBody = Newtonsoft.Json.JsonConvert.SerializeObject(payload);

            HttpContent content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
            try
            {
                using (HttpResponseMessage Check_OperationResponse = await client.PostAsync(DA3Constants.DA3_CLIENT_API_OPERATION, content))
                {
                    if (Check_OperationResponse.IsSuccessStatusCode)
                    {
                        string requestedValue;
                        string responseBody = await Check_OperationResponse.Content.ReadAsStringAsync();
                        JObject jsonContent = JObject.Parse(responseBody);

                        int OperationCount = (int)jsonContent.SelectToken("totalCount");

                        JArray representationObjects = (JArray)jsonContent.SelectToken("representationObjects");


                        for (int i = 0; i < representationObjects.Count; i++)
                        {

                            SoftwareInfo softwareInfo = new SoftwareInfo();

                            softwareInfo.deviceID = deviceId;

                            requestedValue = (string)representationObjects[i].SelectToken("id");

                            softwareInfo.operationId = requestedValue;

                            requestedValue = (string)representationObjects[i].SelectToken("jobName");

                            softwareInfo.campaignName = requestedValue;


                            if (softwareInfo.campaignName.Length > 0)
                            {

                                using (HttpResponseMessage Check_InventoryResponse = await client.GetAsync(string.Format(DA3Constants.DA3_CLIENT_API_OPERATION_INVERNTORY, softwareInfo.operationId)))
                                {

                                    if (Check_InventoryResponse.IsSuccessStatusCode)
                                    {
                                        string responseBody2 = await Check_InventoryResponse.Content.ReadAsStringAsync();
                                        JObject jsonContent2 = JObject.Parse(responseBody2);

                                        JArray inventoryArray = (JArray)jsonContent2.SelectToken("inventory");

                                        if (inventoryArray.Count > 0)
                                        {
                                            for (int k = 0; k < inventoryArray.Count; k++)
                                            {
                                                JArray componentsArray = (JArray)inventoryArray[k].SelectToken("components");

                                                for (int j = 0; j < componentsArray.Count; j++)
                                                {
                                                    softwareInfo.softwareName = (string)componentsArray[j].SelectToken("componentName");
                                                    softwareInfo.softwareVersion = (string)componentsArray[j].SelectToken("updateContent.targetComponentVersionName");

                                                }
                                            }
                                        }


                                    }

                                }

                            }
                            softwareInfoList.Add(softwareInfo);
                        }

                    }
                }
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }



        private async Task<string?> handleAuthentiocationSessionID(HttpClient client)

        {

            string sessionID = string.Empty;

            sessionID = _userClientSession.getClientSessionID();

            if (string.IsNullOrWhiteSpace(sessionID))

            {

                client.DefaultRequestHeaders.Add("Accept", "application/json");

                try

                {

                    var creds = _userClientSession.getCredentials();

                    if (creds == null)
                    {

                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:handleAuthentiocationSessionID: NOT ABLE TO FETCH CREDENTIALS.");

                    }

                    else

                    {

                        using (HttpResponseMessage login_response = await client.PostAsync(DA3Constants.DA3_CLIENT_API_LOGIN, new FormUrlEncodedContent(creds)))

                        {
                            if (login_response.IsSuccessStatusCode)

                            {
                                string jsonResponse = await login_response.Content.ReadAsStringAsync();

                                LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);

                                sessionID = loginResponse?.sessionId;

                                if (!string.IsNullOrWhiteSpace(sessionID))

                                    _userClientSession.setClientSessionId(sessionID);
                            }

                        }

                    }

                }
                catch (Exception ex)
                {
                    _logger.LogError("SOFTWARE UPDATE PAGE: ERROR WHILE AUTHENTICATING TO CLIENT API " + ex.Message.ToString(), ex);
                }
            }
            return sessionID;
        }

        private void updateClientHeaders(HttpClient client, string? sessionID)

        {
            client.DefaultRequestHeaders.Clear();

            client.DefaultRequestHeaders.Add("Accept", "application/json");

            if (!string.IsNullOrEmpty(sessionID))
            {
                client.DefaultRequestHeaders.Add("sessionId", sessionID);
            }
        }
    }

    class AvailablePackageResponse

    {
        public string? PackageID { get; set; }
        public string? SoftwareName { get; set; }
        public string? SoftwareVersion { get; set; }
        public string? DownloadUri { get; set; }
        public string? ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }

        public long downloadFileSize { get; set; }
        public string? userErrorMessage { get; set; }
    }
    public class DownloadData
    {
        public long softwareSize { get; set; }
        public string? SoftwareName { get; set; }

    }
}
