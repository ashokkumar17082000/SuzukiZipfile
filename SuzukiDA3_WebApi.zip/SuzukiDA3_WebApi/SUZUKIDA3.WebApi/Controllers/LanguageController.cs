﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class LanguageController : BaseController
    {
        private readonly ILanguageDataAzureTableService _languageService;
       
        public LanguageController(ILanguageDataAzureTableService languageService)
        {
            _languageService = languageService;

        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllLanguage))]
        public async Task<IActionResult> GetAllLanguage()
        {
            var response = await _languageService.GetLanguageData();
            return Ok(response);
        }
    }
}
