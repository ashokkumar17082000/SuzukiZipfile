﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Controllers
{
    /// <summary>
    /// Controller for user code validation
    /// </summary>
    /// <seealso cref="SUZUKIDA3.WebApi.Controllers.BaseController" />
    public class AdminUserController : BaseController
    {
        private readonly IAdminUserValidationAzureTableService _azureValidationCodeService;
        private readonly IEmailDataAzureTableService _emailDataService;

        public AdminUserController(IAdminUserValidationAzureTableService azureValidationService)
        {
            _azureValidationCodeService = azureValidationService;

        }

        /// <summary>
        /// Validates the user code.
        /// </summary>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet(nameof(GetUserLoggedIn))]
        public async Task<IActionResult> GetUserLoggedIn(string userId, string pwd)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(userId))
                {
                    var response = await _azureValidationCodeService.GetUser(userId);
                    //return (response == null ? Ok(false) : Ok(response.IsAdmin == userId));
                    if (response == null) { return Ok(false); }
                    else
                    {
                        response.IsAdmin = true;
                        if(response.PasswordHash!=null && response.PasswordHash == pwd)
                        return Ok(response);
                        else
                            return Ok(false);
                    }
                }
                else { return BadRequest("Failed!"); }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpGet(nameof(GetUserCode))]
        public async Task<IActionResult> GetUserCode(string userCode)
        {
            var response = await _azureValidationCodeService.GetUser(userCode);
            if (response == null)
            {
                return BadRequest("Failed !");
            }
            return Ok(response);
        }

        /// <summary>
        /// Updates the user code.
        /// </summary>
        /// <param name="oldcode">The oldcode.</param>
        /// <param name="userCode">The user code.</param>
        /// <returns></returns>
       
    }
}