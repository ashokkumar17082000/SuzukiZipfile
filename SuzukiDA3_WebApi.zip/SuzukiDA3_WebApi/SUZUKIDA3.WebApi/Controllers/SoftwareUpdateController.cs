﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System.Net.Http.Headers;
using System.Text.Json;
using SUZUKIDA3.Common.Helpers;

namespace SUZUKIDA3.WebApi.Controllers
{
    /// <summary>
    /// Software update controller
    /// </summary>
    /// <seealso cref="SUZUKIDA3.WebApi.Controllers.BaseController" />
    public class SoftwareUpdateController : BaseController
    {
        #region Private Fields
        private readonly ILogger<SoftwareUpdateController> _logger;
        private readonly IAsymetricCryptographicService _encryptionDecryptionService;
        private readonly IManageClientUserSession _userClientSession;
        private bool IsMTLSRequired = false;
        private string clientAPIbaseUrl = string.Empty;
        private string clientExternalStorageUrl = string.Empty;
        private readonly IZipEncryptionHelper _zipEncryptionService;
        private ClientAccessReqDto _accessReqData;
        private readonly IHttpClientFactory _httpClientFactory;
        #endregion
        public SoftwareUpdateController(ILogger<SoftwareUpdateController> logger, IAsymetricCryptographicService encryptionDecryptionService, IConfiguration configure, IManageClientUserSession userClientSession, IZipEncryptionHelper zipEncryptionService, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _encryptionDecryptionService = encryptionDecryptionService;
            _userClientSession = userClientSession;
            _accessReqData = _userClientSession.GetClientConnectData();
            IsMTLSRequired = _accessReqData.IsMTLS;
            clientAPIbaseUrl = _accessReqData.CleintBaseUrl;
            clientExternalStorageUrl = _accessReqData.ClientExternalStorageUrl;
            _zipEncryptionService = zipEncryptionService;
            _httpClientFactory = httpClientFactory;
        }

        /// <summary>
        /// Softwares update.
        /// </summary>
        /// <param name="file">The file.</param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost(nameof(SoftwareUpdate))]
        public async Task<IActionResult> SoftwareUpdate(IFormFile file)
        {
            if (file == null)
            {
                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FileNotFound, Message = "File should be uploaded." });
            }

            string sessionID = string.Empty;
            string packageID = string.Empty;
            string loginUrl = clientAPIbaseUrl + "api/login";
            string check_for_update_url = clientExternalStorageUrl + "createPackageByInventory";
            string software_download_url = clientExternalStorageUrl;

            try
            {

                if (IsMTLSRequired)
                {
                    _userClientSession.handle_MTLS_validation(true);
                }
                var creds = _userClientSession.getCredentials();

                if (creds == null)
                {
                    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FetchCredentialsFailed, Message = "Failed client Authentication !" });
                }

                Stream decrypted_file_stream = await _encryptionDecryptionService.DecryptFile(file);
                if (decrypted_file_stream == null)
                {
                    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.CorruptedFile, Message = "InValid file format." });
                }
                _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Uploaded file decryption success!");
                using (HttpClient client = _httpClientFactory.CreateClient(DA3Constants.DA3_HTTP_CLIENT_NAME))
                {
                    sessionID = _userClientSession.getClientSessionID();

                    if (string.IsNullOrWhiteSpace(sessionID))
                    {
                        //get login credentials
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        try
                        {

                            using (HttpResponseMessage login_response = await client.PostAsync(loginUrl, new FormUrlEncodedContent(creds)))
                            {
                                if (login_response.IsSuccessStatusCode)
                                {
                                    string jsonResponse = await login_response.Content.ReadAsStringAsync();
                                    LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);
                                    sessionID = loginResponse?.sessionId;
                                    if (!string.IsNullOrWhiteSpace(sessionID))
                                        _userClientSession.setClientSessionId(sessionID);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogError("Failed to authenticate to client Server.", ex.Message);
                            return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FetchCredentialsFailed, Message = "Failed client Authentication!" });
                        }
                    }
                    if (sessionID == string.Empty)
                    {
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.ServerAuthFail, Message = "Internal Server Error!" });
                    }

                    _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Autentication success : SessionID : " + sessionID);
                    var formData = new MultipartFormDataContent();

                    StreamContent streamcontent = new StreamContent(decrypted_file_stream);
                    formData.Add(streamcontent, "file", file.FileName);

                    client.DefaultRequestHeaders.Add("sessionId", sessionID);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    using (HttpResponseMessage update_check_response = await client.PostAsync(check_for_update_url, formData))
                    {
                        if (update_check_response.IsSuccessStatusCode)
                        {
                            string jsonResponse = await update_check_response.Content.ReadAsStringAsync();
                            var packageUpdateResponse = JsonSerializer.Deserialize<SoftwareUpdatePackageResDto>(jsonResponse);
                            packageID = packageUpdateResponse?.id;
                        }
                    }

                    if (packageID == string.Empty)
                    {
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." });
                    }
                    int package_ready_counter = 0;

                    _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: update Available, Package Id!" + packageID);

                    do
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.Add("Accept", "application/json");
                        client.DefaultRequestHeaders.Add("sessionId", sessionID);
                        package_ready_counter++;

                        using (HttpResponseMessage response_download_ready = await client.GetAsync(software_download_url + packageID))
                        {
                            if (response_download_ready.IsSuccessStatusCode)
                            {
                                string jsonResponse = await response_download_ready.Content.ReadAsStringAsync();
                                PackageDownloadReadyResponseObject packageAvailableResponse = JsonSerializer.Deserialize<PackageDownloadReadyResponseObject>(jsonResponse);
                                if (packageAvailableResponse != null && packageAvailableResponse.status == "SUCCESS")
                                {
                                    package_ready_counter = 200;
                                    _logger.LogInformation("SOFTWARE DOWNLOAD PAGE:Sucessfully Completed packaging in OTA Server: Package Status: " + packageAvailableResponse.status);
                                }
                                else if (packageAvailableResponse != null && packageAvailableResponse.status == "FAILED")
                                {
                                    _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Failed while packaging in OTA Server: Package Status: " + packageAvailableResponse.status);
                                    package_ready_counter = 200;
                                    return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Software Update is not available." });

                                }
                                else
                                {
                                    _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Waiting for package Avaialblity:" + packageAvailableResponse?.status);
                                    Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                                }
                            }
                            else
                            {
                                Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                            }
                        }
                    } while (package_ready_counter < 120);
                    software_download_url += string.Format("{0}/download", packageID);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("sessionId", sessionID);
                    client.DefaultRequestHeaders.Add("Accept", "application/json");

                    try
                    {
                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, software_download_url);
                        using (HttpResponseMessage fileDownloadResponse = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead).ConfigureAwait(true))
                        {
                            _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:" + fileDownloadResponse.IsSuccessStatusCode);
                            if (fileDownloadResponse.IsSuccessStatusCode)
                            {
                                var datastream = await fileDownloadResponse.Content.ReadAsStreamAsync();
                                _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:Started:");
                                string contentType = fileDownloadResponse.Content?.Headers.ContentType?.MediaType?.ToString();

                                if (string.IsNullOrEmpty(contentType))
                                {
                                    contentType = "application/octet-stream";
                                }
                                ContentDispositionHeaderValue contentDisposition = fileDownloadResponse.Content?.Headers?.ContentDisposition;
                                string fileName = contentDisposition != null ? _userClientSession.getFileNameFromContentDisposition(contentDisposition) : "SoftwareUpdate.zip";

                                _logger.LogInformation("SOFTWARE REQUEST RESPONSE DOWNLOAD:" + fileDownloadResponse.Content?.Headers.ToString());
                                Response.Headers.Add("Content-Type", contentType);
                                Response.Headers.Add("Content-Disposition", $"attachment; filename={fileName}");
                                Response.Headers.Add("FileName", fileName);
                                await datastream.CopyToAsync(Response.Body);
                                await Response.Body.FlushAsync();
                                await Response.CompleteAsync();
                                _logger.LogInformation(string.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: COMPLETED: FOR PACKAGEID: {0}, FileName: {1}", packageID, fileName));
                                datastream.Close();
                                return new EmptyResult();
                            }
                            else
                            {
                                _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response STATUS CODE: {0}", fileDownloadResponse.StatusCode), "");
                                _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response Reason Parse: {0}", fileDownloadResponse.ReasonPhrase), "");
                                string errorContent = await fileDownloadResponse.Content.ReadAsStringAsync();
                                _logger.LogError(String.Format("SOFTWARE REQUEST RESPONSE DOWNLOAD: Response Reason Parse:{0}", errorContent), "");
                                return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.DownloadFailed, Message = "SOFTWARE REQUEST RESPONSE DOWNLOAD." + errorContent });

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(String.Format("EXCEPTION: DOWNLOAD FROM OTA FAILED:  ", ex.Message), "");
                        return BadRequest(new SoftwareErrorResponseDto { ErrorCode = ErrorCode.DownloadFailed, Message = "Software Download failed. With Exception In Download." });
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("software report failed.", ex.Message);
                return BadRequest(ex.Message);
            }
            finally
            {
                if (IsMTLSRequired)
                {
                    _userClientSession.handle_MTLS_validation(false);
                }
            }
        }
        private async Task<HttpClient?> getClientHeaders(HttpClient client)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("Accept", "application/json");
            string sessionID = await handleAuthentiocationSessionID(client);
            if (!string.IsNullOrEmpty(sessionID))
            {
                client.DefaultRequestHeaders.Add("sessionId", sessionID);
            }
            return client;
        }

        private async Task<string?> handleAuthentiocationSessionID(HttpClient client)
        {
            string sessionID = string.Empty;
            string loginUrl = clientAPIbaseUrl + "api/login";
            sessionID = _userClientSession.getClientSessionID();
            if (string.IsNullOrWhiteSpace(sessionID))
            {
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                try
                {
                    var creds = _userClientSession.getCredentials();
                    if (creds == null)
                    {
                        _logger.LogInformation("SOFTWARE UPDATE PAGE ERROR:handleAuthentiocationSessionID: NOT ABLE TO FETCH CREDENTIALS.");
                    }
                    else
                    {
                        using (HttpResponseMessage login_response = await client.PostAsync(loginUrl, new FormUrlEncodedContent(creds)))
                        {
                            if (login_response.IsSuccessStatusCode)
                            {
                                string jsonResponse = await login_response.Content.ReadAsStringAsync();
                                LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);
                                sessionID = loginResponse?.sessionId;
                                if (!string.IsNullOrWhiteSpace(sessionID))
                                    _userClientSession.setClientSessionId(sessionID);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError("SOFTWARE UPDATE PAGE: ERROR WHILE AUTHENTICATING TO CLIENT API " + ex.Message.ToString(), ex);
                }
            }
            return sessionID;
        }
    }
}
