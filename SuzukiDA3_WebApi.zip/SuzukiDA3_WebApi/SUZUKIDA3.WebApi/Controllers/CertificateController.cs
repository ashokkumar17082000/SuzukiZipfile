﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class CertificateController : BaseController
    {
        private readonly ICertificateDataAzureTableService _certificateService;

        public CertificateController(ICertificateDataAzureTableService certificateService)
        {
            _certificateService = certificateService;

        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllCertificates))]
        public async Task<IActionResult> GetAllCertificates()
        {
            var response = await _certificateService.GetCertificateData();
            return Ok(response);
        }
    }
}
