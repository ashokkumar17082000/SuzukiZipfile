﻿using Castle.Components.DictionaryAdapter.Xml;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.IO.Compression;
using System.Net;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class ReleaseNotesController : BaseController
    {
        private readonly IModelList _ModelService;
        private readonly IReleaseNotes _releaseNotes;
        private readonly ILogger<ReleaseNotesController> _Logger;
        private readonly IAzureBlobStorage _AzureBlobStorage;

        public ReleaseNotesController(IModelList modelService,IReleaseNotes releaseNotes, ILogger<ReleaseNotesController> logger, IAzureBlobStorage azureBlobStorage)
        {
            _ModelService = modelService;
            _releaseNotes = releaseNotes;
            _Logger = logger;
            _AzureBlobStorage = azureBlobStorage;
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetSoftwareList))]
        public async Task<IActionResult> GetSoftwareList()
        {
            var response = await _releaseNotes.GetReleaseNotesList();
            return Ok(response);
        }

        [AllowAnonymous]
        [HttpGet(nameof(GetReleaseNotesData))]
        public async Task<IActionResult> GetReleaseNotesData(string softwareVariant,string softwareVersion,string langCode)
        {
            var response = await _releaseNotes.GetReleaseNotesDataList(softwareVariant, softwareVersion, langCode);
           
            return Ok(response);
        }
    }
}
