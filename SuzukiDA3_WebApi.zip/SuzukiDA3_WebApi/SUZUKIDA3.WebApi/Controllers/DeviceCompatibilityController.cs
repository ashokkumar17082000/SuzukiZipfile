﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto;

namespace SUZUKIDA3.WebApi.Controllers
{
    public class DeviceCompatibilityController : BaseController
    {
        private readonly IDCManufacturerDataAzureTableService _dcManufacturerService;
       private readonly IDeviceDataAzureTableService _deviceDataAzureTableService;
        private readonly IOSDataAzureTableService _oSDataAzureTableService;
        private readonly IDeviceOSFeatureAzureTableService _deviceOSFeatureTableService;
        public DeviceCompatibilityController(IDCManufacturerDataAzureTableService dcManufacturerService, IDeviceDataAzureTableService deviceDataAzureTableService, IOSDataAzureTableService oSDataAzureTableService, IDeviceOSFeatureAzureTableService deviceOSFeatureAzureTableService)
        {
            _dcManufacturerService = dcManufacturerService;
            _deviceDataAzureTableService = deviceDataAzureTableService;
            _oSDataAzureTableService = oSDataAzureTableService;
            _deviceOSFeatureTableService = deviceOSFeatureAzureTableService;
        }

        [AllowAnonymous]
        [HttpGet(nameof(GetAllRegion))]
        public async Task<IActionResult> GetAllRegion()
        {
            var response = await _dcManufacturerService.GetDCRegion();
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetAllManufacturerName))]
        public async Task<IActionResult> GetAllManufacturerName()
        {
            var response = await _dcManufacturerService.GetDCManufacturerData();
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetDeviceName))]
        public async Task<IActionResult> GetDeviceName()
        {
            var response = await _deviceDataAzureTableService.GetDeviceData();
            return Ok(response);
        }
        [AllowAnonymous]
        [HttpGet(nameof(GetOSName))]
        public async Task<IActionResult> GetOSName()
        {
            var response = await _oSDataAzureTableService.GetOSData();
            return Ok(response);
        }

        [AllowAnonymous]
        [HttpPost(nameof(GetDeviceOSFeatures))]
        public async Task<IActionResult> GetDeviceOSFeatures([FromBody] OSFeatureReqDto data)
        {

            var response = await _deviceOSFeatureTableService.GetDeviceOSFeatureData(data);
            return Ok(response);
        }
    }
}
