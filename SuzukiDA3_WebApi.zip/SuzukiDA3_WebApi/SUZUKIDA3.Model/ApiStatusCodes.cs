﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model
{
    public static class ApiStatusCodes
    {
        public const int IsSuccessfully = 200;

        /// <summary>
        /// The is failed
        /// </summary>
        public const int IsFailed = 2001;

        public const int IsGuidFailed = 400;


        /// <summary>
        /// The success/
        /// </summary>
        public const bool Success = true;

        /// <summary>
        /// The failed/
        /// </summary>
        public const bool Failed = false;
    }
}
