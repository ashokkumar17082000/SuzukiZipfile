﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace SUZUKIDA3.Model.CommonModels
{
    /* public interface IEntity
     {
         DateTime CreatedAt { get; set; }
         String CreatedBy { get; set; }
         String ModfiedBy { get; set; }

         DateTime ModifiedAt { get; set; }
         Boolean Status { get; set; }
     }
    */

    public class EntityBase
    {
        public Guid RefId { get; private set; }

        public string? CreatedBy { get; set; }

        public DateTime? CreatedAt { get; private set; }

        public string? ModfiedBy { get; set; }

        public DateTime? ModifiedAt { get; set; }

        [Column(TypeName = "int")]
        [JsonPropertyName("IsActive")]
        public EntityStatus EntityStatus { get; set; }

        public EntityBase()
        {
            RefId = Guid.NewGuid();
            CreatedAt = DateTime.UtcNow;
            EntityStatus = EntityStatus.Active;

        }

        public void ArchiveEntity()
        {
            EntityStatus = EntityStatus.Archived;
        }

        public void DeleteEntity()
        {
            EntityStatus = EntityStatus.Deleted;
        }

        public void ActivateEntity()
        {
            EntityStatus = EntityStatus.Active;
        }

        public void OnEntityModified()
        {
            ModifiedAt = DateTime.UtcNow;
        }
    }
    public enum EntityStatus
    {
        Archived = 0,
        Active = 1,
        Deleted = 2
    }

    public enum Role
    {
        SuperAdmin = 0,
        Admin = 1,
        Dealer = 2
    }
}
