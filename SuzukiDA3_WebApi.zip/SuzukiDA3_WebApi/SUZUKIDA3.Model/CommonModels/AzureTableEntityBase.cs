﻿using Azure;
using Azure.Data.Tables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.CommonModels
{
    /// <summary>
    /// Azure Table base class
    /// </summary>
    /// <seealso cref="Azure.Data.Tables.ITableEntity" />
    public class AzureTableEntityBase : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public AzureTableEntityBase()
        {
            Timestamp = DateTimeOffset.UtcNow;

        }
    }
}
