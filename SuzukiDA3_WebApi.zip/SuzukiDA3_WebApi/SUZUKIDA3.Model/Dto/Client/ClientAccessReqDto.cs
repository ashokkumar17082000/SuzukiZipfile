﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.Client
{
    public class ClientAccessReqDto
    {
        public string CleintBaseUrl { get; set; } = string.Empty;
        public string LoginUrl { get; set; } = string.Empty;

        public string ClientExternalStorageUrl { get; set; } = string.Empty;

        public bool IsMTLS { get; set; }


        public string ClientCheckForUpdateUrl { get; set; } = string.Empty;

        public string ClientDownloadSoftware { get; set; } = string.Empty;

        public string ReportUpload { get; set; } = string.Empty;


    }
}
