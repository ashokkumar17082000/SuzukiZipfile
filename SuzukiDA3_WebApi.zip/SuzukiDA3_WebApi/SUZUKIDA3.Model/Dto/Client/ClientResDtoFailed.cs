﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.Client
{
    public class ClientResDtoFailed
    {
        public string key { get; set; } = string.Empty;
        public string httpError { get; set; } = string.Empty;
        public string localizedMessage { get; set; } = string.Empty;

    }
}
