﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.Client
{
    public class LoginResDto
    {
        public string id { get; set; } = string.Empty;      
        public string sessionId { get; set; } = string.Empty;
        public string domainName { get; set; } = string.Empty;
        public string domainPin { get; set; } = string.Empty;
        public string firstName { get; set; } = string.Empty;
        public string lastName { get; set; } = string.Empty;
    }
}
