﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto
{
    public class OSFeatureReqDto
    {
       
        public int? manufactureID { get; set; }
        public int? deviceID { get; set; }
        public int? osID { get; set; }
        public string? languageCode { get; set; }

    }
}
