﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.SoftwareUpdate
{
    public class SoftwareInfo
    {
        public string deviceID { get; set; }
        public string operationId { get; set; }
        public string campaignName { get; set; }
        public string softwareVersion { get; set; }
        public string softwareName { get; set; }
    }
}
