﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.SoftwareUpdate
{
    public class SoftwareErrorResponseDto
    {
        public ErrorCode Code { get; set; }
        public string? Message { get; set; }
        public ErrorCode ErrorCode { get; set; }
    }



    public enum ErrorCode
    {
        BadRequest = 400,
        Unauthorized = 401,
        Forbidden = 403,
        NotFound = 404,
        InternalServerError = 500,

        FileNotFound = 550,
        UpdateNotAvailable = 551,
        CorruptedFile = 552,
        ServerAuthFail = 553,
        FetchCredentialsFailed = 559,
        ClientAuthenticationFailed = 560,
        ReportUpdateSuccess = 800,


        DownloadFailed= 600

        
    }
}
