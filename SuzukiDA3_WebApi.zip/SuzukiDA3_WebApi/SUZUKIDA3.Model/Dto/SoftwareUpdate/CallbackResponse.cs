﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto.SoftwareUpdate
{
    public class CallbackResponse
    {
        public string? requestId { get; set; }
        public string? status { get; set; }
        public string? errorKey { get; set; }
        public string? errorMessage { get; set; }

        public string? downloadFileUrl { get; set; }
        public long downloadFileSize { get; set; }
        public string? CallBackRecivedFromHarman { get; set; }
    }
}
