﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.Dto
{
    public class TempLoginReqDto
    {
        public string? UserId {  get; set; }
    }
}
