﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableAndroidAuto : AzureTableEntityBase
    {
        public string? LanguageCode { get; set; }
       public string? content { get; set; }

        public int EntityStatus { get; set; }
       public string url_ref { get; set; }

    }
}
