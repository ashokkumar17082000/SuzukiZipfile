﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableCallback : AzureTableEntityBase
    {
        public string? UserErrorMessage { get; set; }
        public string? Status { get; set; }
        public string? ErrorKey { get; set; }
        public string? ErrorMessage { get; set; }
        public string? DownloadFileUrl { get; set; }
        public string? RequestId { get; set; }

        public long DownloadFileSize { get; set; }
        public string? CallBackRecivedFromHarman { get; set; }
        public string? CallBackRequestToHarman { get; set; }
        public string? DownloadStartFromHarman { get; set; }
        public string? Environment { get; set; }
        public string? InventoryDescription { get; set; }
        public string? UploadToBlob { get; set; }


    }
}
