﻿using Microsoft.AspNetCore.Http;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace SUZUKIDA3.Model.DataModel
{
    [Table("SoftwareUpdateTracker")]
    public class SoftwareUpdate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SoftwareTrackerID { get; set;}
        
        
        [NotMapped]
        public IFormFile? InfotainmentFile { get; set;}

        public DateTime Created { get; set;}

        public bool IsSuccess { get; set;}

        public SoftwareUpdate()
        {
            Created = DateTime.Now;
        }

    }
}
