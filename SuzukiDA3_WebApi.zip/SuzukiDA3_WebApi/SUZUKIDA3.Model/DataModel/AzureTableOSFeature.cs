﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableOSFeature : AzureTableEntityBase
    {
        public int? DeviceID { get; set; }
        public int? ManufacturerID { get; set; }

        public int? OSID { get; set; }
        public int? FeatureID { get; set; }
        public int? OSFeatureStatus { get; set; }
        public int? EntityStatus { get; set; }



    }
}
