﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableUserManualCountryModel : AzureTableEntityBase
    {
        public string? Country { get; set; }
        public int CountryID { get; set; }
        //public int ModelCodeId { get; set; }
        public int DestinationID { get; set; }
        public string? Destination { get; set; }
        public string? ModelCode { get; set; }

    }
}
