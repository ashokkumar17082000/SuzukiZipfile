﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableFeatureLanguage: AzureTableEntityBase
    {
        [JsonPropertyName("FeatureLanguageID")]
        public string? PartitionKey { get; set; }

        public string? FeatureCategory { get; set; }
        public string? FeatureName { get; set; }
        public int? FeatureRefID { get; set; }
        public string? LanguageCode { get; set; }
    }
}
