﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableUserCode : AzureTableEntityBase
    {
        public string? ValidationCode { get; set; }
        public string? EmailId { get; set; }

        public AzureTableUserCode()
        {
            PartitionKey = "UserCodeValidation";
            RowKey = Guid.NewGuid().ToString();
        }
    }
}
