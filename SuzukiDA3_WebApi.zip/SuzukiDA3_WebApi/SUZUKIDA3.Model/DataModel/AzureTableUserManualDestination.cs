﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableUserManualDestination : AzureTableEntityBase
    {
        public string? UserManualName { get; set; }
        public int UserManualID { get; set; }
        public int DestinationID { get; set; }
        public string? UserManualUrl { get; set; }

        public string? Language { get; set; }

    }
}
