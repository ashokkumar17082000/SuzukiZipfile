﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableUserManualList : AzureTableEntityBase
    {
        public string? CountryName { get; set; }
        public int EntityStatus { get; set; }
        public string? DefaultLanguage { get; set; }
        public string? Destination { get; set; }
        public string? FileSize { get; set; }
        public int CountryID { get; set; }
        public string? Language { get; set; }
        public string? ModelCode { get; set; }
        public int DestinationID { get; set; }
        public int ModelCodeID { get; set; }
        public string? Modelcodename_year { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string? PartNumber { get; set; }
        public int UserManualID { get; set; }
        public string? UserManualName { get; set; }
        public string? UserManualUrl { get; set; }

    }
}
