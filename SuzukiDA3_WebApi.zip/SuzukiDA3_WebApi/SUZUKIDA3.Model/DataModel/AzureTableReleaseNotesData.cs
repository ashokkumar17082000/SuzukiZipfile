﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableReleaseNotesData : AzureTableReleaseNotes
    {
        public string? languageCode { get; set; }
        public string? content { get; set; }
        public string? notes { get; set; }
        
    }
}
