﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    [Table("NLogs")]
    public class NLogTable
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public string? Application { get; set; }
        public string? Level { get; set; }
        public string? Message { get; set; }
        public string? Logger { get; set; }
        public string? Callsite { get; set; }
        public string? Exception { get; set; }
        public string? Logged { get; set; }
        public DateTime? CreatedAt { get; private set; }

        public NLogTable()
        {
            CreatedAt = DateTime.UtcNow;
        }
    }
}
