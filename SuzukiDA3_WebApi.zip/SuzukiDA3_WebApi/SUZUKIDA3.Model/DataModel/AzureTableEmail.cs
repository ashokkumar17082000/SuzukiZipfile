﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableEmail : AzureTableEntityBase
    {
        public string? MemberName { get; set; }
        public string? MemberValue { get; set; }
        public AzureTableEmail() {
            PartitionKey = "Email";
            RowKey = Guid.NewGuid().ToString();
        }
    }
}
