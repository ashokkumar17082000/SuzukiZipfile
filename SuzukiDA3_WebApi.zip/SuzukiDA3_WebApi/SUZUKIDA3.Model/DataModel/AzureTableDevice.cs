﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
   public class AzureTableDevice : AzureTableEntityBase
   {
        public int Order { get; set; }
        public string? DeviceName { get; set; }
        public int ManufacturerRefId { get; set; }
        public string? CreatedBy { get; set; }

        public int EntityStatus { get; set;}
   }
}
