﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableFeature: AzureTableEntityBase
    {
      
        public string? Feature { get; set; }  
        public string? FeatureCategory { get; set; }  
        public int FeatureEntityStatus { get; set; }  
        public int? FeatureOrder { get; set; }  
        public int? Order { get; set; }  


    }
}
