﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
   public class AzureTableDCManufacturer : AzureTableEntityBase
   {
        public int Order { get; set; }
        public string? ManufacturerName { get; set; }
        public int RegionId { get; set; }

        public int EntityStatus { get; set;}
   }
}
