﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableModel : AzureTableEntityBase
    {
           public string? ModelName { get; set; }
           public string? ModelCode { get; set; }
           public int Order { get; set; }
           public string? ModelGroup { get; set; }
           public int ModelGroupOrder { get; set; }
           public int EntityStatus { get; set; }
        
    }
}
