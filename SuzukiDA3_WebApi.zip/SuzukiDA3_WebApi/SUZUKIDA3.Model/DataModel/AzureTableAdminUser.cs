﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableAdminUser : AzureTableEntityBase
    {
        public string? PasswordHash { get; set; }
        public string? UserId { get; set; }
        public bool? IsAdmin { get; set; }
        public string? DisplayName { get; set; }

        public string? EntityStatus { get; set; }

    }
}
