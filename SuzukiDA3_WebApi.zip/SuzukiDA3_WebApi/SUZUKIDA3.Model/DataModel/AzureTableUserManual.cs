﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableUserManual : AzureTableEntityBase
    {
        public string? ManualLanguage { get; set; }
        public int EntityStatus { get; set; }
        public string? ModelCode { get; set; }
        public string? ManualPath { get; set; }
        
    }
}
