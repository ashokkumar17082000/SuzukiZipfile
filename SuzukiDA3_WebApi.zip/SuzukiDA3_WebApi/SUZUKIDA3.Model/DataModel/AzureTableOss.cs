﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableOss : AzureTableEntityBase
    {
        public string? softwareVersion { get; set; }
        public string? softwareName { get; set; }
        public string? downloadOSSBundle { get; set; }
        public string? downloadOSSLicense { get; set; }

        public int EntityStatus { get; set; }

    }
}
