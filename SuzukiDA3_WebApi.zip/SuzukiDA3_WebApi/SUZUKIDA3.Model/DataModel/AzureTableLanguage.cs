﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
   public class AzureTableLanguage : AzureTableEntityBase
   {
        public string? LanguageDisplayName { get; set; }
        public string? LanguageCode { get; set; }

        public int EntityStatus { get; set;}

        public int Order { get; set; }
    }
}
