﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableReleaseNotes : AzureTableEntityBase
    {
        public string? softwareVariant { get; set; }
        public int EntityStatus { get; set; }
        public string? softwareVersion { get; set; }
        
    }
}
