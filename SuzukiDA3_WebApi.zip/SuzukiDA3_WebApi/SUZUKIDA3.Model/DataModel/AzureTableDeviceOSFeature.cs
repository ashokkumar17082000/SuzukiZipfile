﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableDeviceOSFeature: AzureTableEntityBase
    {
        public string FeatureID { get; set; }

        public string? Category {  get; set; }
        public string? FeatureCategory { get; set; }
        public string? Feature { get; set; }
        public string? FeatureName { get; set; }
        public int? OSFeatureStatus { get; set; }
        public string? ImageUrl { get; set; }
        public int? FeatureEntityStatus { get; set; }
        public int? EntityStatus { get; set; }
        public int? Order { get; set; }

        public int? FeatureOrder {  get; set; }
    }
}
