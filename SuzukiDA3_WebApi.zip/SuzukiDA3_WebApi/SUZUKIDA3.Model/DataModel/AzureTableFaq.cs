﻿using SUZUKIDA3.Model.CommonModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Model.DataModel
{
    public class AzureTableFaq : AzureTableEntityBase, IComparable<AzureTableFaq>
    {
        public string? Answer { get; set; }
        public string? LanguageCode { get; set; }
        public string? Question { get; set; }
        public string? content { get; set; }

        public int EntityStatus { get; set; }
        public int FaqOrderCode { get; set; }
        public int HasContent { get; set; }

        public int CompareTo(AzureTableFaq? other)
        {
            return this.FaqOrderCode.CompareTo(other.FaqOrderCode);
        }
    }
}
