﻿using Azure.Security.KeyVault.Secrets;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Configuration;

namespace SUZUKIDA3.WebApi.Helpers
{
    public class KeyVaultManager : IKeyVaultManager
    {
        private readonly SecretClient _secretClient;
        private readonly ILogger<KeyVaultManager> _logger;
        private readonly IConfiguration _configuration;
        private readonly Dictionary<string, string> _secrets;
        public KeyVaultManager(SecretClient secretClient, ILogger<KeyVaultManager> logger,IConfiguration configuration)
        {
            _secretClient = secretClient;
            _logger = logger;
            _configuration = configuration;
            _secrets = LoadSecretsFromKeyVault();
        }
        public async Task<string> GetSecret(string secretName)
        {
            try
            {
                _logger.LogInformation(string.Format("Calling Key Vault for Key: {0}", secretName));
                if (_secrets.TryGetValue(secretName, out var keyvalue))
                {
                   // _logger.LogInformation($"Loading Keys from Dictionary {keyvalue}");
                    return keyvalue;
                }

                KeyVaultSecret keyValueSecret = await _secretClient.GetSecretAsync(secretName);

                return keyValueSecret.Value;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
            return string.Empty;
        }

        public string GetSecretKey(string secretName)
        {
            _logger.LogInformation($"{_secrets.Count}");
            if (_secrets.TryGetValue(secretName, out var keyvalue))
            {
               // _logger.LogInformation($"Loading Keys from Dictionary {keyvalue}");
                return keyvalue;
            }
            else
            {
                _logger.LogInformation(string.Format("Key Not Found in dcitionary KeyVault: {0}", secretName));
                string value = _configuration.GetValue<string>(secretName);
                if (!string.IsNullOrWhiteSpace(value))
                {
                    //_logger.LogInformation(string.Format("Key KeyValue from config: {0}", secretName));
                    return value;
                }
            }

            return string.Empty;
        }

        private Dictionary<string, string> LoadSecretsFromKeyVault()
        {
            var secrets = new Dictionary<string, string>();
            try
            {

                foreach (var secret in _secretClient.GetPropertiesOfSecrets())
                {
                    var secretValue = _secretClient.GetSecret(secret.Name).Value.Value;
                   // _logger.LogInformation($"Fected secrect Value is: {secretValue}");
                    secrets.Add(secret.Name, secretValue);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }
            return secrets;
        }

        public Dictionary<string, string> TestReturnAllLoadedKeyVaultData()
        {
            return _secrets;
        }
    }
}
