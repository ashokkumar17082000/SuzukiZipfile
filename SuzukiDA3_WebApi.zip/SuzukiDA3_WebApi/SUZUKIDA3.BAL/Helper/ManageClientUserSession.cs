﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.Dto.Client;
using System.Net;


namespace SUZUKIDA3.BAL.Helper
{
    public class ManageClientUserSession : IManageClientUserSession
    {
        private readonly IMemoryCache _memoryCache;
        private readonly IConfiguration _config;
        private readonly IMtlsCertifcateValidator _certificateValidator;
        private readonly IKeyVaultManager _secretManager;
        private bool IsMTLSRequired = false;


        public ManageClientUserSession(IMemoryCache memoryCache, IConfiguration config, IMtlsCertifcateValidator certificateValidator, IKeyVaultManager secretManager)
        {
            _memoryCache = memoryCache;
            _config = config;
            _certificateValidator = certificateValidator;
            _secretManager = secretManager;
            IsMTLSRequired = _secretManager.GetSecretKey(DA3Constants.ClientMTLS) == "1" ? true : false;
        }

        public ClientAccessReqDto GetClientConnectData()
        {
            string baseUrl = _config.GetValue<string>(DA3Constants.ClientBaseURIKey);
            if (!string.IsNullOrWhiteSpace(baseUrl))
            {
                string externalstorageUrl = baseUrl + "api/v1.0/externalStorage/";
                var clientData = new ClientAccessReqDto()
                {
                    IsMTLS = IsMTLSRequired,
                    CleintBaseUrl = baseUrl,
                    ClientExternalStorageUrl = externalstorageUrl
                };
                clientData.LoginUrl = clientData.CleintBaseUrl + "api/login";
                clientData.ReportUpload = clientData.ClientExternalStorageUrl + "uploadReport";
                clientData.ClientCheckForUpdateUrl = clientData.ClientExternalStorageUrl + "createPackageByInventory";
                clientData.ClientDownloadSoftware = clientData.ClientExternalStorageUrl + "{0}/download";

                return clientData;
            }
            return null;

        }

        public string getClientSessionID()
        {
            _memoryCache.TryGetValue(DA3Constants.ClientLoginUserSessionIdSaveKey, out string session);
            return session != null ? session : string.Empty;
        }

        public void setClientSessionId(string sessionIdValue)
        {
            var cacheEntryOptions = new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15)
            };
            _memoryCache.Set(DA3Constants.ClientLoginUserSessionIdSaveKey, sessionIdValue, cacheEntryOptions);
        }

        public List<KeyValuePair<string, string>> getCredentials()
        {
            var formData = new List<KeyValuePair<string, string>>();


            string clientUsernameValue = _secretManager.GetSecretKey(DA3Constants.ClientUserNameValue);

            if (!string.IsNullOrWhiteSpace(DA3Constants.ClientUserNameKey) && !string.IsNullOrWhiteSpace(clientUsernameValue))
            {
                formData.Add(new KeyValuePair<string, string>(DA3Constants.ClientUserNameKey, clientUsernameValue));
            }

            string clienPasswordValue = _secretManager.GetSecretKey(DA3Constants.ClientPasswordValue);

            if (!string.IsNullOrWhiteSpace(DA3Constants.ClientPasswordNameKey) && !string.IsNullOrWhiteSpace(clienPasswordValue))
            {
                formData.Add(new KeyValuePair<string, string>(DA3Constants.ClientPasswordNameKey, clienPasswordValue));

            }
            string clienDomainValue = _secretManager.GetSecretKey(DA3Constants.ClientDomainValue);

            if (!string.IsNullOrWhiteSpace(DA3Constants.ClientDomainNameKey) && !string.IsNullOrWhiteSpace(clienDomainValue))
            {
                formData.Add(new KeyValuePair<string, string>(DA3Constants.ClientDomainNameKey, clienDomainValue));

            }
            return formData;
        }

        public List<KeyValuePair<string, string>> getCredentialsOld()
        {
            var formData = new List<KeyValuePair<string, string>>();

            var creds = _config.GetSection("ClientConnect").GetSection("cred").Get<Dictionary<string, string>>();
            if (creds != null)
            {
                foreach (var kvp in creds)
                {
                    formData.Add(new KeyValuePair<string, string>(kvp.Key, kvp.Value));
                }
            }
            return formData;
        }

        public void handle_MTLS_validation(bool begin)
        {
            if (begin)
            {
                ServicePointManager.ServerCertificateValidationCallback += _certificateValidator.ValidateServerCertificate;

            }
            else
            {
                ServicePointManager.ServerCertificateValidationCallback -= _certificateValidator.ValidateServerCertificate;
            }
        }
        public HttpClient CreateHttpClient()
        {
            if (IsMTLSRequired)
            {
                var serverCertificate = _certificateValidator.GetClientCertificate();
                return new HttpClient(new HttpClientHandler()
                {
                    ClientCertificates = { serverCertificate },
                    ServerCertificateCustomValidationCallback = _certificateValidator.ValidateCertificate
                });
            }

            return new HttpClient();
        }

        private MultipartFormDataContent getFormContent(IFormFile file)
        {
            var formData = new MultipartFormDataContent();
            using (Stream fileStream = file.OpenReadStream())
            {
                StreamContent streamcontent = new StreamContent(fileStream);
                fileStream.Position = 0;
                formData.Add(streamcontent, "file", file.FileName);
            }
            return formData;
        }

        public string getFileNameFromContentDisposition(System.Net.Http.Headers.ContentDispositionHeaderValue contentDisposition)
        {
            string filename = "SUZUKI_Software_download.zip";

            if (!string.IsNullOrWhiteSpace(_config.GetValue<string>(DA3Constants.SOFTWARE_DOWNLOAD_FileName)))
            {
                filename = _config.GetValue<string>(DA3Constants.SOFTWARE_DOWNLOAD_FileName);
            }

            if (contentDisposition != null && !string.IsNullOrEmpty(contentDisposition.FileName))
            {
                filename = contentDisposition.FileName;

                if (!string.IsNullOrEmpty(filename) && filename.Length > 1 && filename.IndexOf("\\") > 0)
                {
                    filename = filename.Trim('\\');
                }
            }
            return filename;
        }

    }
}
