﻿using System;
using System.IO;
using System.IO.Compression;
using System.IO.Pipelines;
using System.Reflection.Metadata;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;

namespace SUZUKIDA3.BAL.Helper
{
    public class ZipEncryptionService : IZipEncryptionHelper
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<ZipEncryptionService> _logger;
        private readonly IAsymetricCryptographicService _encryptionDecryptService;

        public ZipEncryptionService(IConfiguration configuration, ILogger<ZipEncryptionService> logger, IAsymetricCryptographicService encryptionDecryptService)
        {

            _logger = logger;
            _encryptionDecryptService = encryptionDecryptService;
            _configuration = configuration;

        }

        public async Task<Stream> EncryptZipContents(Stream stream)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                try
                {
                    await stream.CopyToAsync(ms);
                    ms.Position = 0;
                    using (var archive = new ZipArchive(ms, ZipArchiveMode.Update))
                    {
                        var jsonEntry = archive.Entries
                     .FirstOrDefault(entry => entry.FullName.EndsWith("_dd.json", StringComparison.OrdinalIgnoreCase));
                        if (jsonEntry != null)
                        {
                            using (var entryStream = jsonEntry.Open())
                            {
                                var encryptedJsondataArry = await _encryptionDecryptService.EncryptStream(entryStream);
                                entryStream.SetLength(0); // Clear existing content
                                entryStream.Write(encryptedJsondataArry, 0, encryptedJsondataArry.Length);
                            }
                        }
                    }

                    var updatedMemoryStream = new MemoryStream(ms.ToArray());

                    updatedMemoryStream.Position = 0;

                    return updatedMemoryStream;
                   

                }
                catch (Exception ex)
                {
                    _logger.LogError("Excpetion while encrypting the response zip file.", ex);
                    return ms;
                }
            }
        }






    }
}
