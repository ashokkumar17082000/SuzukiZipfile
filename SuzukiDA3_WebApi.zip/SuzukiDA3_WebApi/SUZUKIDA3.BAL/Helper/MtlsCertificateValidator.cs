﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace SUZUKIDA3.BAL.Helper
{
    public class MtlsCertificateValidator : IMtlsCertifcateValidator
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<MtlsCertificateValidator> _logger;
        private readonly string CertificatePath_ossl = @"C:\\Hari\\Projects\\SUZUKIDA3\\MTLS test\\Certificates\\client-cert.pfx";
        private readonly string CertificatePath = @"C:\\Hari\\Projects\\SUZUKIDA3\\MTLS test\\WithPowerShell\\clientcert.pfx";

        public MtlsCertificateValidator(IConfiguration configuration, ILogger<MtlsCertificateValidator> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public X509Certificate2 GetClientCertificate()
        {
            X509Certificate2 clientcertifcate = new X509Certificate2(CertificatePath, DA3Constants.CertificatePasswordValue);
            bool isCertifcateValid = IsClientCertificateValid(clientcertifcate);
            if (!isCertifcateValid) return null;

            return clientcertifcate;
        }

        public bool IsClientCertificateValid(X509Certificate2 certificate)
        {
            if (certificate == null)
            {
                return false;
            }
            if (certificate.NotAfter < DateTime.UtcNow)
            {
                return false;
            }



            return true;
        }

        public bool ValidateCertificate(HttpRequestMessage httpRequestMessage, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {

            if (certificate == null)
            {
                return false;
            }
            if (certificate.Issuer == "")
            {
                return false;
            }

            var allowedThumbprints = _configuration.GetSection("Certificates").Get<Dictionary<string, string>>();

            if (allowedThumbprints.Count == 0)
            {
                _logger.LogInformation("No Certificates Present.");
                return false;
            }

            if (!allowedThumbprints.Values.Contains(certificate.GetPublicKeyString()))
            {
                _logger.LogInformation("InValid");
                return false;
            }
            _logger.LogInformation("Certificate is Valid");
            return true;

        }


        public bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
            if (certificate == null)
            {
                return false;
            }
            if (certificate.Issuer == "")
            {
                return false;
            }

            var allowedThumbprints = _configuration.GetSection("Certificates").Get<Dictionary<string, string>>();

            if (allowedThumbprints.Count == 0)
            {
                _logger.LogInformation("No Certificates Present.");
                return false;
            }

            if (!allowedThumbprints.Values.Contains(certificate.GetPublicKeyString()))
            {
                _logger.LogInformation("InValid");
                return false;
            }
            _logger.LogInformation("Certificate is Valid");
            return true;

        }
    }
}
