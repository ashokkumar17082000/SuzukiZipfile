﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace SUZUKIDA3.BAL.Helper
{
    public class AsymetricEncryptionService : IAsymetricCryptographicService
    {
        private readonly IConfiguration _config;
        private readonly IKeyVaultManager _secrectManager;
        private readonly string privatekey;
        private readonly string publickey;

        public AsymetricEncryptionService(IConfiguration config, IKeyVaultManager secrectManager)
        {
            _config = config;
            _secrectManager = secrectManager;
            privatekey = _secrectManager.GetSecretKey(DA3Constants.PrivateKey);
            publickey = _secrectManager.GetSecretKey(DA3Constants.PublicKey);

        }

        public async Task<Stream> DecryptFile(IFormFile file)
        {
            try
            {
                using (StreamReader reader = new StreamReader(file.OpenReadStream()))
                {
                    string fileContents = await reader.ReadToEndAsync();
                    var jsonObj = JsonConvert.DeserializeObject<InfotainmentDataModel>(fileContents);
                    if (jsonObj != null && jsonObj.data != null)
                    {
                        byte[] encryptedData = Convert.FromBase64String(jsonObj.data);
                        RSAParameters privateKey = RSAParametersFromBase64String(privatekey);

                        // Extract the encrypted AES key, IV, and data
                        int keySize = 4096 / 8;
                        int ivSize = 4096 / 8;
                        byte[] encryptedAesKey = new byte[keySize];
                        byte[] encryptedAesIV = new byte[ivSize];
                        byte[] encryptedActualData = new byte[encryptedData.Length - keySize - ivSize];
                        if (encryptedData.Length > keySize + ivSize)
                        {
                            Buffer.BlockCopy(encryptedData, 0, encryptedAesKey, 0, keySize);
                            Buffer.BlockCopy(encryptedData, keySize, encryptedAesIV, 0, ivSize);
                            Buffer.BlockCopy(encryptedData, keySize + ivSize, encryptedActualData, 0, encryptedActualData.Length);
                            // Decrypt the AES key and IV with RSA
                            byte[] aesKey = DecryptWithRsa4096(encryptedAesKey, privateKey);
                            byte[] aesIV = DecryptWithRsa4096(encryptedAesIV, privateKey);

                            // Decrypt the data with AES
                            byte[] decryptedData = DecryptWithAes(encryptedActualData, aesKey, aesIV);
                            Stream decryptedStream = new MemoryStream(decryptedData);
                            return decryptedStream;
                        }
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public async Task<Stream> EncryptFile(IFormFile file)
        {

            try
            {
                //Stream encryptedstream =  new MemoryStream();
                using (var memoryStream = new MemoryStream())
                {
                    await file.CopyToAsync(memoryStream);
                    byte[] jsonDataBytes = memoryStream.ToArray();

                    RSAParameters publicKey = RSAParametersFromBase64String(publickey);

                    // Generate a random AES key and IV
                    using (Aes aesAlg = Aes.Create())
                    {
                        aesAlg.GenerateKey();
                        aesAlg.GenerateIV();

                        // Encrypt the data with AES
                        byte[] encryptedData = EncryptWithAes(jsonDataBytes, aesAlg.Key, aesAlg.IV);

                        // Encrypt the AES key and IV with RSA
                        byte[] encryptedAesKey = EncryptWithRsa4096(aesAlg.Key, publicKey);
                        byte[] encryptedAesIV = EncryptWithRsa4096(aesAlg.IV, publicKey);

                        // Combine the encrypted AES key, IV, and data
                        byte[] finalData = CombineArrays(encryptedAesKey, encryptedAesIV, encryptedData);
                        string finalText = Convert.ToBase64String(finalData);
                        var item = new InfotainmentDataModel { data = finalText };
                        var jsondata = JsonConvert.SerializeObject(item);
                        byte[] transmit = Encoding.UTF8.GetBytes(jsondata);
                        Stream encryptedStream = new MemoryStream(transmit);

                        return encryptedStream;
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<byte[]> EncryptStream(Stream mStream)
        {
            try
            {

                using (var memoryStream = new MemoryStream())
                {
                    await mStream.CopyToAsync(memoryStream);
                    byte[] jsonDataBytes = memoryStream.ToArray();
                    RSAParameters publicKey = RSAParametersFromBase64String(publickey);
                    // Generate a random AES key and IV
                    using (Aes aesAlg = Aes.Create())
                    {
                        aesAlg.GenerateKey();
                        aesAlg.GenerateIV();

                        // Encrypt the data with AES
                        byte[] encryptedData = EncryptWithAes(jsonDataBytes, aesAlg.Key, aesAlg.IV);

                        // Encrypt the AES key and IV with RSA
                        byte[] encryptedAesKey = EncryptWithRsa4096(aesAlg.Key, publicKey);
                        byte[] encryptedAesIV = EncryptWithRsa4096(aesAlg.IV, publicKey);

                        // Combine the encrypted AES key, IV, and data
                        byte[] finalData = CombineArrays(encryptedAesKey, encryptedAesIV, encryptedData);
                        string finalText = Convert.ToBase64String(finalData);
                        var item = new InfotainmentDataModel { data = finalText };
                        var jsondata = JsonConvert.SerializeObject(item);
                        byte[] transmit = Encoding.UTF8.GetBytes(jsondata);
                        return transmit;
                       
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        private static byte[] EncryptWithRsa4096(byte[] data, RSAParameters publicKey)
        {
            using (RSA rsa = RSA.Create(4096))
            {
                rsa.ImportParameters(publicKey);
                return rsa.Encrypt(data, RSAEncryptionPadding.OaepSHA512);
            }
        }

        private static byte[] DecryptWithRsa4096(byte[] data, RSAParameters privateKey)
        {
            using (RSA rsa = RSA.Create(4096))
            {
                rsa.ImportParameters(privateKey);
                return rsa.Decrypt(data, RSAEncryptionPadding.OaepSHA512);
            }
        }

        private static byte[] EncryptWithAes(byte[] data, byte[] key, byte[] iv)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = key;
                aesAlg.IV = iv;

                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, aesAlg.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        csEncrypt.Write(data, 0, data.Length);
                        csEncrypt.FlushFinalBlock();
                    }

                    return msEncrypt.ToArray();
                }
            }
        }

        private static byte[] DecryptWithAes(byte[] data, byte[] key, byte[] iv)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = key;
                aesAlg.IV = iv;
                using (MemoryStream msDecrypt = new MemoryStream())
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, aesAlg.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        csDecrypt.Write(data, 0, data.Length);
                        csDecrypt.FlushFinalBlock();
                    }

                    return msDecrypt.ToArray();
                }
            }
        }

        private static byte[] CombineArrays(byte[] array1, byte[] array2, byte[] array3)
        {
            byte[] result = new byte[array1.Length + array2.Length + array3.Length];
            Buffer.BlockCopy(array1, 0, result, 0, array1.Length);
            Buffer.BlockCopy(array2, 0, result, array1.Length, array2.Length);
            Buffer.BlockCopy(array3, 0, result, array1.Length + array2.Length, array3.Length);
            return result;
        }
        private static RSAParameters RSAParametersFromBase64String(string base64String)
        {
            string[] parts = base64String.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length > 2)
            {
                return new RSAParameters
                {
                    Modulus = Convert.FromBase64String(parts[0]),
                    Exponent = Convert.FromBase64String(parts[1]),
                    D = Convert.FromBase64String(parts[2]),
                    P = Convert.FromBase64String(parts[3]),
                    Q = Convert.FromBase64String(parts[4]),
                    DP = Convert.FromBase64String(parts[5]),
                    DQ = Convert.FromBase64String(parts[6]),
                    InverseQ = Convert.FromBase64String(parts[7])
                };

            }
            return new RSAParameters
            {
                Modulus = Convert.FromBase64String(parts[0]),
                Exponent = Convert.FromBase64String(parts[1]),
            };
        }

        public class InfotainmentDataModel
        {
            public string data { get; set; }
        }
    }
}
