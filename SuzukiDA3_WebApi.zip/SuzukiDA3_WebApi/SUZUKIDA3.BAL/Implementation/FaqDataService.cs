﻿using Azure.Data.Tables;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.BAL.Implementation
{
    public class FaqDataService : IFaqDataAzureTableService
    {
        private readonly IConfiguration _configuration;

        public FaqDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_Faq]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientAndroid()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_Android_Auto]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        /// <summary>
        /// Gets the Certificate data.
        /// </summary>
        /// <returns></returns>
        public async Task<List<AzureTableFaq>> GetFaqData(string lanCode)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableFaq>(x=>x.LanguageCode==lanCode.ToLower());
            
            List<AzureTableFaq> FaqData = new List<AzureTableFaq>();
            await foreach (var item in record)
            {
                FaqData.Add(item);
            }

            if (FaqData.Count > 0)
            {
                FaqData.Sort();
                return FaqData;
            }

            return null;
        }
        public async Task<List<AzureTableAndroidAuto>> GetAndroidAutoData(string languageCode,string url)
        {
            TableClient tableClient = await this.GetTableClientAndroid();
            var record = tableClient.QueryAsync<AzureTableAndroidAuto>(x => x.LanguageCode == languageCode.ToLower() && x.url_ref==url);

            List<AzureTableAndroidAuto> AndroidAutoData = new List<AzureTableAndroidAuto>();
            await foreach (var item in record)
            {
                AndroidAutoData.Add(item);
            }

            if (AndroidAutoData.Count > 0)
                return AndroidAutoData;
            
            return null;
        }
    }
}
