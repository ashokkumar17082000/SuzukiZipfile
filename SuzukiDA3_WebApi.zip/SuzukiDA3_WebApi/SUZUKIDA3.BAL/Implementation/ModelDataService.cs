﻿using Azure.Data.Tables;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.BAL.Implementation
{
    public class ModelDataService : IModelList
    {
        private readonly IConfiguration _configuration;

        public ModelDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_MODEL]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        /// <summary>
        /// Gets the email data.
        /// </summary>
        /// <param name="memberName">Name of the member.</param>
        /// <returns></returns>
        
        public async Task<List<AzureTableModel>> GetModelList()
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableModel>();
            List<AzureTableModel> ModelData = new List<AzureTableModel>();
            await foreach (var item in record)
            {
                ModelData.Add(item);
            }
            if (ModelData.Count > 0)
                return ModelData;

            return null;
        }
    }
}
