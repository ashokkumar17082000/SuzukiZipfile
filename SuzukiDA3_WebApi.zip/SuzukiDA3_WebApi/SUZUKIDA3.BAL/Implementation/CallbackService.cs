﻿using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using Azure.Communication.Email;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Azure.Core;
using System.Collections.Concurrent;

namespace SUZUKIDA3.BAL.Implementation
{
    public class CallbackService : ICallbackAzureTableService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CallbackService> _logger;
        public CallbackService(IConfiguration configuration, ILogger<CallbackService> logger)
        {
            _configuration = configuration;
            _logger = logger;   

        }
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_CALLBACK]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClient3()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DA3Logs]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientSession()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_Session]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClient2()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_CALLBACK_ERROR]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
       
        public async Task<bool> AddCallbackResponse(CallbackResponse callbackResponse, string id, string errorMessage)
        {
            AzureTableCallback item = await GetCallbackResponse(id);
            TableClient tableClient = await this.GetTableClient();
            Response response = null;
            if (item == null)
            {
                AzureTableCallback validationCodeItem = new AzureTableCallback { PartitionKey = DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString(), ETag = ETag.All, RowKey = id, DownloadFileSize = callbackResponse.downloadFileSize, DownloadFileUrl = callbackResponse.downloadFileUrl, ErrorKey = callbackResponse.errorKey, ErrorMessage = callbackResponse.errorMessage, RequestId = callbackResponse.requestId, Status = callbackResponse.status, UserErrorMessage = errorMessage, CallBackRecivedFromHarman = DateTime.Now.ToString() };
                
                response = await tableClient.AddEntityAsync<AzureTableCallback>(validationCodeItem);
            }
            else 
            {
                item.DownloadFileSize = callbackResponse.downloadFileSize;
                item.DownloadFileUrl = callbackResponse.downloadFileUrl;
                item.ErrorKey = callbackResponse.errorKey;
                item.ErrorMessage = callbackResponse.errorMessage;
                item.RequestId = callbackResponse.requestId;
                item.Status = callbackResponse.status;
                item.UserErrorMessage = errorMessage;
                item.CallBackRecivedFromHarman = DateTime.Now.ToString();
                response=await tableClient.UpdateEntityAsync(item, ETag.All, TableUpdateMode.Replace);
            }
            return !response.IsError;
        }
        public async Task<bool> AddSessionValidation(string EmailId,string AuthInstant, string SessionKey)
        {
                TableClient tableClient = await this.GetTableClientSession();
                var guid = Guid.NewGuid().ToString();

                AzureTableSession azureTableSession = new AzureTableSession { PartitionKey = DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString(), ETag = ETag.All, RowKey = guid,EmailId=EmailId,AuthInstant=AuthInstant,SessionKey=SessionKey };

                Response response = await tableClient.AddEntityAsync<AzureTableSession>(azureTableSession);
                return !response.IsError;
        }
        public async Task<bool> AddLogsData(string module, string id, string status,string logs)
        {
            
            TableClient tableClient = await this.GetTableClient3();
                AzureLogsData logsData = new AzureLogsData { PartitionKey = DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString(), ETag = ETag.All, RowKey = id,Status=status,GenericLogs=logs,Module=module};

                var response = await tableClient.AddEntityAsync<AzureLogsData>(logsData);
            return !response.IsError;
        }


        public async Task<AzureTableCallback> GetCallbackResponse(string id)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableCallback>(itm => itm.RowKey == id);
            List<AzureTableCallback> callbacks = new List<AzureTableCallback>();
            await foreach (var item in record)
            {
                callbacks.Add(item);
            }
            if (callbacks.Count > 0)
                return callbacks.FirstOrDefault();

            return null;
        }
        public async Task<AzureTableSession> GetSessionResponse(string emailId,string sessionKey)
        {
            TableClient tableClient = await this.GetTableClientSession();
            var record = tableClient.QueryAsync<AzureTableSession>(itm => itm.EmailId==emailId & itm.SessionKey==sessionKey);
            List<AzureTableSession> sessions = new List<AzureTableSession>();
            await foreach (var item in record)
            {
                sessions.Add(item);
            }
            if (sessions.Count > 0)
                return sessions.FirstOrDefault();

            return null;
        }
        public async Task<AzureTableCallbackError> GetCallbackError(string status, string errorKey)
        {
            TableClient tableClient = await this.GetTableClient2();
            var record = tableClient.QueryAsync<AzureTableCallbackError>(itm => itm.ErrorCode==errorKey.ToLower() && itm.Status==status.ToUpper());
            List<AzureTableCallbackError> errorMessage = new List<AzureTableCallbackError>();
            await foreach (var item in record)
            {
                errorMessage.Add(item);
            }
            if (errorMessage.Count > 0)
                return errorMessage.FirstOrDefault();

            return null;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="previousUserCode">The previous user code.</param>
        /// <param name="UserCode">The user code.</param>
        /// <returns></returns>
        public async Task<bool> UpdateCallbackresponse(string id, string InventoryDescription, string CallBackRequestToHarman, string DownloadStartFromHarman, string Environment, string UploadToBlob)
        {
            AzureTableCallback item = await GetCallbackResponse(id);
            TableClient tableClient = await this.GetTableClient();
            
            Response response = null;
            if (item == null)
            {
                AzureTableCallback azureTableCallback = new AzureTableCallback();
                azureTableCallback.RowKey = id;
                azureTableCallback.InventoryDescription = InventoryDescription;
                azureTableCallback.CallBackRequestToHarman = CallBackRequestToHarman;
                azureTableCallback.DownloadStartFromHarman = DownloadStartFromHarman;
                azureTableCallback.Environment = Environment;
                azureTableCallback.UploadToBlob = UploadToBlob;
                azureTableCallback.PartitionKey = DateTimeOffset.Now.ToUnixTimeMilliseconds().ToString();
                azureTableCallback.ETag = ETag.All;
                 response = await tableClient.AddEntityAsync<AzureTableCallback>(azureTableCallback);
                
            }
            else
            {
                item.InventoryDescription = InventoryDescription;
                item.CallBackRequestToHarman = CallBackRequestToHarman;
                item.DownloadStartFromHarman = DownloadStartFromHarman;
                item.Environment = Environment;
                item.UploadToBlob = UploadToBlob;
                response = await tableClient.UpdateEntityAsync(item, ETag.All, TableUpdateMode.Replace);
            }
            

            return !response.IsError;
        }
    }
}
