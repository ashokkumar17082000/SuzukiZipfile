﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Data.Tables;
using Azure.Storage.Sas;
using Azure.Storage;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;

namespace SUZUKIDA3.BAL.Implementation
{
    public class UserManualDataService : IUserManual
    {
        private readonly IConfiguration _configuration;
        private readonly string _storageAccountName = "sda3container";
        private readonly string _containerName = "sda3container";        
        private readonly string _storageAccountKey = "vODcQojfFruUfH/ipE+N11+sU3IjQhNwBTLRqVnRbd+i6rPxpjwHT52ZvWGmgfkQ3W4MoR0uw6iw+ASt3Ih4lQ==";

        public UserManualDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_USER_MANUAL]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientForCountry()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_COUNTRY_MASTER]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientForUserManualMaster()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_USERMANUAL_MASTER]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientCountryModel()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_COUNTRY_MODEL]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientModelCode()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_MODEL_CODE]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientDestinationLanguage()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DESTINATION_LANGUAGE]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        /// <summary>
        /// Gets the email data.
        /// </summary>
        /// <param name="memberName">Name of the member.</param>
        /// <returns></returns>
        public async Task<List<AzureTableUserManual>> GetUserManualList()
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableUserManual>();
            List<AzureTableUserManual> UserManualData = new List<AzureTableUserManual>();
            await foreach (var item in record)
            {
                UserManualData.Add(item);
            }
            if (UserManualData.Count > 0)
                return UserManualData;

            return null;
        }
        public async Task<List<AzureTableUserManualCountry>> GetCountryList()
        {
            TableClient tableClient = await this.GetTableClientForCountry();
            var record = tableClient.QueryAsync<AzureTableUserManualCountry>();
            List<AzureTableUserManualCountry> UserManualCountryData = new List<AzureTableUserManualCountry>();
            await foreach (var item in record)
            {
                UserManualCountryData.Add(item);
            }
            if (UserManualCountryData.Count > 0)
                return UserManualCountryData;

            return null;
        }
        public async Task<List<AzureTableUserManualList>> GetUserManualDataList()
        {
            TableClient tableClient = await this.GetTableClientForUserManualMaster();
            var record = tableClient.QueryAsync<AzureTableUserManualList>();
            List<AzureTableUserManualList> UserManualData = new List<AzureTableUserManualList>();
            await foreach (var item in record)
            {
                UserManualData.Add(item);
            }
            if (UserManualData.Count > 0)
                return UserManualData;

            return null;
        }

        //public async Task<List<AzureTableUserManualList>> GetUserManualDataList()
        //{
        //    TableClient tableClient = await this.GetTableClientForUserManualMaster();
        //    var record = tableClient.QueryAsync<AzureTableUserManualList>();
        //    List<AzureTableUserManualList> UserManualData = new List<AzureTableUserManualList>();

        //    await foreach (var item in record)
        //    {
        //        // Make sure the UserManualName is not null/empty before generating the SAS URL
        //        if (!string.IsNullOrEmpty(item.UserManualName))
        //        {
        //            // Generate secure SAS URL using file name
        //            item.UserManualUrl = GenerateSasUrl(item.UserManualName + ".pdf");
        //        }

        //        UserManualData.Add(item);
        //    }

        //    return UserManualData.Count > 0 ? UserManualData : null;
        //}


   

        private string GenerateSasUrl(string fileName)
        {
            var blobUri = new Uri($"https://{_storageAccountName}.blob.core.windows.net/sda3container/UserManualsNew/{fileName}");

            var sasBuilder = new BlobSasBuilder
            {
                BlobContainerName = "sda3container",
                BlobName = $"UserManualsNew/{fileName}",
                Resource = "b", // b = blob
                ExpiresOn = DateTimeOffset.UtcNow.AddMinutes(1)
            };

            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            var credential = new StorageSharedKeyCredential(_storageAccountName, _storageAccountKey);
            var sasToken = sasBuilder.ToSasQueryParameters(credential).ToString();

            return $"{blobUri}?{sasToken}";
        }


        public async Task<List<AzureTableUserManualDestination>> GetUserManualDataList(int userManualId, int destinationId)
        {
            TableClient tableClient = await this.GetTableClientDestinationLanguage();
            var record = tableClient.QueryAsync<AzureTableUserManualDestination>(itm=>itm.UserManualID==userManualId && itm.DestinationID==destinationId);
            List<AzureTableUserManualDestination> UserManualData = new List<AzureTableUserManualDestination>();
            await foreach (var item in record)
            {
                UserManualData.Add(item);
            }
            if (UserManualData.Count > 0)
                return UserManualData;

            return null;
        }
        public async Task<List<AzureTableUserManualCountryModel>> GetCountryModelList(int destinationId,int countryId)
        {
            TableClient tableClient = await this.GetTableClientCountryModel();
            var record = tableClient.QueryAsync<AzureTableUserManualCountryModel>(itm=>itm.DestinationID==destinationId && itm.CountryID==countryId);
            List<AzureTableUserManualCountryModel> UserManualCountryModelData = new List<AzureTableUserManualCountryModel>();
            await foreach (var item in record)
            {
                UserManualCountryModelData.Add(item);
            }
            if (UserManualCountryModelData.Count > 0)
                return UserManualCountryModelData;

            return null;
        }
        public async Task<List<AzureTableUserManualModel>> GetModelCodeList(int destinationId, string[] modelCode)
        {
            TableClient tableClient = await this.GetTableClientModelCode();
            List<AzureTableUserManualModel> UserManualModelData = new List<AzureTableUserManualModel>();
            foreach (var modelcodeitem in modelCode) { 
            var record = tableClient.QueryAsync<AzureTableUserManualModel>(itm => itm.DestinationID == destinationId && itm.ModelCode==modelcodeitem);
            
            await foreach (var item in record)
            {
                UserManualModelData.Add(item);
            }
            }
            if (UserManualModelData.Count > 0)
                return UserManualModelData;

            return null;
        }
    }
}
