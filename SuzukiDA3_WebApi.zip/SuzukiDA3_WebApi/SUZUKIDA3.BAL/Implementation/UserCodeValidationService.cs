﻿using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using Azure.Communication.Email;

namespace SUZUKIDA3.BAL.Implementation
{
    public class UserCodeValidationService : IUserCodeValidationAzureTableService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<UserCodeValidationService> _logger;
        public UserCodeValidationService(IConfiguration configuration, ILogger<UserCodeValidationService> logger)
        {
            _configuration = configuration;
            _logger = logger;   

        }
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_USERCODE]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        /// <summary>
        /// Adds the user.
        /// </summary>
        /// <param name="UserCode">The user code.</param>
        /// <returns></returns>
        public async Task<bool> AddUser(string UserCode)
        {
            var previousItem = await this.GetUser(UserCode);
            if (previousItem != null) { return false; }
            AzureTableUserCode validationCodeItem = new AzureTableUserCode { PartitionKey = DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY, ETag = ETag.All, ValidationCode = UserCode, RowKey = Guid.NewGuid().ToString(), };
            TableClient tableClient = await this.GetTableClient();
            var response = await tableClient.AddEntityAsync<AzureTableUserCode>(validationCodeItem);
            return !response.IsError;
        }
        public async Task<bool> AddUserWithEmail(string UserCode, string Email)
        {
            var previousItem = await this.GetUserByEmail(Email);
            if (previousItem != null) { return false; }
            AzureTableUserCode validationCodeItem = new AzureTableUserCode { PartitionKey = DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY, ETag = ETag.All, ValidationCode = UserCode, RowKey = Guid.NewGuid().ToString(),EmailId=Email, };
            TableClient tableClient = await this.GetTableClient();
            var response = await tableClient.AddEntityAsync<AzureTableUserCode>(validationCodeItem);
            return !response.IsError;
        }
        public async Task<bool> SendMail(string ToMail,string upperTemplate, string lowerTemplate, string fromMail,string mailSubject, string connectionStringACS)
        {
            bool UserAddedOrUpdated;    
            //Random rnd = new Random();
            //int otp = Convert.ToInt32(rnd.Next(100000,1000000));
            var otp = Guid.NewGuid();
            if(await GetUserByEmail(ToMail)==null)
                UserAddedOrUpdated=await AddUserWithEmail(otp.ToString(), ToMail);
            else
                UserAddedOrUpdated=await UpdateUserByEmail(otp.ToString(), ToMail);

            var connectionString =connectionStringACS ;
            var emailClient = new EmailClient(connectionString);

            var sender = fromMail;
            var recipient = ToMail;
            var subject = mailSubject;
            var htmlContent = upperTemplate+ otp.ToString()+lowerTemplate;

            try
            {
                var emailSendOperation = await emailClient.SendAsync(
                    wait: WaitUntil.Completed,
                    senderAddress: sender, // The email address of the domain registered with the Communication Services resource
                    recipientAddress: recipient,
                    subject: subject,
                    htmlContent: htmlContent);
                return true;
            }
            catch (RequestFailedException ex)
            {
                /// OperationID is contained in the exception message and can be used for troubleshooting purposes
                _logger.LogError("Send Mail to "+ToMail+ "failed-"+ex.Message, ex);
                return false;
            }
        }

        public async Task<bool> DeleteUser(string usercode)
        {
            var itm = await this.GetUser(usercode);
            if (itm == null)
            {
                return false;
            }
            TableClient tableClient = await this.GetTableClient();

            var response = await tableClient.DeleteEntityAsync(DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY, itm.RowKey);
            return !response.IsError;
        }

        public async Task<List<AzureTableUserCode>> GetAllUser()
        {
            TableClient tableClient = await this.GetTableClient();
            List<AzureTableUserCode> userCodes = new List<AzureTableUserCode>();
            var data = tableClient.QueryAsync<AzureTableUserCode>();
            await foreach (var item in data)
            {
                userCodes.Add(item);
            }
            return userCodes;
        }

        public async Task<AzureTableUserCode?> GetUser(string UserCode)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableUserCode>(itm => itm.PartitionKey == DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY && itm.ValidationCode == UserCode);
            List<AzureTableUserCode> userCodes = new List<AzureTableUserCode>();
            await foreach (var item in record)
            {
                userCodes.Add(item);
            }
            if (userCodes.Count > 0)
                return userCodes.FirstOrDefault();

            return null;
        }
        public async Task<AzureTableUserCode?> GetUserByEmail(string Email)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableUserCode>(itm => itm.PartitionKey == DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY && itm.EmailId == Email);
            List<AzureTableUserCode> userCodes = new List<AzureTableUserCode>();
            await foreach (var item in record)
            {
                userCodes.Add(item);
            }
            if (userCodes.Count > 0)
                return userCodes.FirstOrDefault();

            return null;
        }

        public async Task<List<AzureTableUserCode>> GetByPartitionKey()
        {
            TableClient tableClient = await this.GetTableClient();
            List<AzureTableUserCode> userCodes = new List<AzureTableUserCode>();
            var data = tableClient.QueryAsync<AzureTableUserCode>(itm => itm.PartitionKey == DA3Constants.AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY);
            await foreach (var item in data)
            {
                userCodes.Add(item);
            }
            return userCodes;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="previousUserCode">The previous user code.</param>
        /// <param name="UserCode">The user code.</param>
        /// <returns></returns>
        public async Task<bool> UpdateUser(string previousUserCode, string UserCode)
        {
            AzureTableUserCode item = await GetUser(previousUserCode);
            if (item == null)
                return false;
            TableClient tableClient = await this.GetTableClient();
            item.ValidationCode = UserCode;
            var response = await tableClient.UpdateEntityAsync(item, ETag.All, TableUpdateMode.Replace);
            return !response.IsError;
        }

        /// <summary>
        /// Updates the user by email.
        /// </summary>
        /// <param name="EmailId">The email identifier.</param>
        /// <param name="UserCode">The user code.</param>
        /// <returns></returns>
        public async Task<bool> UpdateUserByEmail(string UserCode, string EmailId)
        {
            AzureTableUserCode item = await GetUserByEmail(EmailId);
            if (item == null)
                return false;
            TableClient tableClient = await this.GetTableClient();
            item.ValidationCode = UserCode;
            var response = await tableClient.UpdateEntityAsync(item, ETag.All, TableUpdateMode.Replace);
            return !response.IsError;
        }

        public async Task<bool> ValidateUserCode(string UserCode)
        {
            var item = await GetUser(UserCode);
            if (item == null) return false;
            return true;
        }
    }
}
