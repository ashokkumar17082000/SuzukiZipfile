﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using Azure;
using SUZUKIDA3.Model.Dto.Blob;
using SUZUKIDA3.Common.Constants;
using System.Text;
using System.IO.Compression;
using System.Net;
using System;
using System.Net.Http;
using Polly;
namespace SUZUKIDA3.BAL.Implementation
{
    public class AzureStorageService : IAzureBlobStorage
    {
        private readonly string? _storageConnectionString;
        private readonly string? _storageContainerName;
        private readonly ILogger<AzureStorageService> _logger;

        public AzureStorageService(IConfiguration configuration, ILogger<AzureStorageService> logger)
        {
            _logger = logger;
            _storageConnectionString = configuration.GetValue<string>(DA3Constants.Blob_Connection_String);
            _storageContainerName = configuration.GetValue<string>(DA3Constants.Blobl_Container_Name);
           
        }
        public async Task<BlobResponseDto> DeleteAsync(string blobFilename)
        {
            BlobContainerClient client = new BlobContainerClient(_storageConnectionString, _storageContainerName);

            BlobClient file = client.GetBlobClient(blobFilename);

            try
            {
                // Delete the file
                await file.DeleteIfExistsAsync();
            }
            catch (RequestFailedException ex)
                when (ex.ErrorCode == BlobErrorCode.BlobNotFound)
            {
                // File did not exist, log to console and return new response to requesting method
                _logger.LogError($"File {blobFilename} was not found.");
                return new BlobResponseDto { Error = true, Status = $"File with name {blobFilename} not found." };
            }

            // Return a new BlobResponseDto to the requesting method
            return new BlobResponseDto { Error = false, Status = $"File: {blobFilename} has been successfully deleted." };
        }

        public async Task<BlobDto> DownloadAsync(string blobFilename)
        {
            BlobContainerClient client = new BlobContainerClient(_storageConnectionString, _storageContainerName);

            try
            {
                // Get a reference to the blob uploaded earlier from the API in the container from configuration settings
                BlobClient file = client.GetBlobClient(blobFilename);

                // Check if the file exists in the container
                if (await file.ExistsAsync())
                {
                    var data = await file.OpenReadAsync();
                    Stream blobContent = data;

                    // Download the file details async
                    var content = await file.DownloadContentAsync();

                    // Add data to variables in order to return a BlobDto
                    string name = blobFilename;
                    string contentType = content.Value.Details.ContentType;

                    // Create new BlobDto with blob data from variables
                    return new BlobDto { Content = blobContent, Name = name, ContentType = contentType };
                }
            }
            catch (RequestFailedException ex)
                when (ex.ErrorCode == BlobErrorCode.BlobNotFound)
            {
                // Log error to console
                _logger.LogError($"File {blobFilename} was not found.");
            }

            // File does not exist, return null and handle that in requesting method
            return null;
        }

        public async Task<List<BlobDto>> ListAsync()
        {
            BlobContainerClient container = new BlobContainerClient(_storageConnectionString, _storageContainerName);

            // Create a new list object for 
            List<BlobDto> files = new List<BlobDto>();

            await foreach (BlobItem file in container.GetBlobsAsync())
            {
                // Add each file retrieved from the storage container to the files list by creating a BlobDto object
                string uri = container.Uri.ToString();
                var name = file.Name;
                var fullUri = $"{uri}/{name}";


                files.Add(new BlobDto
                {
                    Uri = fullUri,
                    Name = name,
                    FilePath = name,
                    ContentType = file.Properties.ContentType
                });
            }

            // Return all files to the requesting method
            return files;
        }

        public async Task<BlobResponseDto> UploadAsync(IFormFile file)
        {

            BlobResponseDto response = new();
            
            //BlobContainerClient container = new BlobContainerClient(_storageConnectionString, _storageContainerName);
            //using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read)) 
            //{ 
            //   Response.BufferOutput= false;   // to prevent buffering
            //   byte[] buffer = new byte[1024];
            //   int bytesRead = 0;
            //   while ((bytesRead = fs.Read(buffer, 0, buffer.Length)) > 0) 
            //   {
            //       Response.OutputStream.Write(buffer, 0, bytesRead);
            //   }
            //} 
            //using (var ms = new MemoryStream())
            //{
            //    var sw = new StreamWriter(ms);
            //    var sr = new StreamReader(ms);

            //    sw.WriteLine("data");
            //    sw.WriteLine("data 2");
            //    ms.Position = 0;

            //    Console.WriteLine(sr.ReadToEnd());
            //}
            //ZipFile.ExtractToDirectory(file.FileName, "NewFolder");
            //Directory.Delete("NewFolder", true);
            //var filesdd = Directory.GetFiles("NewFolder", "*dd.json");
            //File.Delete(filesdd.FirstOrDefault());

            //byte[] fileBytes =System.IO.File.ReadAllBytes(file.Name);
            //await container.CreateAsync();
            try
            {
                //BlobClient client = container.GetBlobClient("sda3container");

                ////var localFilePath=file.FileName;
                //    await client.UploadAsync(file.FileName);


                //response.Status = $"File {file.FileName} Uploaded Successfully";
                //response.Error = false;
                //response.Blob.Uri = client.Uri.AbsoluteUri;
                //response.Blob.Name = file.FileName;
                //response.Blob.FilePath = client.Name;
                if (file.Length > 0)
                {
                    // Create a BlobServiceClient
                    var blobServiceClient = new BlobServiceClient(_storageConnectionString);

                    // Get a reference to the container
                    var blobContainerClient = blobServiceClient.GetBlobContainerClient(_storageContainerName);

                    // Create the container if it doesn't exist
                    await blobContainerClient.CreateIfNotExistsAsync();

                    // Get a reference to a blob within the container
                    var blobClient = blobContainerClient.GetBlobClient(file.FileName);

                    // Upload the file to the blob
                    using (var stream = file.OpenReadStream())
                    {
                        await blobClient.UploadAsync(stream, overwrite: true);
                    }
                    response.Status = $"File {file.FileName} Uploaded Successfully";
                    response.Error = false;
                    response.Blob.Uri = blobClient.Uri.AbsoluteUri;
                    response.Blob.Name = file.FileName;
                    response.Blob.FilePath = blobClient.Name;
                    Console.WriteLine($"File '{file.FileName}' uploaded to Blob Storage.");
                }
                else
                {
                    Console.WriteLine("The uploaded file is empty.");
                }

            }
            catch (RequestFailedException ex)
               when (ex.ErrorCode == BlobErrorCode.BlobAlreadyExists)
            {
                _logger.LogError($"File with name {file.FileName} already exists in container. Set another name to store the file in the container: '{_storageContainerName}.'");
                response.Status = $"File with name {file.FileName} already exists. Please use another name to store your file.";
                response.Error = true;
                return response;
            }
            catch (RequestFailedException ex)
            {
                _logger.LogError($"Unhandled Exception. ID: {ex.StackTrace} - Message: {ex.Message}");
                response.Status = $"Unexpected error: {ex.StackTrace}. Check log with StackTrace ID.";
                response.Error = true;
                return response;
            }

            return response;
        }


        public async Task<BlobResponseDto> UploadToAsync(IFormFile file, string? Folder)
        {
            BlobResponseDto response = new();

            BlobContainerClient container = new BlobContainerClient(_storageConnectionString, _storageContainerName);
            //await container.CreateAsync();
            try
            {
                string filepath = string.IsNullOrWhiteSpace(Folder) ? "" : Folder + "/";
                filepath += file.FileName;


                BlobClient client = container.GetBlobClient(filepath);

                // Open a stream for the file we want to upload
                await using (Stream? data = file.OpenReadStream())
                {
                    await client.UploadAsync(data, true);
                }

                // Everything is OK and file got uploaded
                response.Status = $"File {file.FileName} Uploaded Successfully";
                response.Error = false;
                response.Blob.Uri = client.Uri.AbsoluteUri;
                response.Blob.Name = file.FileName;
                response.Blob.FilePath = client.Name;

            }
            // If the file already exists, we catch the exception and do not upload it
            catch (RequestFailedException ex)
               when (ex.ErrorCode == BlobErrorCode.BlobAlreadyExists)
            {
                _logger.LogError($"File with name {file.FileName} already exists in container. Set another name to store the file in the container: '{_storageContainerName}.'");
                response.Status = $"File with name {file.FileName} already exists. Please use another name to store your file.";
                response.Error = true;
                return response;
            }
            // If we get an unexpected error, we catch it here and return the error message
            catch (RequestFailedException ex)
            {
                // Log error to console and create a new response we can return to the requesting method
                _logger.LogError($"Unhandled Exception. ID: {ex.StackTrace} - Message: {ex.Message}");
                response.Status = $"Unexpected error: {ex.StackTrace}. Check log with StackTrace ID.";
                response.Error = true;
                return response;
            }

            // Return the BlobUploadResponse object
            return response;
        }

        public async Task<bool> CheckFolderExistsAsync(string folderName)
        {
            bool hasFolder = false;
            BlobContainerClient client = new BlobContainerClient(_storageConnectionString, _storageContainerName);
            BlobClient file = client.GetBlobClient(folderName);
            hasFolder = await file.ExistsAsync();

            return hasFolder;

        }

        private (BlobContainerClient, BlobClient, bool) GetBlobFolderClient(string folderName)
        {
            bool isFolderExists = false;
            BlobContainerClient container = new BlobContainerClient(_storageConnectionString, _storageContainerName);
            BlobClient client = container.GetBlobClient(folderName + "/");
            if (client.Exists())
            {
                isFolderExists = true;
            }
            return (container, client, isFolderExists);
        }

        public async Task<List<BlobDto>> ListFileFromFolder(string folderName)
        {
            (BlobContainerClient container, BlobClient client, bool isFolderExists) = GetBlobFolderClient(folderName);
            List<BlobDto> files = new List<BlobDto>();
            if (isFolderExists)
            {
                await foreach (BlobItem file in container.GetBlobsAsync(prefix: folderName + "/"))
                {
                    string uri = container.Uri.ToString();
                    var name = file.Name;
                    var fullUri = $"{uri}/{name}";
                    files.Add(new BlobDto
                    {
                        Uri = fullUri,
                        Name = name,
                        FilePath = name,
                        ContentType = file.Properties.ContentType
                    });
                }

            }
            else
            {
                await client.UploadAsync(new MemoryStream(Array.Empty<byte>()), true);
            }

            return files;
        }

        private async Task<BlobDto> sendInfotainmentFileToHarman(IFormFile file)
        {
            bool isSuccess = false;
            string apiUrl = "https://localhost:7777/";
            string storageurl = "api/v1.0/externalStorage";
            string postUrl = apiUrl + "api/v1.0/externalStorage/createPackageByInventory";
            string downloadzipfileUrl = apiUrl + storageurl+"/download";
            string geturl = apiUrl + storageurl;
            BlobDto blob = new();
            await using (Stream fileStream = file.OpenReadStream())
            {
                StreamContent streamcontent = new StreamContent(fileStream);
                var formData = new MultipartFormDataContent();
                formData.Add(streamcontent, "file", file.FileName);
                using (HttpClient httpClient = new HttpClient())
                {
                    httpClient.Timeout = TimeSpan.FromMinutes(10);
                    
                    HttpResponseMessage response =  await httpClient.PostAsync(downloadzipfileUrl, formData);
                    if (response.IsSuccessStatusCode)
                    {
                        isSuccess = true;
                        var content = await response.Content.ReadAsStreamAsync();
                        var contentType = "application/zip";
                        var fileName = "SUZUKI_Infotainment_SoftwareUpdate.zip"; 
                        blob.Content = content;
                        blob.ContentType = contentType;
                        blob.FilePath = fileName;
                    }
                    else
                    {
                        isSuccess = false;
                    }
                }
            }
            return blob;
        }

        private async Task<ICollection<BlobResponseDto>> GetDataFromDifferentAPI(IFormFile file)
        {
            ICollection<BlobResponseDto> data = null;

            string apiUrl = "https://localhost:7777/";
            string storageurl = "api/v1.0/externalStorage";
            string geturl = apiUrl + storageurl;

          
            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.Timeout = TimeSpan.FromSeconds(6000);
                HttpResponseMessage response = await httpClient.GetAsync(geturl);
                if (response.IsSuccessStatusCode)
                {
                    data = null;
                    // var responseContent = await response.Content.ReadFromJsonAsync<BlobResponseDto>();
                    var resposeContents = await response.Content.ReadAsStringAsync();
                    //response.Content.ReadFromJsonAsync();
                }
                else
                {
                    data = null;
                }
            }

            return data;
        }
        private async Task<bool> CallHarmanPostRequest(IFormFile file)
        {
            bool isSuccess = false;
            string apiUrl = "https://localhost:7777/";
            string storageurl = "api/v1.0/externalStorage";

            using (HttpClient httpClient = new HttpClient()
            {
                BaseAddress = new Uri(apiUrl)
            })
            {
                string POST_Test = "TEST Folder Name";

                var content = new StringContent(POST_Test, Encoding.UTF8, "text/plain");
                // httpClient.DefaultRequestHeaders.Add("Content-Type", "text/plain");
                //content.Headers.ContentType = new MediaTypeHeaderValue("text/plain");
                // string jsonContent = "{\"key\":\"Hari\"}";
                // var contentString = new StringContent(jsonContent, Encoding.UTF8, "application/json");


                HttpResponseMessage response = await httpClient.PostAsync(storageurl, content);

                if (response.IsSuccessStatusCode)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            return isSuccess;
        }
        public async Task<string> UploadZipFromUrlAsync(string sourceUrl, string containerName, string blobName,string connectionString)
        {
            //try
            //{
            //    BlobServiceClient _blobServiceClient = new BlobServiceClient(connectionString);
            //    var blobContainerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            //    await blobContainerClient.CreateIfNotExistsAsync(PublicAccessType.None);

            //    var blobClient = blobContainerClient.GetBlobClient(blobName);

            //    // Start copying from the source URL to Blob Storage
            //    var copyOperation = await blobClient.StartCopyFromUriAsync(new Uri(sourceUrl));

            //    // Poll for copy completionss
            //    while (true)
            //    {
            //        var properties = await blobClient.GetPropertiesAsync();
            //        if (properties.Value.CopyStatus != CopyStatus.Pending)
            //            break;
            //        await Task.Delay(500); // Wait before checking again
            //    }

            //    return blobClient.Uri.ToString(); // Return the uploaded Blob URL
            //}
            //catch (Exception ex)
            //{
            //    return $"Error: {ex.Message}";
            //}


            using (HttpClient client = new HttpClient())
            {
              
                client.Timeout = TimeSpan.FromSeconds(30);

                
                var policy = Policy
                    .Handle<HttpRequestException>()
                    .Or<TimeoutException>()
                    .WaitAndRetryAsync(10, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt))); 

                
                Stream fileStream = await policy.ExecuteAsync(async () => await client.GetStreamAsync(sourceUrl));

                
                BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
                BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);

                
                BlobClient blobClient = containerClient.GetBlobClient(blobName);
                await blobClient.UploadAsync(fileStream, overwrite: true);

                return blobClient.Uri.ToString();
            }

            //try
            //{ 


            //    using (HttpClient client = new HttpClient())
            //    {
            //        //client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");

            //        int retryCount = 0;
            //        const int maxRetries = 10;
            //        bool requestSucceeded = false;
            //        Stream stream= null;
            //        while (!requestSucceeded && retryCount < maxRetries)
            //        {
            //            try
            //            {
            //                stream = await client.GetStreamAsync(sourceUrl);
            //                requestSucceeded = true;
            //                Console.Write("This shows retry count-"+retryCount);
            //            }
            //            catch (HttpRequestException e) when (e.Message.Contains("Forbidden"))
            //            {
            //                // Handle 403 error (e.g., log, wait, and retry)
            //                retryCount++;
            //                await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, retryCount))); // Exponential backoff
            //            }
            //        }


            //        // Create a BlobServiceClient
            //        BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

            //        // Get a reference to the container and create it if it doesn't exist
            //        BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);

            //        await containerClient.CreateIfNotExistsAsync();
            //        // Get a reference to the blob (the file we want to upload)
            //        BlobClient blobClient = containerClient.GetBlobClient(blobName);

            //        // Upload the file stream to the blob
            //        await blobClient.UploadAsync(stream, overwrite: true);


            //        // Return the blob URL
            //        return blobClient.Uri.ToString();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    return "Error while downloading and uploading file" + ex.Message;
            //}
        }
        public async Task<BlobResponseDto> SoftwareUpdate(IFormFile file)
        {
            BlobDto blob = new();
            BlobResponseDto blobResponseDto = new BlobResponseDto();
            //var response = await GetDataFromDifferentAPI(file);
            var response1 = await sendInfotainmentFileToHarman(file);
            blob = response1 as BlobDto;
            blobResponseDto.Blob = blob;

            blobResponseDto.Status = response1 != null ? "Success" : "Failed";
            blobResponseDto.Error = false;
            return blobResponseDto;
        }
    }
}
