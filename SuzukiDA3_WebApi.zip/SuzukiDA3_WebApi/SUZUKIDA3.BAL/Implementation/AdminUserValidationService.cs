﻿using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using Azure.Communication.Email;

namespace SUZUKIDA3.BAL.Implementation
{
    public class AdminUserValidationService : IAdminUserValidationAzureTableService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<UserCodeValidationService> _logger;
        public AdminUserValidationService(IConfiguration configuration, ILogger<UserCodeValidationService> logger)
        {
            _configuration = configuration;
            _logger = logger;   

        }
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_USER_MASTER]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        public async Task<AzureTableAdminUser?> GetUser(string UserId)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableAdminUser>(itm => itm.UserId == UserId.ToLower());
            List<AzureTableAdminUser> userCodes = new List<AzureTableAdminUser>();
            await foreach (var item in record)
            {
                userCodes.Add(item);
            }
            if (userCodes.Count > 0)
                return userCodes.FirstOrDefault();

            return null;
        }
        public async Task<bool> ValidateUserCode(string UserCode)
        {
            var item = await GetUser(UserCode);
            if (item == null) return false;
            return true;
        }
    }
}
