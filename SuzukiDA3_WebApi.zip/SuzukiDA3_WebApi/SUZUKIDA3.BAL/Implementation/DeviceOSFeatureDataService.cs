﻿using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SUZUKIDA3.BAL.Implementation
{
    public class DeviceOSFeatureDataService : IDeviceOSFeatureAzureTableService
    {
        private readonly IConfiguration _configuration;

        public DeviceOSFeatureDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient(string tableName)
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(tableName);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        public async Task<List<AzureTableDeviceOSFeature>> GetDeviceOSFeatureData(OSFeatureReqDto data)
                {
          
            var tableClient1 = await GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DeviceOSFeature]);
            var tableClient2 = await GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_Feature]);
            var tableClient3 = await GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_FeatureStatus]);
            var tableClient4 = await GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_FeatureLanguage]);




            var FeatureDataTask = tableClient2.QueryAsync<AzureTableFeature>(entity=> entity.FeatureEntityStatus==1);
            var OSFeatureDataTask = tableClient1.QueryAsync<AzureTableOSFeature>(entity => entity.ManufacturerID == data.manufactureID && entity.DeviceID == data.deviceID && entity.OSID == data.osID && entity.EntityStatus == 1);

            var FeatureStatusDataTask = tableClient3.QueryAsync<AzureTableFeatureStatus>();
            var FeatureLanguageDataTask = tableClient4.QueryAsync<AzureTableFeatureLanguage>( entity => entity.LanguageCode == data.languageCode);




            var OSFeatureData = new List<AzureTableOSFeature>();
            var FeatureData = new List<AzureTableFeature>();
            var FeatureStatusData = new List<AzureTableFeatureStatus>();
            var FeatureLanguageData = new List<AzureTableFeatureLanguage>();

            await foreach (var entity in OSFeatureDataTask)
            {
                OSFeatureData.Add(entity);
            }

            await foreach (var entity in FeatureDataTask)
            {
                FeatureData.Add(entity);
            }

            await foreach (var entity in FeatureStatusDataTask)
            {
                FeatureStatusData.Add(entity);
            }

            await foreach (var entity in FeatureLanguageDataTask)
            {
                FeatureLanguageData.Add(entity);
            }


            var DeviceOSFeatureData = new List<AzureTableDeviceOSFeature>();


            var joinedData = from osFeature in OSFeatureData
                             join feature in FeatureData on osFeature.FeatureID.ToString() equals feature.PartitionKey
                             join featureStatus in FeatureStatusData on osFeature.OSFeatureStatus.ToString() equals featureStatus.PartitionKey
                             join featureLanguage in FeatureLanguageData on feature.PartitionKey equals featureLanguage.FeatureRefID.ToString() 
                             select new AzureTableDeviceOSFeature
                             {
                                 PartitionKey = osFeature.PartitionKey,
                                 RowKey = osFeature.RowKey,
                                 FeatureID =  feature.PartitionKey,
                                 Feature   = feature.Feature,
                                 Category = feature.FeatureCategory,
                                 FeatureCategory=featureLanguage.FeatureCategory,
                                 FeatureName = featureLanguage.FeatureName,
                                 OSFeatureStatus=osFeature.OSFeatureStatus,
                                 ImageUrl=featureStatus.ImageUrl,
                                 FeatureEntityStatus=feature.FeatureEntityStatus,
                                 EntityStatus=osFeature.EntityStatus,
                                 Order=feature.Order,
                                 FeatureOrder=feature.FeatureOrder,
                                 ETag =osFeature.ETag
                             };
           
            foreach (var entity in joinedData.OrderBy(e=>e.FeatureOrder).ThenBy(e=>e.Order))
            {
                DeviceOSFeatureData.Add(entity);
            }


            if (DeviceOSFeatureData.Count > 0)
                return DeviceOSFeatureData;

            return null;
        }
            }
}
