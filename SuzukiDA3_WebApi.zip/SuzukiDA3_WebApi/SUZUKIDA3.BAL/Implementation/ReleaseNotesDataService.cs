﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Data.Tables;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.BAL.Implementation
{
    public class ReleaseNotesDataService : IReleaseNotes
    {
        private readonly IConfiguration _configuration;

        public ReleaseNotesDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_RELEASE_NOTES]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        /// <summary>
        /// Gets the email data.
        /// </summary>
        /// <param name="memberName">Name of the member.</param>
        /// <returns></returns>
        public async Task<List<AzureTableReleaseNotes>> GetReleaseNotesList()
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableReleaseNotes>();
            List<AzureTableReleaseNotes> releaseNotes = new List<AzureTableReleaseNotes>();
            await foreach (var item in record)
            {
                releaseNotes.Add(item);
            }
            if (releaseNotes.Count > 0)
                return releaseNotes;

            return null;
        }
        public async Task<List<AzureTableReleaseNotesData>> GetReleaseNotesDataList(string softwareVariant, string softwareVersion,string langCode)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableReleaseNotesData>(itm=>itm.softwareVariant==softwareVariant && itm.softwareVersion==softwareVersion && itm.languageCode==langCode);
            List<AzureTableReleaseNotesData> releaseNotesData = new List<AzureTableReleaseNotesData>();
            await foreach (var item in record)
            { 
                releaseNotesData.Add(item);
            }
            if (releaseNotesData.Count > 0)
                return releaseNotesData;

            return null;
        }
    }
}
