﻿using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Interfaces.Repository;
using SUZUKIDA3.Model.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.BAL.Implementation
{
    public class TempLoginService : ITempLoginService
    {
        private readonly IUnitOfWorkRepository _uow;
        public TempLoginService(IUnitOfWorkRepository uow)
        {

            _uow = uow;
        }
        public async Task<bool> Add(TempLogin entity)
        {
            await this._uow.TempLogin.Add(entity);
            var res = _uow.Save();
            return res > 0;
        }

        public async Task<TempLogin> findServieItem(string userId)
        {
            TempLogin item = await _uow.TempLogin.findItem(userId);
            return item;
        }

        public Task<IEnumerable<TempLogin>> GetAll()
        {
            return _uow.TempLogin.GetAll();
        }

        public Task<TempLogin> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> Remove(int id)
        {
            TempLogin item = await GetById(id);
            _uow.TempLogin.Remove(item);
            var res = _uow.Save();
            return res > 0;
        }

        public Task<bool> Update(TempLogin entity)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> ValidateUserIdServiceAsync(string userId)
        {
            return await _uow.TempLogin.ValidateUserIdAsync(userId);
        }
    }
}
