﻿using Azure;
using Azure.Data.Tables;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;
using System.Net;
using System.Net.Mail;

namespace SUZUKIDA3.BAL.Implementation
{
    public class EmailDataService : IEmailDataAzureTableService
    {
        private readonly IConfiguration _configuration;

        public EmailDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_EMAIL]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        //public async Task<bool> AddEmail()
        //{
        //    //var previousItem = await this.GetUser(UserCode);
        //   // if (previousItem != null) { return false; }
        //    AzureTableEmail validationCodeItem = new AzureTableEmail { PartitionKey = "EmailTemplate", ETag = ETag.All, MemberName="EmailId", RowKey = Guid.NewGuid().ToString(),MemberValue= "premkumar.ks@in.bosch.com" };
        //    TableClient tableClient = await this.GetTableClient();
        //    var response = await tableClient.AddEntityAsync<AzureTableEmail>(validationCodeItem);
        //    return !response.IsError;
        //}

        /// <summary>
        /// Gets the email data.
        /// </summary>
        /// <param name="memberName">Name of the member.</param>
        /// <returns></returns>
        public async Task<AzureTableEmail> GetEmailData(string memberName)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableEmail>(itm => itm.PartitionKey == DA3Constants.AZURE_TABLE_EMAIL_PARTITION_KEY && itm.MemberName == memberName);
            List<AzureTableEmail> EmailData = new List<AzureTableEmail>();
            await foreach (var item in record)
            {
                EmailData.Add(item);
            }
            if (EmailData.Count > 0)
                return EmailData.FirstOrDefault();

            return null;
        }
        public async Task<AzureTableEmail> GetEmailList(string memberValue)
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableEmail>(itm => itm.PartitionKey == DA3Constants.AZURE_TABLE_EMAIL_PARTITION_KEY && itm.MemberName == "EmailId" && itm.MemberValue==memberValue);
            List<AzureTableEmail> EmailData = new List<AzureTableEmail>();
            await foreach (var item in record)
            {
                EmailData.Add(item);
            }
            if (EmailData.Count > 0)
                return EmailData.FirstOrDefault();

            return null;
        }
    }
}
