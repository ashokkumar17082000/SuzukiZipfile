﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Data.Tables;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.BAL.Implementation
{
    public class DeviceDataService : IDeviceDataAzureTableService
    {
        private readonly IConfiguration _configuration;

        public DeviceDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DeviceMaster]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        public async Task<List<AzureTableDevice>> GetDeviceData()
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableDevice>();
            List<AzureTableDevice> DeviceData = new List<AzureTableDevice>();
            await foreach (var item in record)
            {
                DeviceData.Add(item);
            }
            
            if (DeviceData.Count > 0)
                return DeviceData;

            return null;
        }
    }
}
