﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.Data.Tables;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Microsoft.Extensions.Configuration;
using SUZUKIDA3.Common.Constants;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Model.DataModel;

namespace SUZUKIDA3.BAL.Implementation
{
    public class DCManufacturerDataService : IDCManufacturerDataAzureTableService
    {
        private readonly IConfiguration _configuration;

        public DCManufacturerDataService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Gets the table client.
        /// </summary>
        /// <returns></returns>
        private async Task<TableClient> GetTableClient()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DCManufacturer]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }

        private async Task<TableClient> GetTableClientDevice()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_DeviceMaster]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        private async Task<TableClient> GetTableClientRegion()
        {
            var serviceClient = new TableServiceClient(_configuration[DA3Constants.Blob_Connection_String]);
            var tableClient = serviceClient.GetTableClient(_configuration[DA3Constants.AZURE_STORAGE_TABLE_RegionMaster]);
            await tableClient.CreateIfNotExistsAsync();
            return tableClient;
        }
        public async Task<List<AzureTableDCManufacturer>> GetDCManufacturerData()
        {
            TableClient tableClient = await this.GetTableClient();
            var record = tableClient.QueryAsync<AzureTableDCManufacturer>();
            List<AzureTableDCManufacturer> DCManufacturerData = new List<AzureTableDCManufacturer>();
            await foreach (var item in record)
            {
                DCManufacturerData.Add(item);
            }
            if (DCManufacturerData.Count > 0)
                return DCManufacturerData;

            return null;
        }
        public async Task<List<AzureTableDCRegion>> GetDCRegion()
        {
            TableClient tableClient = await this.GetTableClientRegion();
            var record = tableClient.QueryAsync<AzureTableDCRegion>();
            List<AzureTableDCRegion> DCRegionData = new List<AzureTableDCRegion>();
            await foreach (var item in record)
            {
                DCRegionData.Add(item);
            }
            if (DCRegionData.Count > 0)
                return DCRegionData;

            return null;
        }
        public async Task<List<AzureTableDevice>> GetDeviceData(int ManufacturerId)
        {
            TableClient tableClient = await this.GetTableClientDevice();
            var record = tableClient.QueryAsync<AzureTableDevice>(itm=>itm.ManufacturerRefId == ManufacturerId );
            List<AzureTableDevice> DeviceData = new List<AzureTableDevice>();
            await foreach (var item in record)
            {
                DeviceData.Add(item);
            }
            if (DeviceData.Count > 0)
                return DeviceData;

            return null;
        }
    }
}
