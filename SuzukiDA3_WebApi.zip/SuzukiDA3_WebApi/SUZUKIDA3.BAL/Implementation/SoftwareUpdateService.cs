﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Interfaces.Repository;
using SUZUKIDA3.Model.DataModel;
using SUZUKIDA3.Model.Dto.Client;
using SUZUKIDA3.Model.Dto.SoftwareUpdate;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Controllers;
using SUZUKIDA3.Common.Helpers;
namespace SUZUKIDA3.BAL.Implementation
{
    public class SoftwareUpdateService : ISoftwareUpdateService
    {
        private readonly IUnitOfWorkRepository _uow;

        public SoftwareUpdateService(IUnitOfWorkRepository uow)
        {
            _uow = uow;
        }

        public Task<bool> Add(SoftwareUpdate entity)
        {
            throw new NotImplementedException();
        }


        public Task<IEnumerable<SoftwareUpdate>> GetAll()
        {
            throw new NotImplementedException();
        }

        public Task<SoftwareUpdate> GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> Remove(int id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> Update(SoftwareUpdate entity)
        {
            throw new NotImplementedException();
        }
        public async Task<Object> ClientCall(IManageClientUserSession _userClientSession, string loginUrl, IEnumerable<KeyValuePair<string,string>> creds, ILogger _logger,IFormFile file, Stream decrypted_file_stream,string packageId,string software_download_url,string check_for_update_url)
        {
            string sessionID = string.Empty;
            using (HttpClient client = _userClientSession.CreateHttpClient())
            {
                client.Timeout = TimeSpan.FromMinutes(25);
                sessionID = _userClientSession.getClientSessionID();

                if (string.IsNullOrWhiteSpace(sessionID))
                {
                    //get login credentials
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    try
                    {

                        using (HttpResponseMessage login_response = await client.PostAsync(loginUrl, new FormUrlEncodedContent(creds)))
                        {
                            if (login_response.IsSuccessStatusCode)
                            {
                                string jsonResponse = await login_response.Content.ReadAsStringAsync();
                                LoginResDto loginResponse = JsonSerializer.Deserialize<LoginResDto>(jsonResponse);
                                sessionID = loginResponse?.sessionId;
                                if (!string.IsNullOrWhiteSpace(sessionID))
                                    _userClientSession.setClientSessionId(sessionID);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Failed to authenticate to client Server.", ex.Message);
                        return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.FetchCredentialsFailed, Message = "Failed client Authentication!" };
                    }
                }
                if (sessionID == string.Empty)
                {
                    return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.ServerAuthFail, Message = "Internal Server Error!" };
                }

                _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: Autentication success : SessionID : " + sessionID);
                var formData = new MultipartFormDataContent();
                
                StreamContent streamcontent = new StreamContent(decrypted_file_stream);
                formData.Add(streamcontent, "file", file.FileName);

                client.DefaultRequestHeaders.Add("sessionId", sessionID);
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                using (HttpResponseMessage update_check_response = await client.PostAsync(check_for_update_url, formData))
                {
                    if (update_check_response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await update_check_response.Content.ReadAsStringAsync();
                        var packageUpdateResponse = JsonSerializer.Deserialize<SoftwareUpdatePackageResDto>(jsonResponse);
                        packageId = packageUpdateResponse?.id;
                    }
                }
                
                if (packageId == string.Empty)
                {
                    return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Update Not avaialble for your Infotainment Package." };
                }
                int package_ready_counter = 0;

                _logger.LogInformation("SOFTWARE DOWNLOAD PAGE: update Available, Package Id!" + packageId);

                do
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Accept", "application/json");
                    client.DefaultRequestHeaders.Add("sessionId", sessionID);
                    package_ready_counter++;

                    using (HttpResponseMessage response_download_ready = await client.GetAsync(software_download_url + packageId))
                    {
                        if (response_download_ready.IsSuccessStatusCode)
                        {
                            string jsonResponse = await response_download_ready.Content.ReadAsStringAsync();
                            PackageDownloadReadyResponseObject packageAvailableResponse = JsonSerializer.Deserialize<PackageDownloadReadyResponseObject>(jsonResponse);
                            if (packageAvailableResponse != null && packageAvailableResponse.status == "SUCCESS")
                            { package_ready_counter = 100; }
                            else if (packageAvailableResponse != null && packageAvailableResponse.status == "FAILED")
                            {
                                package_ready_counter = 100;
                                return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.UpdateNotAvailable, Message = "Software Update is not available." };

                            }
                            else
                            {
                                Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                            }
                        }
                        else
                        {
                            Task.Delay(TimeSpan.FromSeconds(5)).Wait();
                        }
                    }
                } while (package_ready_counter < 8);
                software_download_url += string.Format("{0}/download", packageId);
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("sessionId", sessionID);
                client.DefaultRequestHeaders.Add("Accept", "application/json");
                _logger.LogInformation("Is Download Package Avaialble" + packageId);
                HttpResponse Response=null;
                try
                {
                    using (HttpResponseMessage download_response = await client.GetAsync(software_download_url, HttpCompletionOption.ResponseHeadersRead))
                    {
                        _logger.LogInformation("SOFTWARE DOWNLOAD RESPONSE :" + download_response.IsSuccessStatusCode);

                        if (download_response.IsSuccessStatusCode)
                        {

                            string contentType = download_response.Content.Headers.ContentType.MediaType.ToString();

                            if (string.IsNullOrEmpty(contentType))
                            {
                                contentType = "application/octet-stream";
                            }

                            string fileName = _userClientSession.getFileNameFromContentDisposition(download_response.Content.Headers.ContentDisposition);
                            _logger.LogInformation("SOFTWARE DOWNLOAD RESPONSE Headers:" + download_response.Content.Headers.ToString());
                            Response.Headers.Add("Content-Type", "application/octet-stream");
                            Response.Headers.Add("Content-Disposition", $"attachment; filename={fileName}");
                            Response.Headers.Add("FileName", fileName);
                            await download_response.Content.CopyToAsync(Response.Body);
                            return new EmptyResult();
                        }
                        else
                        {
                            return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.DownloadFailed, Message = "Software Download failed." };
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError("DOWNLOAD FROM OTA FAILED:  ", ex.Message);
                    return new SoftwareErrorResponseDto { ErrorCode = ErrorCode.DownloadFailed, Message = "Software Download failed." };
                }
            }
        }


    }
}
