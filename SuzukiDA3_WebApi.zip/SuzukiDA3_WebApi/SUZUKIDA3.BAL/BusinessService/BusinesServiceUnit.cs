﻿using SUZUKIDA3.BAL.Implementation;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.Interfaces.Repository;


namespace SUZUKIDA3.BAL.BusinessService
{
    public class BusinesServiceUnit : IBusinesServiceUnit
    {
        private readonly IUnitOfWorkRepository _unitOfWork;
        private ISoftwareUpdateService _softwareUpdateService;
        private ITempLoginService _tempLoginService;

        public BusinesServiceUnit(IUnitOfWorkRepository unitOfWork)
        {
            _unitOfWork = unitOfWork;

        }

        public ISoftwareUpdateService SoftwareUpdateService => _softwareUpdateService ?? new SoftwareUpdateService(_unitOfWork);


        public ITempLoginService TempLoginService => _tempLoginService ?? new TempLoginService(_unitOfWork);

    }
}
