﻿namespace SUZUKIDA3.Common.Helpers
{
    /// <summary>
    /// class for handling download package response
    /// </summary>
    public class PackageDownloadReadyResponseObject
    {
        public string id { get; set; }
        public string deprecationStatus { get; set; }
        public string status { get; set; }
    }
}
