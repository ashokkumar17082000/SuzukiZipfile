﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Common.Constants
{
    /// <summary>
    /// Common contants used in project
    /// </summary>
    public static class DA3Constants
    {
        public const string connection_value = "string connection";
        public const string Blobl_Container_Name = "BlobContainerName";
        public const string Blob_Connection_String = "BlobStorageConnection";


        public const string ClientBaseURIKey = "ClientBaseUrl";
        public const string ClientUserNameKey = "userName";
        public const string ClientPasswordNameKey = "password";
        public const string ClientDomainNameKey = "domain";
        public const string ClientMTLS = "MTLS";
        public const string ClientUserNameValue = "ClientUserName";
        public const string ClientPasswordValue = "ClientPassword";
        public const string ClientDomainValue = "ClientDomain";



        public const string ClientLoginUserSessionIdSaveKey = "clientSessionID";
        public const string PublicKey = "PublicKey";
        public const string PrivateKey = "PRIVATEKEY";

        //should be configurable from keyvault
        public const string CertificatePasswordValue = "Client123";
        public const string SOFTWARE_DOWNLOAD_FileName = "SOFTWARE_DOWNLOAD_FILENAME";

        public const string AZURE_STORAGE_TABLE_USERCODE = "AZURE_STORAGE_TABLE_USERCODE_NAME";
        public const string AZURE_STORAGE_TABLE_USER_MASTER = "AZURE_STORAGE_TABLE_USER_MASTER";
        public const string AZURE_TABLE_VALIDATION_CODE_PARTITION_KEY = "UserCodeValidation";

        public const string AZURE_STORAGE_TABLE_EMAIL = "AZURE_STORAGE_TABLE_EMAIL_NAME";
        public const string AZURE_TABLE_EMAIL_PARTITION_KEY = "EmailTemplate";

        public const string AZURE_STORAGE_TABLE_LANGUAGE = "AZURE_STORAGE_TABLE_LANGUAGE";
        public const string AZURE_STORAGE_TABLE_DCManufacturer = "AZURE_STORAGE_TABLE_DCManufacturer";
        public const string AZURE_STORAGE_TABLE_DeviceMaster = "AZURE_STORAGE_TABLE_DeviceMaster";
        public const string AZURE_STORAGE_TABLE_RegionMaster = "AZURE_STORAGE_TABLE_RegionMaster";
        public const string AZURE_STORAGE_TABLE_OS = "AZURE_STORAGE_TABLE_OS";
        public const string AZURE_STORAGE_TABLE_DeviceOSFeature = "AZURE_STORAGE_TABLE_DeviceOSFeature";

        public const string AZURE_STORAGE_TABLE_Certificate = "AZURE_STORAGE_TABLE_Certificate";
        public const string AZURE_STORAGE_TABLE_Faq = "AZURE_STORAGE_TABLE_Faq";
        public const string AZURE_STORAGE_TABLE_Android_Auto = "AZURE_STORAGE_TABLE_Android_Auto";
        public const string AZURE_STORAGE_TABLE_Oss = "AZURE_STORAGE_TABLE_Oss";

        public const string AZURE_STORAGE_TABLE_CALLBACK = "AZURE_STORAGE_TABLE_CALLBACK";
        public const string AZURE_STORAGE_TABLE_DA3Logs = "AZURE_STORAGE_TABLE_DA3Logs";
        public const string AZURE_STORAGE_TABLE_Session = "AZURE_STORAGE_TABLE_Session";
        public const string AZURE_STORAGE_TABLE_CALLBACK_ERROR = "AZURE_STORAGE_TABLE_CALLBACK_ERROR";

        public const string AZURE_STORAGE_TABLE_Feature = "AZURE_STORAGE_TABLE_Feature";
        public const string AZURE_STORAGE_TABLE_FeatureStatus = "AZURE_STORAGE_TABLE_FeatureStatus";
        public const string AZURE_STORAGE_TABLE_FeatureLanguage = "AZURE_STORAGE_TABLE_FeatureLanguage";


        public const string AZURE_STORAGE_TABLE_MODEL = "AZURE_STORAGE_TABLE_MODEL";
        public const string AZURE_STORAGE_TABLE_USER_MANUAL = "AZURE_STORAGE_TABLE_USER_MANUAL";
        public const string AZURE_STORAGE_TABLE_RELEASE_NOTES = "AZURE_STORAGE_TABLE_RELEASE_NOTES";
        public const string AZURE_STORAGE_TABLE_DESTINATION_LANGUAGE = "AZURE_STORAGE_TABLE_DESTINATION_LANGUAGE";
        public const string AZURE_STORAGE_TABLE_MODEL_CODE = "AZURE_STORAGE_TABLE_MODEL_CODE";
        public const string AZURE_STORAGE_TABLE_COUNTRY_MODEL = "AZURE_STORAGE_TABLE_COUNTRY_MODEL";
        public const string AZURE_STORAGE_TABLE_COUNTRY_MASTER = "AZURE_STORAGE_TABLE_COUNTRY_MASTER";
        public const string AZURE_STORAGE_TABLE_USERMANUAL_MASTER = "AZURE_STORAGE_TABLE_USERMANUAL_MASTER";

        public const string DA3_SITE_ORIGIN_ONLY_FOR_CROSS_ORIGIN_VAR = "CROSS_ORIGIN_SITES_ALLOWED";
        public const string DA3_SITE_ORIGIN_TITLE = "DA3_CROSS_SITE_ORIGIN_TITLE";
        public const string DA3_HTTP_CLIENT_NAME = "OTA_CLIENT_CONNECTION_NAME";

        public const string DA3_CLIENT_API_LOGIN = "api/login";
        public const string DA3_CLIENT_API_CREATEPACKAGE = "api/v1.0/externalStorage/createPackageByInventory";
        public const string DA3_CLIENT_API_CREATEPACKAGE_With_Callback = "api/v1.0/externalStorage/createPackageByInventory?callbackUrl=https://suzuki-da3-be-uat.azurewebsites.net/api/UpdateSoftware/callback?Id=";
        public const string DA3_CLIENT_API_UPDATEAVAIALBE = "api/v1.0/externalStorage/{0}";
        public const string DA3_CLIENT_API_DOWNLOADSOFTWARE = "api/v1.0/externalStorage/{0}/download";

        public const string DA3_CLIENT_API_OPERATION = "api/v1.0/operations/filter";

        public const string DA3_CLIENT_API_OPERATION_INVERNTORY = "api/v1.0/operations/{0}/inventory";





    }
}
