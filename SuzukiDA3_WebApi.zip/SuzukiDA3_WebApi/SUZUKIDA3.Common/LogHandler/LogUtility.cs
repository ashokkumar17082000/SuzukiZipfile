﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Common.LogHandler
{
    /// <summary>
    /// Log utility class
    /// </summary>
    public static class LogUtility
    {
        /// <summary>
        /// Builds the exception message.
        /// </summary>
        /// <param name="x">The x.</param>
        /// <returns></returns>
        public static string BuildExceptionMessage(Exception ex)
        {
            Exception logException = ex;
            if (ex.InnerException != null)
            {
                logException = ex.InnerException;
            }

            string strErrorMsg = Environment.NewLine + "Error in Path :";

            strErrorMsg += Environment.NewLine + "Raw Url :";

            strErrorMsg += Environment.NewLine + "Message :" + logException.Message;

            strErrorMsg += Environment.NewLine + "Source :" + logException.Source;

            strErrorMsg += Environment.NewLine + "Stack Trace :" + logException.StackTrace;

            strErrorMsg += Environment.NewLine + "TargetSite :" + logException.TargetSite;

            return strErrorMsg;
        }
    }

}
