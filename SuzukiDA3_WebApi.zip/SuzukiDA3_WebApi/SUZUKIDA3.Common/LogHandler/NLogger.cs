﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUZUKIDA3.Common.LogHandler
{
    /// <summary>
    /// Nlogger class
    /// </summary>
    public static class NLogger
    {

        /// <summary>
        /// The logger private field
        /// </summary>
        private static readonly Logger Logger;

        static NLogger()
        {
            Logger = LogManager.GetCurrentClassLogger();
            LogManager.ThrowExceptions = true;
        }

        #region Public Methods   
        public static void Error(Exception x)
        {
            if (Logger.IsErrorEnabled)
            {
                Error(LogUtility.BuildExceptionMessage(x));
            }
        }

        /// <summary>
        /// Errors the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        public static void Error(string message)
        {
            LogEventInfo eventInfo = new LogEventInfo(LogLevel.Error, string.Empty, message);
            eventInfo.Properties["event-Message"] = message;
            eventInfo.Properties["event-Type"] = "Error";

            if (Logger.IsErrorEnabled)
            {
                Logger.Log(eventInfo);
            }
        }


        /// <summary>
        /// Errors the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="ex">The ex.</param>
        public static void Error(string message, Exception ex)
        {
            LogEventInfo eventInfo = new LogEventInfo(LogLevel.Error, string.Empty, message + ". Execption:" + ex.Message);

            eventInfo.Properties["event-Type"] = "Error";
            eventInfo.Properties["event-StackTrace"] = ex.StackTrace;
            eventInfo.Properties["event-InnerException"] = ex.InnerException != null ? ex.InnerException.ToString() : "N/A";
        }
        #endregion
    }
}
