﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.WebApi.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace SUZUKIDA3.WebApi.TestCase.ControllerTest
{
    public class SoftwareUpdateControllerTest
    {
        private Mock<ISoftwareUpdateService> _softwareUpdateService;
        private SoftwareUpdateController _softwareUpdateController;

        public SoftwareUpdateControllerTest()
        {
            _softwareUpdateService = new Mock<ISoftwareUpdateService>();
           // _softwareUpdateController = new SoftwareUpdateController(_softwareUpdateService.Object);
        }



        [Fact]
        public void ValidateFileUpload_SoftwareUpdate_ActionExecutes()
        {
            using (var stream = File.OpenRead(@"./Images/Dart 1.jpg"))
            {
                var file = new FormFile(stream, 0, stream.Length, null, Path.GetFileName(@"./Images/Dart 1.jpg"))
                {
                    Headers = new HeaderDictionary(),
                    ContentType = "image/jpeg"
                };
                var result = _softwareUpdateController.SoftwareUpdate(file);
                Assert.IsAssignableFrom<OkResult>(result);
            }
        }

    }
}
