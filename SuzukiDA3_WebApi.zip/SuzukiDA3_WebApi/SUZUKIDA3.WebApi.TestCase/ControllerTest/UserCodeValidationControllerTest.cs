﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using SUZUKIDA3.BAL.Implementation;
using SUZUKIDA3.Interfaces.BusinessLayterInterface;
using SUZUKIDA3.WebApi.Controllers;
using SUZUKIDA3.WebApi.TestCase.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Microsoft.Extensions.Configuration;

namespace SUZUKIDA3.WebApi.TestCase.ControllerTest
{
    public class UserCodeValidationControllerTest
    {
        private IUserCodeValidationAzureTableService _userCodeValidationServices;
        //private Mock<IUserCodeValidationAzureTableService> _userCodeValidationServices;
        private UserCodeValidationController _userCodeValidationcontroller;
        private Mock<ITempLoginService> _empLoginService;
        private IConfiguration _configuration;
        public UserCodeValidationControllerTest()
        {
            _configuration = ConfigurationFactory.CreateConfiguration();
           // _userCodeValidationServices = new UserCodeValidationService(_configuration);
            //_userCodeValidationcontroller = new UserCodeValidationController(_userCodeValidationServices);
            //_empLoginService = new Mock<ITempLoginService>();

            //_userCodeValidationServices = new Mock<IUserCodeValidationAzureTableService>();
            //_userCodeValidationcontroller = new UserCodeValidationController(_userCodeValidationServices.Object);
        }

        [Theory]
        [InlineData("b0ecdfc7-14f2-4a35-b2fd-dd3d07f494c3")]
        [InlineData("d961ee6f-0178-420d-a906-4e6746a58582")]
        [InlineData("f08e1ac3-b59f-45aa-a320-6835bef53508")]
        [InlineData("123456")]
        public async void ValidateUserCode_ActionExecutes_ReturnSuccess(string usercode)
        {

            var result = await _userCodeValidationcontroller.ValidateUserCode(usercode);
            var resultType = result as OkObjectResult;


            Assert.NotNull(result);
            //Assert.NotNull(resultType);
            Assert.Equal(200, resultType.StatusCode);
            Assert.IsType<bool>(resultType.Value);
            Assert.Equal(true, resultType.Value);
        }


        [Theory]
        [InlineData("1234567")]
        [InlineData("b0ecdfc7-14f2-4a35-b2fd-dd3d07f494c9")]
        public async void ValidateUserCode_ActionExecutes_ReturnFailedCases(string userCode)
        {

            var result = await _userCodeValidationcontroller.ValidateUserCode(userCode);
            var resultType = result as BadRequestObjectResult;

            Assert.NotNull(result);
            Assert.NotNull(resultType);
            Assert.Equal(400, resultType.StatusCode);
            Assert.IsType<bool>(resultType.Value);
            Assert.Equal(false, resultType.Value);
        }

        [Theory]
        [InlineData("202402")]
        [InlineData("b0ecdfc7-14f2-4a35-b2fd-dd3d07f494c2")]
        public async void ValidateUserCode_ActionExecutes_AddingNewValidationCodes_Pass(string usercode)
        {
            var result = await _userCodeValidationcontroller.CreateUserCode(usercode);
            var resultType = result as OkObjectResult;


            Assert.NotNull(result);
           // Assert.NotNull(resultType);
            Assert.Equal(200, resultType.StatusCode);
            Assert.Equal(true, resultType.Value);

        }


        [Theory]
        [InlineData("202402")]
        [InlineData("b0ecdfc7-14f2-4a35-b2fd-dd3d07f494c2")]
        public async void ValidateUserCode_ActionExecutes_AddingAlreadyAddedCodes_ShouldFail(string usercode)
        {
            var result = await _userCodeValidationcontroller.CreateUserCode(usercode);
            var resultType = result as BadRequestObjectResult;


            Assert.NotNull(result);
            //Assert.NotNull(resultType);
            Assert.Equal(400, resultType.StatusCode);
            Assert.Equal(false, resultType.Value);

        }

        [Theory]
        [InlineData("202402", "202401")]

        public async void ValidateUserCode_ActionExecutes_UpdatingExistingCode_Pass(string oldCode, string userCode)
        {
            var result = await _userCodeValidationcontroller.UpdateUserCode(oldCode, userCode);
            var resultType = result as OkObjectResult;

            Assert.NotNull(result);
            Assert.NotNull(resultType);
            Assert.Equal(200, resultType.StatusCode);
            Assert.Equal(true, resultType.Value);

        }


        [Theory]
        [InlineData("b0ecdfc7-14f2-4a35-b2fd-dd3d07f494c2")]
        public async void ValidateUserCode_ActionExecutes_DeletingCodes_Pass(string userCode)
        {
            var result = await _userCodeValidationcontroller.DeleteUserCode(userCode);
            var resultType = result as OkObjectResult;

            Assert.NotNull(result);
            Assert.NotNull(resultType);
            Assert.Equal(200, resultType.StatusCode);
            Assert.Equal(true, resultType.Value);
        }


    }
}
