﻿namespace SUZUKIDA3.TestCase
{
    public class Class1
    {

    }
}