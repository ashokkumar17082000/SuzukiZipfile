import { environment } from "./environment.development";

export const apiUrls = {
    _auth: {
        authenticate: `${environment.httpsApiUrl}Auth/authenticate`,
        getall: `${environment.httpsApiUrl}Auth`,
        getById: (userId: number) => `${environment.httpsApiUrl}Auth/${userId}`

    },
    _language: {
        getAll: `${environment.httpsApiUrl}Language/GetAllLanguage`,
        getByCode: (langcode: string) => `${environment.httpsApiUrl}Language/code/${langcode}`
    },
    _model: {
        getAll: `${environment.httpsApiUrl}model/GetAllModelCode`,
        getModelCodeByCountry: (DestinationId:number,CountryId: number) => `${environment.httpsApiUrl}Model/GetModelCodeByCountry?DestinationId=${DestinationId }&CountryId=${CountryId}`
    },
    _country:{
            getAll:`${environment.httpsApiUrl}Model/GetCountryList`,
    },
    _userManual: {
        getAll: `${environment.httpsApiUrl}model/GetAllUserManual`,
        getUserManualData:(userManualId: number,destinationId:number) => `${environment.httpsApiUrl}Model/GetUserManualData?userManualId=${userManualId }&destinationId=${destinationId}`
    },
    _faq: {
        getAllByLanguage: (languagecode: string) => `${environment.httpsApiUrl}Faq/GetFaq?languageCode=${languagecode}`,
        getFaqDetail: (languagecode: string,url_ref: string) => `${environment.httpsApiUrl}Faq/GetDetail?languageCode=${languagecode}&urlReference=${url_ref}`,

    },
    _certificate: {
        getAll: `${environment.httpsApiUrl}Certificate/GetAllCertificates`,
    },
    _oss: {
        getAll: `${environment.httpsApiUrl}OSS/GetAllOssFiles`,
    },
    _feature: {
        getAll: `${environment.httpsApiUrl}Feature`,
        getById: (FeatureId: number) => `${environment.httpsApiUrl}Feature/${FeatureId}`,
        getByName: (name: string) => `${environment.httpsApiUrl}Feature/ByName/${name}`,
        add: `${environment.httpsApiUrl}Feature`,
        batch: `${environment.httpsApiUrl}Feature/Batch`,
        update: (FeatureId: number) => `${environment.httpsApiUrl}Feature/${FeatureId}`,
        delete: (FeatureId: number) => `${environment.httpsApiUrl}Feature/${FeatureId}`,
    },
    _deviceCompatability: {
        getAllRegions: `${environment.httpsApiUrl}DeviceCompatibility/GetAllRegion`,
        getAllManufacturers: `${environment.httpsApiUrl}DeviceCompatibility/GetAllManufacturerName`,
        getAllDevices: `${environment.httpsApiUrl}DeviceCompatibility/GetDeviceName`,
        getAllOS: `${environment.httpsApiUrl}DeviceCompatibility/GetOSName`,
        getDeviceOSFeatures: `${environment.httpsApiUrl}DeviceCompatibility/GetDeviceOSFeatures`,

    },
   
    _upload: {
        add: `${environment.httpsApiUrl}Upload/UploadAsync/`,
        get: `${environment.httpApiUrl}Upload/download/`
    },
    _tempLogin: {
        authenticate: (userId: string) => `${environment.httpsApiUrl}TempLogin/${userId}`,
    },
    _validateUserCode: {
        authenticate: (validationCode: string) => `${environment.httpsApiUrl}UserCodeValidation/${validationCode}`,

    }
};