export const environment = {
  baseUrl: window.location.origin,
  production: false,
  httpsApiUrl: 'https://suzuki-da3-be-uat.azurewebsites.net/api/',
  recaptcha: {
    siteKey: '6LcxLTYpAAAAAGHYpNjmU6_7CeLpahvRaGeZMStQ',
    siteKeyV2: '6Ld8RjgpAAAAANXiou_AwKAWblLcw5ur_CqonJtX'
  },
  googleAnalyticsId: "G-3D4X701QRL"
};

