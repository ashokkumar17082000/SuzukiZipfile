export const pageUrls = {
    _site:[
        {
            url:'/site/home',
            displayName:'HOME',
            keyword:'home'
        },
      
        {
            url:'/site/manual',
            displayName:'USER MANUAL',
            keyword:'manual'

        }
        ,
        {
            url:'/site/device',
            displayName:'DEVICE COMPATIBILITY',
            keyword:'device'

        },
        {
            url:'/site/software',
            displayName:'SOFTWARE UPDATE',
            keyword:'software'
        },
       
        {
            url:'/site/certificate',
            displayName:'CERTIFICATE',
            keyword:'certificate'

        },
        {
            url:'/site/oss',
            displayName:'OSS',
            keyword:'oss'

        },
        {
            url:'/site/faq',
            displayName:'FAQ',
            keyword:'faq'

        },
    ],
    _adminDashboard:[
        {
            url:'/admin/dashboard',
            displayName:'Dashboard'

        },
        {
            url:'/admin/manufacturer',
            displayName:'Manufacturers'

        },
        {
            url:'/admin/feature',
            displayName:'Features'

        },
        {
            url:'/admin/device',
            displayName:'Devices'
        },
        {
            url:'/admin/osversion',
            displayName:'OS Versions'
        }
    ]
}