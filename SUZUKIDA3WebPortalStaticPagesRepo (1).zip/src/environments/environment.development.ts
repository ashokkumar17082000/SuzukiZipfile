export const environment = {
  baseUrl: window.location.origin,
  production: false,
  httpApiUrl:'http://localhost:7063/api/',
//   httpsApiUrl: 'https://suzuki-da3-be-dev.azurewebsites.net/api/',
  httpsApiUrl: 'https://suzuki-da3-be-uat.azurewebsites.net/api/',
  recaptcha: {
    siteKey: '6LcxLTYpAAAAAGHYpNjmU6_7CeLpahvRaGeZMStQ',
    siteKeyV2: '6Ld8RjgpAAAAANXiou_AwKAWblLcw5ur_CqonJtX'
  },
  googleAnalyticsId: "G-3D4X701QRL",

  msalConfig: {
    auth: {
        clientId: "67c13f68-5ce7-4524-95eb-50af43a68fde",
        tenantId:"bad45162-d87b-4ec6-a3b4-f2192bbbed18",
        issuer: "https://suzukida3app.onmicrosoft.com/67c13f68-5ce7-4524-95eb-50af43a68fde/v2.0/"
    }
},
apiConfig: {
    scopes: ["https://suzukida3app.onmicrosoft.com/67c13f68-5ce7-4524-95eb-50af43a68fde/Api.Read"],
    uri: "https://suzukida3app.onmicrosoft.com/67c13f68-5ce7-4524-95eb-50af43a68fde"
},
b2cPolicies: {
    names: {
        signUpSignIn: "B2C_1_SocialSignIn",
    },
    authorities: {
        signUpSignIn: {
            authority: "https://suzukida3app.b2clogin.com/suzukida3app.onmicrosoft.com/B2C_1_SocialSignIn"
        } 
    },
    authorityDomain: "suzukida3app.onmicrosoft.com"
}
};



