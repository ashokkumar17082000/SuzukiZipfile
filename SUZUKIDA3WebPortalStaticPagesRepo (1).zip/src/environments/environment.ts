export const environment = {
  baseUrl: window.location.origin,
  production: true,
  httpsApiUrl: 'https://suzuki-da3-be-uat.azurewebsites.net/api/',
  recaptcha: {
    siteKey: '6LcxLTYpAAAAAGHYpNjmU6_7CeLpahvRaGeZMStQ',
    siteKeyV2: '6Ld8RjgpAAAAANXiou_AwKAWblLcw5ur_CqonJtX'
  },
  googleAnalyticsId: "G-3D4X701QRL",
  msalConfig: {
    auth: {
        clientId: "cd73538d-cc5f-4a90-9a56-7698d2f6179b",
        tenantId:"bad45162-d87b-4ec6-a3b4-f2192bbbed18",
        issuer: "https://suzukida3app.b2clogin.com/bad45162-d87b-4ec6-a3b4-f2192bbbed18/v2.0/"
    }
},
apiConfig: {
    scopes: ["https://suzukida3app.onmicrosoft.com/cd73538d-cc5f-4a90-9a56-7698d2f6179b/api.read"],
    uri: "https://suzukida3app.onmicrosoft.com/cd73538d-cc5f-4a90-9a56-7698d2f6179b"
},
b2cPolicies: {
    names: {
        signUpSignIn: "B2C_1_SuzukiAuthentication",
    },
    authorities: {
        signUpSignIn: {
            authority: "https://suzukida3app.b2clogin.com/suzukida3app.onmicrosoft.com/b2c_1_susi_reset_v2"
        } 
    },
    authorityDomain: "suzukida3app.onmicrosoft.com"
}
};
