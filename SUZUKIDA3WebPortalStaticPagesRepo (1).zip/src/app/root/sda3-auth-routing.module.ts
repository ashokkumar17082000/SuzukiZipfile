import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GenerateOTPComponent } from '../pages/generate-otp/generate-otp.component';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { TempLoginComponent } from '../pages/temp-login/temp-login.component';
import { Sda3AuthComponent } from './sda3-auth/sda3-auth.component';


const routes: Routes = [
 
  {path:'',component:Sda3AuthComponent,
  children: [
    { path: '', redirectTo: 'enter', pathMatch: 'full' },
    { path: 'enter', component: TempLoginComponent, },
    { path: 'GenerateOTP', component: GenerateOTPComponent },
    { path: 'notfound', component: NotFoundComponent },
    {path:'**',redirectTo:'/notfound'}
  ]
},

];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Sda3AuthRoutingModule { }
