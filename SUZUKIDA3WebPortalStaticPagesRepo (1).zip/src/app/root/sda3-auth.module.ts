import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Sda3AuthRoutingModule } from './sda3-auth-routing.module';
import { Sda3AuthComponent } from './sda3-auth/sda3-auth.component';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    Sda3AuthRoutingModule,
    RouterModule,MaterialModule  
  ],
  providers: [],
  bootstrap:[Sda3AuthComponent]
})
export class Sda3AuthModule { }
