import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MSAL_GUARD_CONFIG, MsalBroadcastService, MsalGuardConfiguration, MsalService } from '@azure/msal-angular';
import { filter, Subject, takeUntil } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AuthenticationResult, InteractionStatus, PopupRequest, RedirectRequest, EventMessage, EventType, InteractionType, AccountInfo, SsoSilentRequest, IdTokenClaims, PromptValue } from '@azure/msal-browser';



@Component({
  selector: 'app-sda3-dealer',
  templateUrl: './sda3-dealer.component.html',
  styleUrls: ['./sda3-dealer.component.css']
})



export class Sda3DealerComponent {
  Localdata: any;
  sessionData:any;
  

  constructor() { 

    this.Localdata=localStorage; 
    this.sessionData=sessionStorage;
  }
  ngOnInit(): void {
    
 }


}
