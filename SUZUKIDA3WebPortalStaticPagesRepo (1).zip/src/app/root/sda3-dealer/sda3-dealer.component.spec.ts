import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sda3DealerComponent } from './sda3-dealer.component';

describe('Sda3DealerComponent', () => {
  let component: Sda3DealerComponent;
  let fixture: ComponentFixture<Sda3DealerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Sda3DealerComponent]
    });
    fixture = TestBed.createComponent(Sda3DealerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
