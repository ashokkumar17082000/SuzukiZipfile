import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sda3Component } from './sda3.component';

describe('Sda3Component', () => {
  let component: Sda3Component;
  let fixture: ComponentFixture<Sda3Component>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Sda3Component]
    });
    fixture = TestBed.createComponent(Sda3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
