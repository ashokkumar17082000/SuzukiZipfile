import { Component } from '@angular/core';

@Component({
  selector: 'app-sda3',
  templateUrl: './sda3.component.html',
  styleUrls: ['./sda3.component.css']
})
export class Sda3Component {

  Localdata: any;
  sessionData:any;
  
  constructor() {
   
    this.Localdata=localStorage; 
    this.sessionData=sessionStorage;
   
  }
 
   ngOnInit() {
    this.sessionData=sessionStorage;
  }
}
