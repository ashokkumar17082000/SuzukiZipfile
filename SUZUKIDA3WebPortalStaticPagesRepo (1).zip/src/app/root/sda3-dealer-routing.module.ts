import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Da3SoftwareUpdateComponent } from '../pages/da3-software-update/da3-software-update.component';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { HomeComponent } from '../pages/home/home.component';
import { Sda3DealerComponent } from './sda3-dealer/sda3-dealer.component';

const routes: Routes = [
 
  {path:'',component:Sda3DealerComponent,
  children: [
    { path: '', redirectTo: 'software', pathMatch: 'full' },
    { path: 'software', component: Da3SoftwareUpdateComponent },
    { path: 'notfound', component: NotFoundComponent },
    { path: '**', redirectTo: "notfound", pathMatch: 'full' },
  ]
},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Sda3DealerRoutingModule { }
