import { Component } from '@angular/core';

@Component({
  selector: 'app-sda3-auth',
  templateUrl: './sda3-auth.component.html',
  styleUrls: ['./sda3-auth.component.css']
})
export class Sda3AuthComponent {

  Localdata: any;
  sessionData:any;
  
  constructor() {
   
    this.Localdata=localStorage; 
    this.sessionData=sessionStorage;
      
  }
 
   ngOnInit() {
    this.sessionData=sessionStorage;
   
  }
}
