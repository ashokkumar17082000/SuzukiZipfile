import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Sda3AuthComponent } from './sda3-auth.component';

describe('Sda3AuthComponent', () => {
  let component: Sda3AuthComponent;
  let fixture: ComponentFixture<Sda3AuthComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Sda3AuthComponent]
    });
    fixture = TestBed.createComponent(Sda3AuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
