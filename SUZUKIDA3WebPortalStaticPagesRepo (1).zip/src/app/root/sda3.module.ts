import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Sda3RoutingModule } from './sda3-routing.module';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { Sda3Component } from './sda3/sda3.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    Sda3RoutingModule,
    RouterModule,MaterialModule  
  ],
  providers: [],
  bootstrap:[Sda3Component]
})
export class Sda3Module { }
