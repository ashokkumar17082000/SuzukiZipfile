import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { Sda3RoutingModule } from './sda3-routing.module';
import { Sda3DealerRoutingModule } from './sda3-dealer-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    Sda3DealerRoutingModule,
    RouterModule,MaterialModule  
  ],
  providers: [],
  bootstrap:[Sda3DealerModule]
})
export class Sda3DealerModule { }
