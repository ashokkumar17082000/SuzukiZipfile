import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Da3SoftwareUpdateComponent } from '../pages/da3-software-update/da3-software-update.component';
import { NotFoundComponent } from '../pages/not-found/not-found.component';
import { Sda3Component } from './sda3/sda3.component';
import { HomeComponent } from '../pages/home/home.component';
import { UserManualsComponent } from '../pages/user-manuals/user-manuals.component';
import { OssComponent } from '../pages/oss/oss.component';
import { PrivacyPolicyPageComponent } from '../pages/privacy-policy-page/privacy-policy-page.component';
import { PolicyComponent } from '../pages/privacy-policy-page/policy/policy.component';
import { UsageComponent } from '../pages/privacy-policy-page/usage/usage.component';
import { CompatibilityComponent } from '../pages/device-compatibility/compatibility.component';
import { CertificationComponent } from '../pages/certification/certification.component';
import { FaqComponent } from '../pages/faq/faq.component';
import { FaqDetailComponent } from '../pages/faq/faq-detail/faq-detail.component';
import { NavigationComponent } from '../pages/navigation/navigation.component';

const routes: Routes = [
 
  {path:'',component:Sda3Component,
  children: [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'software', component: Da3SoftwareUpdateComponent },
    { path: 'manual', component: UserManualsComponent },
    { path: 'device', component: CompatibilityComponent },
    { path: 'oss', component: OssComponent },
    { path: 'certificates', component: CertificationComponent },
    { path: 'faq', component: FaqComponent },
    { path: 'android-auto', component: FaqDetailComponent },
    { path: 'privacy-policy', component: PrivacyPolicyPageComponent },
    { path: 'policy', component: PolicyComponent },
    { path: 'usage', component: UsageComponent },
    { path: 'navigation', component: NavigationComponent },

    { path: 'notfound', component: NotFoundComponent },
    { path: '**', redirectTo: "notfound", pathMatch: 'full' },
  ]
},

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class Sda3RoutingModule { }
