import { AppRoutingModule } from './app-routing.module';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { LoadingScreenComponent } from './widgets/loading-screen/loading-screen.component';
import { SpinnerComponent } from './widgets/spinner/spinner.component';
import { RouterModule } from '@angular/router';
import { FooterComponent } from './widgets/footer/footer.component';
import { MaterialModule } from './material/material.module';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatIconModule } from '@angular/material/icon'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SuzukiLogoComponent } from './widgets/suzuki-logo/suzuki-logo.component';
import { HeaderComponent } from './widgets/header/header.component';
import { TranslocoRootModule } from './transloco-root.module';
import { TranslocoModule } from '@ngneat/transloco';
import { LanguageComponent } from './widgets/language/language.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthInterceptor } from './helpers/interceptors/auth.interceptor';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { CommonService } from './services/common.service';
import { SafeHtmlPipe } from './helpers/safe-html.pipe';
import { RECAPTCHA_SETTINGS, RecaptchaFormsModule, RecaptchaModule, RecaptchaSettings } from 'ng-recaptcha';
import { environment } from 'src/environments/environment';
import { CacheService } from 'src/app/services/cache.service';
import { GoogleAnalyticsServiceService } from './google-analytics-service.service';
import { MenuComponent } from './widgets/menu/menu.component';
import { CookieBarComponent } from './widgets/cookie-bar/cookie-bar.component';
import { HomeComponent } from './pages/home/home.component';
import { Sda3Component } from './root/sda3/sda3.component';
import { Da3SoftwareUpdateComponent } from './pages/da3-software-update/da3-software-update.component';
import { GenerateOTPComponent } from './pages/generate-otp/generate-otp.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { PrivacyPolicyPageComponent } from './pages/privacy-policy-page/privacy-policy-page.component';
import { TempLoginComponent } from './pages/temp-login/temp-login.component';
import { SwLandingTextComponent } from './widgets/Guidelines/sw-landing-text.component';
import { UpdateAvailabilityComponent } from './widgets/Guidelines/update-availability/update-availability.component';
import { Da3HeaderComponent } from './widgets/da3-header/da3-header.component';
import { Da3NavComponent } from './widgets/da3-nav/da3-nav.component';
import { Da3footerComponent } from './widgets/da3footer/da3footer.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { Sda3AuthComponent } from './root/sda3-auth/sda3-auth.component';
import { UserManualsComponent } from './pages/user-manuals/user-manuals.component';
import { OssComponent } from './pages/oss/oss.component';
import { PolicyComponent } from './pages/privacy-policy-page/policy/policy.component';
import { DownloadService } from './services/download.service';
import { CompatibilityComponent } from './pages/device-compatibility/compatibility.component';
import { CertificationComponent } from './pages/certification/certification.component';
import { FaqComponent } from './pages/faq/faq.component';
import { FaqDetailComponent } from './pages/faq/faq-detail/faq-detail.component';
import { Sda3DealerComponent } from './root/sda3-dealer/sda3-dealer.component';
import { NavigationComponent } from './pages/navigation/navigation.component';
import { MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG, MsalBroadcastService, MsalGuard, MsalInterceptor, MsalModule, MsalRedirectComponent, MsalService } from '@azure/msal-angular';
import { MSALInstanceFactory, MSALGuardConfigFactory, MSALInterceptorConfigFactory } from './helpers/interceptors/Azure-Auth/azure-auth-config';



@NgModule({
  declarations: [AppComponent, LoadingScreenComponent, SpinnerComponent, SafeHtmlPipe,  HeaderComponent,FooterComponent, MenuComponent, CookieBarComponent, LanguageComponent,HomeComponent,Sda3AuthComponent,Sda3DealerComponent, Sda3Component,
    Da3HeaderComponent,
    Da3NavComponent,
    Da3SoftwareUpdateComponent,
    Da3footerComponent,
    TempLoginComponent,
    NotFoundComponent,
    HomeComponent,
    UserManualsComponent,
    OssComponent,
    CookieBarComponent,
    PrivacyPolicyPageComponent,
    PolicyComponent,
    UpdateAvailabilityComponent,
    SwLandingTextComponent,
    CompatibilityComponent,
    CertificationComponent,
    OssComponent,
    FaqComponent,
    NavigationComponent,
    FaqDetailComponent,
    GenerateOTPComponent,
  ],

    providers: [GoogleAnalyticsServiceService, CacheService, CommonService,DownloadService,
      {
        provide: RECAPTCHA_SETTINGS,
        useValue: {
          siteKey: environment.recaptcha.siteKeyV2,
        } as RecaptchaSettings,
      }, 
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService
    ],
  imports: [BrowserModule ,RouterModule, AppRoutingModule,SlickCarouselModule,ReactiveFormsModule, MaterialModule, FormsModule, HttpClientModule, FlexLayoutModule, BrowserAnimationsModule,
     TranslocoRootModule, TranslocoModule, CKEditorModule, SuzukiLogoComponent, RecaptchaModule, RecaptchaFormsModule, MatIconModule,MsalModule,  
    ], 

  bootstrap: [AppComponent,MsalRedirectComponent],
  exports:[]
})
export class AppModule {

}
