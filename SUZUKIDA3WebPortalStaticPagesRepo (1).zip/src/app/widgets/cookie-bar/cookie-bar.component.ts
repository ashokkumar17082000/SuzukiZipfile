import { Component } from '@angular/core';

@Component({
  selector: 'app-cookie-bar',
  templateUrl: './cookie-bar.component.html',
  styleUrls: ['./cookie-bar.component.css']
})
export class CookieBarComponent{
 
  enableCookies(e:any){
    localStorage.setItem("cookies_status","true");
  }
}
