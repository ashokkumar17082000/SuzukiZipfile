import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslocoService } from '@ngneat/transloco';
import { map } from 'rxjs';
import { LanguageModel } from 'src/app/interfaces/iLanguage';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { apiUrls } from 'src/environments/api.urls';

@Component({
  selector: 'app-language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.css']
})
export class LanguageComponent implements OnInit {
  @ViewChild('languageSelect') languageSelect: ElementRef;


  public languages: any;
  public current_language: any;
  selectControl: FormControl;
  selectedLanguage:any;
  sessiondata=sessionStorage;
  constructor(private translocoService: TranslocoService,
    private _snackBar: MatSnackBar,
    private _loaderService: LoaderService,
    private _commonService: CommonService<LanguageModel[]>) {
      this.selectControl = new FormControl('');
     }

  ngOnInit() {
    this.getallLanguages();
    // this.languageSelect.nativeElement.selectedValue=sessionStorage.getItem('current_Lang');
  }
  
  async getallLanguages() {
    let url=apiUrls._language.getAll;
    await this._commonService.get(url).pipe(
      map((res: LanguageModel[]) => {
        return res.map(languages => {
          return {
            languageCode: languages.languageCode,
            languageDisplayName: languages.languageDisplayName,
            isActive: languages.entityStatus,
            order:languages.order
          }
        }
        )
      })
    ).subscribe((res) => {
      this.languages = res.filter(x=>x.isActive==1).sort((a,b)=>(a.order>b.order)?1:-1);
      // this.selectedLanguage='en-us'
    })
  }
 
  onChangeLanguage() {

    const selectedValue = this.languageSelect.nativeElement.value;
    this.languageSelect.nativeElement.value='';

    if (this.translocoService.getAvailableLangs().includes(selectedValue) && selectedValue != null) {
      sessionStorage.setItem("current_Lang", selectedValue);
      this.translocoService.setActiveLang(sessionStorage.getItem("current_Lang"));
      this._loaderService.reloadComponent();

    } else {
      this._snackBar.open('Error:  translation is not avaliable', 'Cancel', {
        horizontalPosition: "end",
        verticalPosition: "top",
        panelClass: 'app-notification-error',
      });
    }

  }

}
