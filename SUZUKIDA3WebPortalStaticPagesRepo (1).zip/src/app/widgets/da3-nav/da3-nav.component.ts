import { Component } from '@angular/core';

@Component({
  selector: 'app-da3-nav',
  templateUrl: './da3-nav.component.html',
  styleUrls: ['./da3-nav.component.css']
})
export class Da3NavComponent {

}
