import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Da3NavComponent } from './da3-nav.component';

describe('Da3NavComponent', () => {
  let component: Da3NavComponent;
  let fixture: ComponentFixture<Da3NavComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Da3NavComponent]
    });
    fixture = TestBed.createComponent(Da3NavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
