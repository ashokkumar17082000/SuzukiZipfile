import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isLoggedIn: Boolean = false;
  localdata: any;
  public username;
  dealerSign:number=0;
  constructor(public dialog: MatDialog,private authService:MsalService,private router: Router) {
  }

  ngOnInit(): void {
    this.localdata = localStorage;
    const currentAccounts = this.authService.instance.getActiveAccount();
    const dealerSigned=sessionStorage.getItem('dealerSigned');
    
    if(this.router.url.startsWith('dealer/',1) && dealerSigned == '1' ){
      this.dealerSign=1;
      this.username=currentAccounts.name;
    }

  }

  Signout() { 
    this.authService.logoutPopup({
      mainWindowRedirectUri: "/"
  });
  }

}
