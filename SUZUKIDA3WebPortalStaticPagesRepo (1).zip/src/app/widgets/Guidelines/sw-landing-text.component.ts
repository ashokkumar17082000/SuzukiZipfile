import { Component } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { UpdateProcedurePageComponent } from '../../pages/update-procedure-page/update-procedure-page.component';

@Component({
  selector: 'app-sw-landing-text',
  templateUrl: './sw-landing-text.component.html',
  styleUrls: ['./sw-landing-text.component.css']
})
export class SwLandingTextComponent {

  constructor(private bottomSheet: MatBottomSheet) {


  }


  openInstructionsPage() {
    this.bottomSheet.open(UpdateProcedurePageComponent);
  }
}
