import { Component } from '@angular/core';

@Component({
  selector: 'app-update-availability',
  templateUrl: './update-availability.component.html',
  styleUrls: ['./update-availability.component.css']
})
export class UpdateAvailabilityComponent {


  onClickDownloadSoftware(){
    
  }
}
