import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwLandingTextComponent } from './sw-landing-text.component';

describe('SwLandingTextComponent', () => {
  let component: SwLandingTextComponent;
  let fixture: ComponentFixture<SwLandingTextComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SwLandingTextComponent]
    });
    fixture = TestBed.createComponent(SwLandingTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
