import { Component } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { Router } from '@angular/router';

@Component({
  selector: 'app-da3footer',
  templateUrl: './da3footer.component.html',
  styleUrls: ['./da3footer.component.css']
})
export class Da3footerComponent {

  constructor(private bottomSheet: MatBottomSheet,private router:Router) {
  }


}
