import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Da3footerComponent } from './da3footer.component';

describe('Da3footerComponent', () => {
  let component: Da3footerComponent;
  let fixture: ComponentFixture<Da3footerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Da3footerComponent]
    });
    fixture = TestBed.createComponent(Da3footerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
