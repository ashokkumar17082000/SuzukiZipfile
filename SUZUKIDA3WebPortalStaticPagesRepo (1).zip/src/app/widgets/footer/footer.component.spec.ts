import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppRootFooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: AppRootFooterComponent;
  let fixture: ComponentFixture<AppRootFooterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AppRootFooterComponent]
    });
    fixture = TestBed.createComponent(AppRootFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
