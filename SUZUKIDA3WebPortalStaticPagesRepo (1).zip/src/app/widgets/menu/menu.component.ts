import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Route, Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { LocalService } from 'src/app/services/local.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css'],
})
export class MenuComponent implements OnInit {
  currentUrl: string;

  constructor(private sessionService: LocalService,private authService: MsalService,private router: Router) { 

    this.handleDealerUrlChange(router.url);
  }
  public menuConfig;

  ngOnInit(): void {
   
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Handle URL change here
        this.currentUrl = event.urlAfterRedirects;
        this.handleDealerUrlChange(this.currentUrl);
      }
    });

  }

  handleDealerUrlChange(url:string){
    if(sessionStorage.getItem('menuConfiguration').length>0)
      {
      this.menuConfig=JSON.parse(sessionStorage.getItem('menuConfiguration'));
      }

      if(url.startsWith('/dealer/')){
        for (const key in this.menuConfig) {
          if (key !='software' ) {
            this.menuConfig[key] = false;
          }
        }
      }else{
        this.menuConfig=JSON.parse(sessionStorage.getItem('menuConfiguration'));
      }
  }
}
