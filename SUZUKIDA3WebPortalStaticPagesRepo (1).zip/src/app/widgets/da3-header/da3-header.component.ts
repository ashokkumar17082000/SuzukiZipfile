import { Component } from '@angular/core';
import { DomSanitizer,SafeResourceUrl } from '@angular/platform-browser';
@Component({
  selector: 'app-da3-header',
  templateUrl: './da3-header.component.html',
  styleUrls: ['./da3-header.component.css']
})
export class Da3HeaderComponent {

  constructor(private sanitizer:DomSanitizer){
    
  }

  // getAssetUrl(assetPath:string):SafeResourceUrl{
  //   const fullPath = `@Images/${assetPath}`;
  //   return this.sanitizer.bypassSecurityTrustResourceUrl(fullPath);
  // }

}
