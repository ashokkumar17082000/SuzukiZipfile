import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Da3HeaderComponent } from './da3-header.component';

describe('Da3HeaderComponent', () => {
  let component: Da3HeaderComponent;
  let fixture: ComponentFixture<Da3HeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Da3HeaderComponent]
    });
    fixture = TestBed.createComponent(Da3HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
