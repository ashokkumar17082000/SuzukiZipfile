import { Component } from '@angular/core';

@Component({
  selector: 'app-suzuki-logo',
  templateUrl: './suzuki-logo.component.html',
  styleUrls: ['./suzuki-logo.component.css'],
  standalone:true
})
export class SuzukiLogoComponent {

}
