import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuzukiLogoComponent } from './suzuki-logo.component';

describe('SuzukiLogoComponent', () => {
  let component: SuzukiLogoComponent;
  let fixture: ComponentFixture<SuzukiLogoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuzukiLogoComponent]
    });
    fixture = TestBed.createComponent(SuzukiLogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
