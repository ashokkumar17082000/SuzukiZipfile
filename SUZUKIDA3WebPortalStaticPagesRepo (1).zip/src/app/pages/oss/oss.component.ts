import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { map } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { apiUrls } from 'src/environments/api.urls';

@Component({
  selector: 'app-oss',
  templateUrl: './oss.component.html',
  styleUrls: ['./oss.component.css']
})
export class OssComponent {
  public license_Exsiss: boolean = true;
  oss:any;
  constructor(public dialog: MatDialog,
    private _commonService:CommonService<any[]>,
    private _snackBar: MatSnackBar,
    private _loaderService:LoaderService
    ) {

      this._loaderService.update$.subscribe(() => {
            this.ngOnInit();
      });

    }

  ngOnInit(): void {
    this.getAllOSS();
  }
  getAllOSS() {
    this._commonService.get(apiUrls._oss.getAll)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:any[])=>{
      this.oss=res;
  });
  }
}
