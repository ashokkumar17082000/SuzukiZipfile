import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FaqModel } from '../../interfaces/iFaq';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { CommonService } from 'src/app/services/common.service';
import { apiUrls } from 'src/environments/api.urls';
import { TranslocoService } from '@ngneat/transloco';
import { Observable, map } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';


@Component({
    selector: 'app-faq',
    templateUrl:'faq.component.html',
    styleUrls: ['./faq.component.css'],
})
export class FaqComponent implements OnInit {

    panelOpenState: boolean[] = [];
    FaqData:any;
    localdata:any;
    data:FaqModel[];
    csvContent: string | null = null;
    fileContent: string = '';



    constructor(public dialog: MatDialog,
      private _commonService:CommonService<FaqModel[]>,
      private _snackBar: MatSnackBar,
      private _loaderService:LoaderService,
      private _transalco:TranslocoService
      ) {
  
        this._loaderService.update$.subscribe(() => {
              this.ngOnInit();
        });
  
      }
  ngOnInit() {
    this.getAllFAQ();
  }

  getAllFAQ() {
    console.log(this._transalco.getActiveLang());
    this._commonService.get(apiUrls._faq.getAllByLanguage(this._transalco.getActiveLang()))
    .pipe(map((result:FaqModel[])=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:FaqModel[])=>{
      this.FaqData=res;
  });
  }


}
