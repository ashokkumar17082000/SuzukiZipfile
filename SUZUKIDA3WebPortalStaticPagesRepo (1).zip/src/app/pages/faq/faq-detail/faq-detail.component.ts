import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { apiUrls } from 'src/environments/api.urls';
import { TranslocoService } from '@ngneat/transloco';
import { map } from 'rxjs';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-faq-detail',
  templateUrl: './faq-detail.component.html',
  styleUrls: ['./faq-detail.component.css'],
})
export class FaqDetailComponent implements OnInit {

  public FaqDetailData: SafeHtml[];
  faqdata:any;

  constructor(
    private _transalco: TranslocoService,
    private sanitizer: DomSanitizer,
    private _commonservice: CommonService<any[]>,
    private _loaderService: LoaderService
    ) {

    this._loaderService.update$.subscribe(() => {
      this.ngOnInit();
    });
  }

  ngOnInit() {
    this.FaqDetailData = [];
    this.getFAQDetail();
  }

  getFAQDetail() {
    console.log(this._transalco.getActiveLang())
    this._commonservice.get(apiUrls._faq.getFaqDetail(this._transalco.getActiveLang(), 'android-auto'))
      .pipe(map((result: any[]) => {
        return result.filter(x=> x.entityStatus == 1)

      }))
      .subscribe((res: any[]) => {
        for (let data of res) {
          this.FaqDetailData.push(this.sanitizeHtml(data['content']))
        }
      });
  }

  sanitizeHtml(html: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }

  
  handleClick(event: Event) {

    event.preventDefault();
    const target = event.target as HTMLElement;
    console.log(target.getAttribute('fragment'))

    if (target.tagName === 'A' && target.getAttribute('fragment')) {
      const id = target.getAttribute('fragment');
      this.scrollToElement(id);
    }
  }

  scrollToElement(id: string) {
    document.querySelector('#'+id).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }



}
