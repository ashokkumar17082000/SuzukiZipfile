import { Component, OnInit, ViewChild } from '@angular/core';
import { SlickCarouselComponent } from 'ngx-slick-carousel';
import { LoaderService } from 'src/app/services/loader.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  @ViewChild('slickModal') slickModal: SlickCarouselComponent;
  data:any;
  slidesStore = [
    {
      img: 'assets/images/home/Infotainment1.png'
    },
    {
      img: 'assets/images/home/Infotainment2.png'
    },
    {
      img: 'assets/images/home/Infotainment1.png'
    }
  ];

  slideConfig:any ;

  constructor(private _loaderService:LoaderService){
   
    this._loaderService.update$.subscribe(() => {
      this.slickModal.slickGoTo(0);
          this.ngOnInit();
    });
  }
  ngOnInit(): void {
  
    this.slideConfig={
      "slidesToShow": 1,
      "slidesToScroll": 1,
      "autplay": true,
       "rtl":sessionStorage.getItem("current_Lang")=='ar',
      "autoplaySpeed": 200,
      "pauseOnHover": true,
      "infinite": true,
      "arrows": true,
      "responsive": [
        {
          "breakpoint": 992,
          "settings": {
            "arrows": true,
            "Infinte": true,
            "autplay": true,
            "slidesToShow": 1,
            "slidesToScroll":1,
          }
        },
        {
          "breakpoint": 768,
          "settings": {
            "arrows": false,
            "Infinte": true,
            "slidesToShow": 1,
            "slidesToScroll": 1,
          }
        }
      ]
    };

  
  }

}
