import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SoftwareDownloadServiceAgreementComponent } from './software-download-service-agreement.component';

describe('SoftwareDownloadServiceAgreementComponent', () => {
  let component: SoftwareDownloadServiceAgreementComponent;
  let fixture: ComponentFixture<SoftwareDownloadServiceAgreementComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SoftwareDownloadServiceAgreementComponent]
    });
    fixture = TestBed.createComponent(SoftwareDownloadServiceAgreementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
