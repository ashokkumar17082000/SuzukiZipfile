import { Component } from '@angular/core';

@Component({
  selector: 'app-software-download-service-agreement',
  templateUrl: './software-download-service-agreement.component.html',
  styleUrls: ['./software-download-service-agreement.component.css']
})
export class SoftwareDownloadServiceAgreementComponent {

}
