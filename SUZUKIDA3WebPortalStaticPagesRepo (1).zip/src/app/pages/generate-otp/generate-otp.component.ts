import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmailCommunicationService } from 'src/app/services/email-communication.service';
@Component({
  selector: 'app-generate-otp',
  templateUrl: './generate-otp.component.html',
  styleUrls: ['./generate-otp.component.css']
})
export class GenerateOTPComponent  {
  public emailId: string = "";
  public isAttemptBlocked: boolean = false;
  public loginErrorMessage: string = "";
  public loginAttemptsCount: number = 0;

  constructor(
    private _router: Router,
    private readonly route: ActivatedRoute,
    private _emailcommunicationservice: EmailCommunicationService) {

  }

  public send(): void {
    this.GenerateUserCode(this.emailId);
  }
 
  /**
   * GenerateUserCode
   */
  public GenerateUserCode(emailId: string): void {
    this._emailcommunicationservice.SendEmail(emailId).subscribe((response: any) => {
      console.log(response);
    }, error => {
      console.log(error);
    });

    this._router.navigate(['enter'], { relativeTo: this.route.parent });
  }
}
