import  * as fileSaver from 'file-saver';
import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css'],
})
export class TestComponent {
value:number=50;

public addedFile: File | null = null;
  constructor(private http: HttpClient) {}

  download() {
    let blob = new Blob(['Hello, world!'], {
      type: 'text/plain;charset=utf-8',
    });
    const url = window.URL.createObjectURL(blob);
    fileSaver.saveAs(blob, 'hello world.txt');
  }

  filedownloadAPI() {

    this.saveTxtToFile('myFile.json', JSON.stringify({"key":"value"}));
    
    let downloadUrl: string =
      'https://localhost:7063/api/_0Test/DecryptFile';

    const formData: FormData = new FormData();
    formData.append('file', this.addedFile, this.addedFile.name);

    this.http
      .post(downloadUrl, formData, { responseType: 'blob' })
      .subscribe(
        (response:any) => {
          console.log('Success!');
          console.log(response);
          let blob: any = new Blob([response], { type: 'text/json; charset=utf-8', });
     
          
          fileSaver.saveAs(blob, "rb_update_1706098305761.zip");
        },
        (error) => {
          console.log('show error occured.');
          console.log(error);
        }
      );
  }

  fileInputChangeHandler(event: any) {
    this.addedFile = event.target.files[0];
    event.preventDefault();
    
  }

   saveTxtToFile(fileName: string, textData: string) {
    const blobData = new Blob([textData], { type: 'text/plain' });
    const urlToBlob = window.URL.createObjectURL(blobData);
  
    const a = document.createElement('a');
    a.style.setProperty('display', 'none');
    document.body.appendChild(a);
    a.href = urlToBlob;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(urlToBlob);
    a.remove();
  }
  
 




}
