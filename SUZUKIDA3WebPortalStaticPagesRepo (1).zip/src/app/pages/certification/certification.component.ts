import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from 'src/app/services/common.service';
import { apiUrls } from 'src/environments/api.urls';
import { map } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.css']
})
export class CertificationComponent implements OnInit{

  localdata:any;
  certificates:any;
  constructor(public dialog: MatDialog,
    private _commonService:CommonService<any[]>,
    private _loaderService:LoaderService
    ) {

      this._loaderService.update$.subscribe(() => {
            this.ngOnInit();
      });

    }

  ngOnInit(): void {
    this.localdata=localStorage
    this.getAllCertificates()
  }
  getAllCertificates() {
    this._commonService.get(apiUrls._certificate.getAll)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:any[])=>{
      this.certificates=res;
  });
  }

  

}
