import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserManualsComponent } from './user-manuals.component';

describe('UserManualsComponent', () => {
  let component: UserManualsComponent;
  let fixture: ComponentFixture<UserManualsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UserManualsComponent]
    });
    fixture = TestBed.createComponent(UserManualsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
