import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { apiUrls } from 'src/environments/api.urls';
import { iModel } from 'src/app/interfaces/IModel';
import { map } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { toNumber } from '@ngneat/transloco';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-user-manuals',
  templateUrl: './user-manuals.component.html',
  styleUrls: ['./user-manuals.component.css']
})
export class UserManualsComponent implements OnInit {
  @ViewChild('modelSelect') modelSelect: ElementRef;
  @ViewChild('countrySelect') countrySelect: ElementRef;


  model_val: any;
  // private _AlluserManuals: any;
  public models: any;
  public userManuals: any[];
  modelgroup: string;
  localdata: any;
  CountryMasterList:any[];
  ModelCodeResult:any[];
  UserManualResult:any[];
  ManualRequested:number=0;
  SelectedModel:any;
  SelectedCountry:any;

  constructor(private _commonService: CommonService<iModel>,
    private _snackBar: MatSnackBar,
    private _loaderService: LoaderService,
  ) {

    this._loaderService.update$.subscribe(() => {
      this.resetEle();
      this.ngOnInit();
    });


  }

  ngOnInit() {
    this.localdata = localStorage;
    // this.getAllModels();
    // this.getAllUserManuals();
    this.getAllCountry()
  }

  resetEle() {
    this.modelSelect.nativeElement.value = '';
    this.countrySelect.nativeElement.value = '';
    this.ModelCodeResult=null;
    this.CountryMasterList=null;
    this.UserManualResult=null;
    this.ManualRequested=0;
  }

  // getAllModels() {
  //   this._commonService.get(apiUrls._model.getAll).pipe(
  //     map((res: any[]) => {
  //       console.log(res);
  //       return res.map(data => {
  //         return {
  //           modelName: data.modelName,
  //           modelCode: data.modelCode,
  //           modelGroup: data.modelGroup,
  //           modelGroupOrder: data.modelGroupOrder,
  //           order: data.order,
  //           partition: toNumber(data.partitionKey),
  //           isActive: data.entityStatus
  //         }
  //       }
  //       )
  //     })
  //   )
  //     .subscribe((res: any[]) => {
  //       this.models = res.filter(res => res.isActive == 1).sort((a, b) => 
  //           a.partition>b.partition?1:-1
  //      );
  //     });
  // }


  getAllCountry() {
   
    let apiCallUrl=apiUrls._country.getAll;
    
    this._commonService.get(apiCallUrl).subscribe((res:any[])=>{
      this.CountryMasterList=res.sort((a, b) => a.countryName < b.countryName?-1:1);
      //   {
      //   // Assuming 'name' is the property you want to sort by
      //   if (a.countryName < b.countryName) {
      //     return -1;
      //   }
      //   if (a.countryName > b.countryName) {
      //     return 1;
      //   }
      //   return 0;
      // });
    // console.log(res);

    });
  }


  // getAllUserManuals() {
  //   this._commonService.get(apiUrls._userManual.getAll).pipe(
  //     map((res: any[]) => {
  //       return res.map(data => {
  //         return {
  //           manualLanguage: data.manualLanguage,
  //           modelCode: data.modelCode,
  //           isActive: data.entityStatus,
  //           manualPath: data.manualPath,
  //           modifiedDate: data.timestamp ,
  //           order: data.order,
  //         }
  //       }
  //       )
  //     })
  //   )
  //     .subscribe((res: any[]) => {
  //       this._AlluserManuals = res.filter(res => res.isActive == 1).sort((a) => a.order);
  //     });
  // }


  OnchangeCountry(e:any){

    const selectedCountryId = Number(e.target.value);
    this.SelectedCountry = this.CountryMasterList.find(country => country.countryID === selectedCountryId);
    this.ModelCodeResult=null;
    this.ManualRequested=0;

    let apiCallUrl=apiUrls._model.getModelCodeByCountry(this.SelectedCountry.destinationID,this.SelectedCountry.countryID);
    this._commonService.get(apiCallUrl).subscribe((res:any[])=>{
      this.ModelCodeResult=res;
    });

}

  // modelchange(e: any) {
  //   let selectedModelCode = e.target.value;
  //   this.userManuals=this._AlluserManuals.filter(data=> data.modelCode==selectedModelCode)
  //   this.model_val = selectedModelCode;
  // }

  Onmodelchange(e:any) {
    let selectedModelCodeYear = e.target.value;
    
    this.SelectedModel=this.ModelCodeResult.find(data=> data.modelcodename_year === selectedModelCodeYear);



    this.UserManualResult = [];
    this.ManualRequested=0;
    

    if(this.SelectedModel != null)
      {
        let apiCallUrl=apiUrls._userManual.getUserManualData(this.SelectedModel.userManualID,this.SelectedModel.destinationID);

        this._commonService.get(apiCallUrl).subscribe((res:any[])=>{
        this.UserManualResult=res;
        if(this.UserManualResult.length >  0){
          this.ManualRequested=1;
        }else{
          this.ManualRequested=-1;
        }
        console.log(this.UserManualResult,this.ManualRequested)

      });
      
      this.model_val=selectedModelCodeYear;

     
      
    }
   

    
    // this.model_val = selectedModelCode;
    //console.log(this.model_val)
  }
}
