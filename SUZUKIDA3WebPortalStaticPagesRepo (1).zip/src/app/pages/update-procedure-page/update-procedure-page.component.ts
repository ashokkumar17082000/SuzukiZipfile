import { Component } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';

@Component({
  selector: 'app-update-procedure-page',
  templateUrl: './update-procedure-page.component.html',
  styleUrls: ['./update-procedure-page.component.css']
})
export class UpdateProcedurePageComponent {
  constructor(private bottomsheet:MatBottomSheet){

  }


  closethisBrowser(){
    this.bottomsheet.dismiss();
  }

}
