import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateProcedurePageComponent } from './update-procedure-page.component';

describe('UpdateProcedurePageComponent', () => {
  let component: UpdateProcedurePageComponent;
  let fixture: ComponentFixture<UpdateProcedurePageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateProcedurePageComponent]
    });
    fixture = TestBed.createComponent(UpdateProcedurePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
