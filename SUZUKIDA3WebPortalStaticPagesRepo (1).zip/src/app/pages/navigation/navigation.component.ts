import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { LocalService } from 'src/app/services/local.service';
import { pageUrls } from 'src/environments/page.urls';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent  implements OnInit{
  constructor(private sessionService: LocalService,private _formBuilder: FormBuilder) { }
  menuItems=pageUrls._site;
  sessiondata;

  isChecked=true;


  ngOnInit(): void {
    this.sessiondata=JSON.parse(sessionStorage.getItem('menuConfiguration'));
}




  setSession(formGroup: FormGroup) {
    // console.log(JSON.stringify(formGroup.value, null, 2));
    let status=confirm('are you sure to save the configuration?');
    if(status){
      sessionStorage.setItem('menuConfiguration',JSON.stringify(formGroup.value, null, 2))
    }

  }


  toggleMenuItem(item: string) {
    const currentVisibility = this.sessionService.getMenuItemVisibility(item);
    this.sessionService.setMenuItemVisibility(item, !currentVisibility);
  }

}

