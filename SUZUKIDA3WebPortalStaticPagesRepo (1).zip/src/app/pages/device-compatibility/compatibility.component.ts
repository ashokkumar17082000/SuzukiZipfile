import { group } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DomSanitizer } from '@angular/platform-browser';
import { TranslocoService, toNumber } from '@ngneat/transloco';
import { map } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { apiUrls } from 'src/environments/api.urls';
@Component({
  selector: 'app-compatibility',
  templateUrl: './compatibility.component.html',
  styleUrls: ['./compatibility.component.css']
})
export class CompatibilityComponent implements OnInit {
  deviceinfo: any;
  searchresults:any;
  slideConfig = {
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "autplay": true,
    "autoplaySpeed": 200,
    "pauseOnHover": true,
    "infinite": true,
    "arrows": true,
    "dots": true,
    "responsive": [
      {
        "breakpoint": 992,
        "settings": {
          "arrows": true,
          "dots": true,
          "Infinte": true,
          "slidesToShow": 1,
          "slidesToScroll": 1,
        }
      },
      {
        "breakpoint": 768,
        "settings": {
          "arrows": false,
          "dots": false,
          "Infinte": true,
          "slidesToShow": 1,
          "slidesToScroll": 1,
        }
      }
    ]
  };
  public manufacturers:any;
  public regions:any;
  public filteredDevices:any;
  public filteredOSVersions:any[];
  public filteredDeviceOSFeatures: { [key: number]: {[key: string]:{[key: string]:any[]}} } = {};
  public loading = false;
  private Devices:any;
  private selectedManfacturer:number;
  private selectedDevice:number;

  public filteredPhones:any[];
  private Os:any[];
  filteredManufacturers: any;
  selectedRegion: number;

  constructor(private snatize:DomSanitizer,private _commonService:CommonService<any>,private _loaderService:LoaderService,    private _snackBar: MatSnackBar,
    private translocoService: TranslocoService){
    this._loaderService.update$.subscribe(() => {
      this.ngOnInit();
    });
  }

  ngOnInit(): void {
  
    this.deviceinfo = {
      regionId:'',
      manufactureID: '',
      deviceID: '',
      osID: '',
      languageCode:this.translocoService.getActiveLang()
    };
    this.searchresults=false;
    this.getAllRegions();
    this.getAllManufacturers();
    this.getAllDevices();
    this.getAllOS();
  }

  searchCompatability(){
      this.loading = true;
      let OrderList=['Hands Free','Contacts','Media (iPod over Bluetooth)','Media (iPod over USB)','Media (Standard Bluetooth Audio)','SMS','Apple CarPlay™ / Android Auto™'];

      this._commonService.post(apiUrls._deviceCompatability.getDeviceOSFeatures,this.deviceinfo).subscribe(
        (response) => {
       //   this.filteredDeviceOSFeatures=response;
       if(response!=null){

          let data = this.groupData(response,'featureOrder' ,'category','featureCategory');
          this.filteredDeviceOSFeatures = data;
          console.log(this.filteredDeviceOSFeatures)

          this.searchresults=true;
          this.loading = false;

       }else{
           this.searchresults=false;
           this.loading = false;

           this._snackBar.open('OS Features were not avaliable', 'Cancel', {
            horizontalPosition: "end",
            verticalPosition: "top",
            panelClass: 'app-notification-error',
          });
       }

        },
        (error) => {
          this.searchresults=false;
          this._snackBar.open('OS Features were not avaliable', 'Cancel', {
            horizontalPosition: "end",
            verticalPosition: "top",
            panelClass: 'app-notification-error',
          });
          // console.error('Error:', error);
        }
      );
  }


  
  groupData(data: any[],key1: string, key2: string, key3: string): { [key: string]: { [key: string]: { [key: string]: any[] } } } {

    return data.reduce((groups, item) => {
      const group1 = item[key1];
      const group2 = item[key2];
      const group3 = item[key3];


      groups[group1] = groups[group1] || {};
      groups[group1][group2] = groups[group1][group2] || [];
      groups[group1][group2][group3] = groups[group1][group2][group3] || [];
    
      groups[group1][group2][group3].push(item);
      
      return groups;
    }, {});
  
  }

  getAllRegions(){
    this._commonService.get(apiUrls._deviceCompatability.getAllRegions)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:any[])=>{
      this.regions=res;
  });
  }


  getAllManufacturers(){
    this._commonService.get(apiUrls._deviceCompatability.getAllManufacturers)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:any[])=>{
      this.manufacturers=res.sort((a,b)=> a.order> b.order?1:-1);
  });
  }

  getAllDevices(){
    this._commonService.get(apiUrls._deviceCompatability.getAllDevices)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)
    }))
    .subscribe((res:any[])=>{
      this.Devices=res.sort((a,b)=> a.order> b.order?1:-1);
  });
  }


  getAllOS(){
    this._commonService.get(apiUrls._deviceCompatability.getAllOS)
    .pipe(map((result:any)=>{
      return result.filter(x=> x.entityStatus == 1)

    }))
    .subscribe((res:any[])=>{
     this.Os=res;
  });
  }

  getManufacturers(e:any){
    this.deviceinfo.manufactureID='';
    this.deviceinfo.deviceID='';
    this.deviceinfo.osID='';
    this.selectedRegion=toNumber(e.target.value);
    this.filteredManufacturers= this.manufacturers.filter(z=>z.regionId==this.selectedRegion);
  }
  
  getDevices(e:any){
    
    this.deviceinfo.deviceID='';
    this.deviceinfo.osID='';

    this.selectedManfacturer=toNumber(e.target.value);
    this.filteredDevices= this.Devices.filter(z=> z.manufacturerRefId==this.selectedManfacturer);
 }


 getDeviceOS(e:any){
  this.deviceinfo.osID='';
  this.selectedDevice=toNumber(e.target.value);
  this.filteredOSVersions= this.Os.filter(z=>z.manufacturerRefId==this.selectedManfacturer && z.deviceRefId==this.selectedDevice);
}






}
