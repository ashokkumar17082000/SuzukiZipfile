import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-usage',
  templateUrl: './usage.component.html',
  styleUrls: ['./usage.component.css']
})
export class UsageComponent implements OnInit {

  private language;
  constructor(private _loaderService:LoaderService,private router:Router){
   
    this._loaderService.update$.subscribe(() => {
          this.ngOnInit();
    });
  }

  ngOnInit(): void {
    this.language= sessionStorage.getItem("current_Lang");
    if(this.language !='ja'){
      this.router.navigate(['notfound']);
    }
  }
}
