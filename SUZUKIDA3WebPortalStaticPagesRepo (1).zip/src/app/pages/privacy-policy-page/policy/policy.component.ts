import { Component } from '@angular/core';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent {
  scroll(id){
    document.querySelector(id).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
