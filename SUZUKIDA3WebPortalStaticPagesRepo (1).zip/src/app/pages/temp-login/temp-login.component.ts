import { LocalService } from '../../services/local.service';
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { apiUrls } from 'src/environments/api.urls';
import { LoaderService } from 'src/app/services/loader.service';
import { TempAuthGuardService } from 'src/app/services/temp-auth-guard.service';

@Component({
  selector: 'app-temp-login',
  templateUrl: './temp-login.component.html',
  styleUrls: ['./temp-login.component.css']
})
export class TempLoginComponent {

  public entryCode: string = "";
  public isAttemptBlocked: boolean = false;
  public loginErrorMessage: string = "";
  public loginAttemptsCount: number = 0;
  token: string | undefined;

  constructor(
    private _router: Router,
    private readonly route: ActivatedRoute,
    private _commonService: CommonService<any>,
    private _loader: LoaderService,
    private _tempLoginService: TempAuthGuardService,
    private _localservice: LocalService) {
    this.token = undefined;
    if (this._tempLoginService.IsUserCodeValidated()) {

       this._router.navigate(['/site/home'], { relativeTo: this.route.parent });
    }
    this.checkIsAttemptsValid();
  }

  public send(form: NgForm): void {
    if (form.invalid) {
      for (const control of Object.keys(form.controls)) {
        form.controls[control].markAsTouched();
      }
      return;
    }

    this.validateLogin(this.entryCode);
  }

  navigateToUserCode($myParam: string = ''): void {
    this._router.navigate(['GenerateOTP'], { relativeTo: this.route.parent });
  }
  ValidateErrorMsg($myParam: string = ''): void {
    if (this.entryCode != null) {
      this.loginErrorMessage = '';
    }
  }
  public validateLogin(userId: string) {
    this.loginAttemptsCount++;
    this.checkIsAttemptsValid();

    this._tempLoginService.SetLoginAttemp(this.loginAttemptsCount);

    this._loader.setLoading(true);
    this._commonService.get(apiUrls._validateUserCode.authenticate(userId)).subscribe((res) => {
      if (res) {

        this._loader.setLoading(false);
        this._localservice.setBool("TEMPLOGIN", true);
        sessionStorage.setItem("TEMPLOGIN", "1");
        this._router.navigate(['/site/home'], { relativeTo: this.route.parent });

      } else {
        this.loginErrorMessage = "Invalid Code. Please try again.";
        this._loader.setLoading(false);
      }
    }, (err) => {
      this.loginErrorMessage = "Connection failed. Please try again.";
      this._loader.setLoading(false);
    });
  }


  public getErrorMessage() {
    return this.loginErrorMessage;
  }
  private checkIsAttemptsValid() {
    let isInvalidLogin: boolean = this._tempLoginService.getIsLoginAttemptInvalid();
    if (isInvalidLogin) {
      this.isAttemptBlocked = isInvalidLogin;
      this.loginErrorMessage = "Too many wrong login attempts. Please try after some time!";
    } else {
    }

  }
}
