import { LocalService } from './../../services/local.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Component, ViewChild, ElementRef, NgZone, ChangeDetectorRef, OnInit } from '@angular/core';
import { STEPPER_GLOBAL_OPTIONS, StepperOrientation } from '@angular/cdk/stepper';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatStepper } from '@angular/material/stepper';
import { LoaderService } from 'src/app/services/loader.service';
import { SoftwareUpdateService } from 'src/app/services/software-update.service';
import { HttpClient, HttpErrorResponse, HttpEventType, HttpHeaders, HttpResponse } from '@angular/common/http';
import { ErrorCode, SoftwaerErrorResponse } from 'src/app/interfaces/iSoftwareErrorResponse';
import { ActivatedRoute, Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { TempAuthGuardService } from 'src/app/services/temp-auth-guard.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { SoftwareDownloadServiceAgreementComponent } from '../software-download-service-agreement/software-download-service-agreement.component';
import { GoogleAnalyticsServiceService } from 'src/app/google-analytics-service.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/app/services/common.service';
import { DownloadService } from 'src/app/services/download.service';
import { apiUrls } from 'src/environments/api.urls';
import { UpdateProcedurePageComponent } from '../update-procedure-page/update-procedure-page.component';
import { SoftwareUpdateCallBackResponse } from 'src/app/interfaces/iSoftwareUpdatePackageResponse';
const maxfileSize: number = 1024 * 1024 * 2;

@Component({
  selector: 'app-da3-software-update',
  templateUrl: './da3-software-update.component.html',
  styleUrls: ['./da3-software-update.component.css'],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false },
    },
  ],
})

export class Da3SoftwareUpdateComponent implements OnInit {
  public addedFile: File | null = null;
  public reportFile: File | null = null;
  public isErrorOccured: boolean = false;
  public isReportUpdate: boolean = false;
  public isValidfile: boolean = true;
  public ProgressMode: any = 'query';
  public progressHide: boolean = true;
  public progressPercent: number = undefined;
  public progressPercentText: string;
  public isDownloadDisabled:boolean=false;
  
  responseResult:SoftwareUpdateCallBackResponse;
  softwareName:string;
  softwareVersion:string;
  private DownloadUrl:string;


  progress = 0;
  message = '';

  token: string | undefined;
  public responseMessage: string = "";
  PackageID: string | undefined;
  private uri = "https://test.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL/rb_update_1711389830430.zip";
  
  @ViewChild('files_upload_control') FilesUploadControl: ElementRef;
  
  public isFileAdded: boolean = false;
  public isReportFileAdded: boolean = false;
  @ViewChild('stepper') public softwareStepper: MatStepper;
  @ViewChild('downloadLink', { static: false }) downloadLinkRef: ElementRef;

  accepedfileFormat: string[] = ["application/json", "json"];
  firstFormGroup = this._formBuilder.group({
    // firstCtrl: ['', Validators.required],
  });
  secondFormGroup = this._formBuilder.group({
    softwareUpdateFileInput: ['', Validators.required],//, fileSizeValidator(1024 * 1024 * 5)],
    // recaptcha: ["", Validators.required]
  });


  thirdFormGroup = this._formBuilder.group({
    // thirdFormGroup: ['', Validators.required],
  });
  
  fourthFormGroup = this._formBuilder.group({
    ReportUpdateFileInput: ['', Validators.required],
  });

  CompletedFormGroup = this._formBuilder.group({});

  stepperOrientation: Observable<StepperOrientation>;

  constructor(private _formBuilder: FormBuilder,
    breakpointObserver: BreakpointObserver,
    private _loader: LoaderService,
    private _localService: LocalService,
    private http: HttpClient,
    private _commonService: CommonService<Blob>,
    private softwareUpdatesvc: SoftwareUpdateService,
    private _zone: NgZone,
    private _cdr: ChangeDetectorRef,
    private _router: Router,
    private _snackBar: MatSnackBar,
    private bottomSheet: MatBottomSheet,
    private _tempLoginService: TempAuthGuardService,
    private readonly route: ActivatedRoute,
    private fileDownloadService: DownloadService,
    private readonly googleAnalyticsService: GoogleAnalyticsServiceService) {
    this.stepperOrientation = breakpointObserver
      .observe('(min-width: 800px)')
      .pipe(map(({ matches }) => (matches ? 'horizontal' : 'vertical')));
    this.token = undefined;

    // this.softwareStepper.linear = false;


  }

  ngOnInit(): void {
    if (environment.production) {
      this.googleAnalyticsService.initialize();
    }

  }
  ngAfterViewInit() {

    // this.gotoCompleted(this.softwareStepper,true,"");
    // this._cdr.detectChanges()
  }

  clearUploadFileControl(file: File | null) {

    this.addedFile = null;
    this.isFileAdded = false;
    this.secondFormGroup.get("softwareUpdateFileInput").setValue(null);
    this.clearFileControls();

  }
  clearFileControls() {

    this.addedFile = null;
    this.isFileAdded = false;
    if (this.FilesUploadControl)
      this.FilesUploadControl.nativeElement.value = '';
  }
  fileInputChangeHandler(event: any) {
    this._loader.setLoading(true);
    let aryCurFiles = event.target.files[0];

    this.addedFile = aryCurFiles;
    if (this.addedFile) {
      if (this.isJsonFile(this.addedFile) && this.addedFile.size < maxfileSize) {
        this.isValidfile = true;
        this.isFileAdded = true;
        this._loader.setLoading(false);
      } else {
        // if (!this.isJsonFile(this.addedFile)) {
        //   this.showSnackbarerrorMessage("The In-vehicle Device Information File should be JSON format file only!");
        // } else if (this.addedFile.size > maxfileSize) {
        //   this.showSnackbarerrorMessage("The In-vehicle Device Information File size should not exceed 5MB!");
        // }

        this.clearFileControls();
        this.isValidfile = false;
      }
    }
    this._loader.setLoading(false);
  }
  moveStepper(index: number, stepper: MatStepper) {
    this.softwareStepper.selectedIndex = index;
    if (index == 3) {
      stepper.linear = false;
    }
    stepper.selectedIndex = index;

  }
  clearReportUploadFileControl(file: File | null) {
    this.reportFile = null;
    this.isReportFileAdded = false;
  }
  reportfileInputChangeHandler(event: any) {

    this.reportFile = event.target.files[0];
    if (this.reportFile || '') {
      if (this.isJsonFile(this.reportFile)) {
        this.isReportFileAdded = true;
      }
    }
  }


  reportSoftwareUpdate(stepper: MatStepper) {
    this._loader.setLoading(true);
    this.softwareUpdatesvc.uploadFile(this.reportFile).then(response => {
      this.isErrorOccured = false;
      this.isReportUpdate = false;
      this.gotoCompleted(stepper);
    }).catch(error => {
      this.isReportUpdate = true;
      this.isErrorOccured = true;
      this.handleErrorResponseWithFromBlob(error, stepper);
    });

  }

  InfotainmentSoftwareUpdate(stepper: MatStepper) {
    stepper.next();
    stepper.linear = false;
    if (this.addedFile == null) {
      return;
    }
    this._loader.setLoading(true);

    // this.softwareUpdatesvc.downloadSoftwareAlfaUpdate(this.addedFile).then(response => {
    // //this.softwareUpdatesvc.downloadFile(this.addedFile).then(blob => {
    // // this.softwareUpdatesvc.downloadWithArryBuffer(this.addedFile).then(response => {
    //   this.isErrorOccured = false;
    //   let filename= "SUZUKI_Software_update.zip"
    //   // this.saveArrayBufferFile(response, filename);
    //  // this.downloadFileToDownloadsFolder(response.blob);
    //    this.saveFile(response.blob, response.fileName);
    //   this.gotoCompleted(stepper);
    // })
    //   .catch(error => {
    //     stepper.next();
    //     this.isErrorOccured = true;
    //     console.log(error);
    //     this.gotoCompleted(stepper);
    //     this.handleErrorResponseWithFromBlob(error, stepper);
    //   });


    this.softwareUpdatesvc.downloadFileLargeWithName(this.addedFile).subscribe((response: HttpResponse<Blob>) => {
      const contentDispositionHeader = response.headers.get('Content-Disposition');
      const fileName = this.getFilenameFromContentDisposition(contentDispositionHeader);

      const blob = new Blob([response.body], { type: 'application/octet-stream' });
      this.saveFile(blob, fileName);
      this.gotoCompleted(stepper);
    }, (error: HttpErrorResponse) => {
      stepper.next();
      this.isErrorOccured = true;
      this.gotoCompleted(stepper);
      this.handleErrorResponseWithFromBlob(error, stepper);
    });


  }

  private saveArrayBufferFile(data: ArrayBuffer, filename: string): void {
    const blob = new Blob([data], { type: 'application/zip' });

    if (window.navigator && window.navigator['msSaveOrOpenBlob']) {
      // For IE
      window.navigator['msSaveOrOpenBlob'](blob, filename);
    } else {
      // For other browsers
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }

  private saveFile(blob: Blob, fileName: string) {
    saveAs(blob, fileName);
  }

  onClickSoftwareUpdate(stepper: MatStepper) {
    //this.openServiceAgrementPage();
    //this.InfotainmentSoftwareUpdate(stepper);
    this.onClickCheckSoftwareUpdateAvailabel(stepper);
  }

  validateCaptcha(secondFormGroup: NgForm) {
    if (secondFormGroup.invalid) {
      for (const control of Object.keys(secondFormGroup.controls)) {
        secondFormGroup.controls[control].markAsTouched();
      }
      return;
    }
  }

  gotoCompleted(stepper: MatStepper, showSuccess?: boolean, message?: string) {
    this._cdr.detectChanges();
    this._loader.setLoading(false);
    this._zone.run(() => {
      stepper.selected.completed = true;
      stepper.selected.editable = false;
      stepper.next();
      stepper.selectedIndex = stepper.steps.length - 1;

      this.softwareStepper.selected.completed = true;
      this.softwareStepper.selected.editable = false;
      this.softwareStepper.next();
      this.softwareStepper.selectedIndex = this.softwareStepper.steps.length - 1;
      this._cdr.detectChanges();
    });
    this.softwareStepper.selectedIndex = this.softwareStepper.steps.length - 1;
    this.onProcessCompleted();
  }

  getFilenameFromContentDisposition(contentDispositionHeader: string) {
    const fileNameMatch = /filename="?([^"]+)"?/i.exec(contentDispositionHeader);
    const fileName = fileNameMatch && fileNameMatch[1] ? fileNameMatch[1] : 'SUZUKI_Software_Update_download.zip';

    return fileName;
  }

  onProcessCompleted() {
    this.reportFile = null;
    this.isReportFileAdded = false;
    this.addedFile = null;
    this.isFileAdded = false;
  }


  restStepper(stepper: MatStepper) {
    this.isErrorOccured = false;
    this.isReportUpdate = false;
    this.onProcessCompleted();
    stepper.reset();
    this.responseMessage = "";

  }

  handleErrorResponseWithFromBlob(error: HttpErrorResponse, stepper: MatStepper) {
    if (error.error instanceof Blob) {
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const errorObject: SoftwaerErrorResponse = JSON.parse(reader.result as string);
          this.handleShownErrorMessages(errorObject);
          this.gotoCompleted(stepper);
        } catch (parseError) {
          let data: SoftwaerErrorResponse = { errorCode: ErrorCode.ResponseLoadFailed, message: "" };
          this.handleShownErrorMessages(data);
          this.gotoCompleted(stepper);
        }
      };
      reader.readAsText(error.error);
    } else {
      this.responseMessage = "Connection failed!";
      this.gotoCompleted(stepper);
    }

  }

  handleShownErrorMessages(errorObject: SoftwaerErrorResponse) {
    if (errorObject && errorObject.errorCode) {
      switch (errorObject.errorCode) {

        case ErrorCode.InternalServerError:
          this.responseMessage = "Internal server error. Network connection failed!";
          break;
        case ErrorCode.CorruptedFile:
          this.responseMessage = "The In-vehicle Device Information File is incorrect or corrupt. Please upload a correct file.";
          break;
        case ErrorCode.FetchCredentialsFailed:
          this.responseMessage = "Unable to establish a connection with Software Update Server. Please try again later.";
          break;
        case ErrorCode.ClientAuthenticationFailed:
          this.responseMessage = "Unable to establish a connection with Software Update Server. Please try again later.";
          break;
        case ErrorCode.DownloadFailed:
          this.responseMessage = "Software update download failed!";
          break;
        case ErrorCode.UpdateNotAvailable:
          this.responseMessage = "The In-vehicle Device Information File is incorrect or corrupt. Please upload a correct file.";
          break;
        case ErrorCode.ResponseLoadFailed:
          this.responseMessage = "Failed to downlaod software. Please try again.";
          break;
        default:
          this.responseMessage = "Unknow error!";
          break;
      }
      // });

    }

    if(errorObject.customErrorCode.length>0){
      this.responseMessage = errorObject.message;
    }


  }

  private isJsonFile(file: File): boolean {
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    return fileExtension === 'json';
  }

  getFileNameFromResponse(response: string): string {
    const contentDispositionHeader = response || 'application/octet-stream';
    //const contentDispositionHeader = response.headers.get('Content-Disposition');
    const fileNameMatch = /filename="?([^"]+)"?/i.exec(contentDispositionHeader);
    const fileName = fileNameMatch && fileNameMatch[1] ? fileNameMatch[1] : 'unknown';
    return fileName && fileName.length > 1 ? fileName[1] : 'download.zip';
  }

  private showSnackbarerrorMessage(msg: string) {
    this._snackBar.open(msg, 'close', {
      horizontalPosition: "end",
      verticalPosition: "top",
      panelClass: 'app-notification-error',
      duration: 3000
    });
  }
  private downloadFileToDownloadsFolder(blob: Blob) {
    const blobUrl = window.URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = blobUrl;
    anchor.download = 'SUZUKI_Software_Update.zip';
    // Specify the desired file name
    anchor.click();
    window.URL.revokeObjectURL(blobUrl);

  }

  openServiceAgrementPage() {
    this.bottomSheet.open(SoftwareDownloadServiceAgreementComponent);
  }


  onClickDownloadSoftware(stepper: MatStepper) {
    this.gotoNextStep(stepper);
    this._loader.setLoading(true);
    
    setTimeout(() => {
      this.downloadFile(this.responseResult.downloadUri);
      this.gotoCompleted(stepper);
    }, 5000); 


    // this.softwareUpdatesvc.downloadSoftwareByPackageID(this.PackageID).subscribe((response: HttpResponse<Blob>) => {
    //   const contentDispositionHeader = response.headers.get('Content-Disposition');
    //   const fileName = this.getFilenameFromContentDisposition(contentDispositionHeader);
    //   const blob = new Blob([response.body], { type: 'application/octet-stream' });

    //   this.saveFile(blob, fileName);
    //   this.gotoCompleted(stepper);
    // }, (error: HttpErrorResponse) => {
    //   this.isErrorOccured = true;
    //   this.gotoCompleted(stepper);
    //   this.handleErrorResponseWithFromBlob(error, stepper);
    // });

  }


  onClickCheckSoftwareUpdateAvailabel(stepper: MatStepper) {
    this._loader.setLoading(true);
   
    let error:SoftwaerErrorResponse;
   
    // this.responseResult= {
    //   packageID: "psdjakjdas",
    //   softwareName: "rb_update_1710231383612.zip",
    //   softwareVersion: "400",
    //   downloadUri: "https://sda3blob.blob.core.windows.net/sda3container/rb_update_1710231383612.zip",
    //   errorCode: "",
    //   errorMessage: ""
    // };
    
    let IsDealer=sessionStorage.getItem('dealerSigned');

    this.softwareUpdatesvc.verifyUpdateAvailable(this.addedFile,IsDealer=='1'?true:false)
      .subscribe(
        response => {
          this._loader.setLoading(false);
          // this.PackageID = response.packageID.toString();
          // this.gotoNextStep(stepper);
          this.responseResult=response;
          console.log(this.responseResult)
          if(this.responseResult.downloadUri.length == 0 || this.responseResult.errorCode.toString().length>0 ){
            this.isErrorOccured = true;
            this.gotoCompleted(stepper);
            error= {
              errorCode:null,
              customErrorCode: this.responseResult.errorCode,
              message: this.responseResult.errorMessage
            }
            if (this.responseResult.errorCode.length != 0) {
                  this.handleShownErrorMessages(error);
              }
      
          }else{
            this._loader.setLoading(false);
            this.PackageID = this.responseResult.packageID.toString();
            this.softwareName=this.responseResult.softwareName.toString();
            this.softwareVersion=this.responseResult.softwareVersion.toString();
      
            this.gotoNextStep(stepper);
          }

        },
        error => {
          this.isErrorOccured = true;
          this.gotoCompleted(stepper);
          console.log(error);

          if (error['error'] != null) {

            this.handleShownErrorMessages(error['error']);
          }
        })

  }

  gotoNextStep(stepper: MatStepper) {
    this._zone.run(() => {
      stepper.selected.completed = true;
      stepper.selected.editable = false;
      stepper.next();
    });


  }


  downloadFile(fileUrl:string): void {
    const link = document.createElement('a');
    // link.setAttribute('target', '_blank');
    link.setAttribute('href', fileUrl);
    link.setAttribute('download', this.responseResult.softwareName);
    document.body.appendChild(link);
    link.click();
    link.remove();
  }




  // downloadRenameUri() {

  //   let fileUrl = 'https://test.device.smartplayprosync.com:443/VrmDLServerWEB/servlet/RequestDPServlet/EXTERNAL/rb_update_1711389830430.zip';
   
  //   this.ProgressMode = 'query';
  //   this.progressPercent=0;
  //   this.progressPercentText='';
  //   this.isDownloadDisabled=true;

  //    console.time("Request time");

  //   const headers = new HttpHeaders().set('filename', "C:/SuzukiDA3WebPortalSU_2902/SUZUKIDA3.WebApi/Local_packages_2gb.zip");

  //   this.http.get(apiUrls._upload.get, {
  //     headers: headers ,
  //     reportProgress: true,
  //     responseType: 'blob',
  //     observe: 'events'
  //   }).subscribe({
  //     next: (result) => {
  //        console.timeLog("Request time");
  //         this.progressHide=false;
  //         if (result.type === HttpEventType.DownloadProgress) {
       
  //           this.ProgressMode = 'determinate';
  //           this.progressPercent = Math.round(100 * result.loaded / result.total);
    
  //           let totalSize = result.total / 1000000;
  //           let downloadSize = result.loaded / 1000000;
    
  //           let downloadSizeValue = downloadSize >= 1000 ? (downloadSize / 1000).toFixed(2) + 'GB' : downloadSize.toFixed(2) + 'MB';
  //           let totalSizeValue = totalSize >= 1000 ? (totalSize / 1000).toFixed(2) + 'GB' : totalSize.toFixed(2) + 'MB';
    
  //           this.progressPercentText = downloadSizeValue + ' /' + totalSizeValue;
    
  //         }else if (result.type === HttpEventType.Response) {
  //           let blob: Blob = result.body as Blob;
  //           let a = document.createElement('a');
  //           a.download = "rb_update_new_name.zip";
  //           a.href = window.URL.createObjectURL(blob);
  //           a.click();
  //           setTimeout(() => {
  //             this.progressPercentText = 'Download Completed';
  //             this.isDownloadDisabled=false;

  //           }, 1000);
  //            console.timeEnd("Request time");
    
  //         }

  //     },
  //     error:(error)=>{
  //       this.ProgressMode = 'query';
  //       this.progressPercent=0;
  //       this.progressPercentText='';
  //       this.isDownloadDisabled=false;
  //       this.progressHide=true;
  //       console.timeEnd("answer time");

  //     }
  //   });

      
      
    //   (event: any) => {
      
    //   this.progressHide = false;
    //   // console.log(HttpEventType.DownloadProgress, event.type, HttpEventType.Response)
    
    //   if (event.type === HttpEventType.DownloadProgress) {
       
    //     this.ProgressMode = 'determinate';
    //     this.progressPercent = Math.round(100 * event.loaded / event.total);

    //     let totalSize = event.total / 1000000;
    //     let downloadSize = event.loaded / 1000000;

    //     let downloadSizeValue = downloadSize >= 1000 ? (downloadSize / 1000).toFixed(2) + 'GB' : downloadSize.toFixed(2) + 'MB';
    //     let totalSizeValue = totalSize >= 1000 ? (totalSize / 1000).toFixed(2) + 'GB' : totalSize.toFixed(2) + 'MB';

    //     this.progressPercentText = downloadSizeValue + ' /' + totalSizeValue;

    //   } else if (event.type === HttpEventType.Response) {
    //     let blob: Blob = event.body as Blob;
    //     let a = document.createElement('a');
    //     a.download = "rb_update_new_name.zip";
    //     a.href = window.URL.createObjectURL(blob);
    //     a.click();

    //     setTimeout(() => {
    //       this.progressPercentText = 'Download Completed';

    //     }, 1000);

    //   }
    // });



  // }

  openInstructionsPage() {
    this.bottomSheet.open(UpdateProcedurePageComponent);
  }
}



