import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Da3SoftwareUpdateComponent } from './da3-software-update.component';

describe('Da3SoftwareUpdateComponent', () => {
  let component: Da3SoftwareUpdateComponent;
  let fixture: ComponentFixture<Da3SoftwareUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [Da3SoftwareUpdateComponent]
    });
    fixture = TestBed.createComponent(Da3SoftwareUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
