import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { AuthGuard } from './services/auth.guard.service';
import { MsalGuard } from '@azure/msal-angular';
import { BrowserUtils } from '@azure/msal-browser';

const routes: Routes = [

  {path:'',redirectTo:'site/home',pathMatch:"full"},
  { path: 'site', loadChildren: () => import('./root/sda3.module').then(m => m.Sda3Module),canActivate: [AuthGuard] },
  { path: 'auth', loadChildren: () => import('./root/sda3-auth.module').then(m => m.Sda3AuthModule) },
  { path: 'dealer', loadChildren: () => import('./root/sda3-dealer.module').then(m => m.Sda3DealerModule),canActivate: [MsalGuard]  },
  { path: 'notfound', component: NotFoundComponent },
  {path:"**",redirectTo:'notfound'}

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
      anchorScrolling: 'enabled',
      scrollOffset: [0, 64], // [x, y]
      initialNavigation: !BrowserUtils.isInIframe() && !BrowserUtils.isInPopup() ? 'enabledNonBlocking' : 'disabled' 
    
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
