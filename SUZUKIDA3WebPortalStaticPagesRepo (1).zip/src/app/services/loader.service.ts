import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  private loading:boolean = false;
  private updateSubject = new Subject<void>();

  // Observable to which components can subscribe
  update$ = this.updateSubject.asObservable();

  constructor() { }

  setLoading(loading:boolean){
    this.loading = loading;
  }

  getLoading(){
    return this.loading;
  }

  reloadComponent(){
    this.updateSubject.next();
  }
  
}
