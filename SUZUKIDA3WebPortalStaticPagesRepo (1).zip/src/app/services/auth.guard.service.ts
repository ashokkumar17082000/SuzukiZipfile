import { Injectable } from '@angular/core';
import { ActivatedRoute, CanActivate, Router } from '@angular/router';
import { TempAuthGuardService } from './temp-auth-guard.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private _tempLoginService: TempAuthGuardService,
    private readonly route: ActivatedRoute) {

    }

  canActivate(): boolean {
   
    // Check authentication logic here
    if (!this._tempLoginService.IsUserCodeValidated()) {
        this.router.navigate(['/auth/enter'], { relativeTo: this.route.parent });
        return false;
    }   
      else{
        return true;
      } 
   
  }
}
