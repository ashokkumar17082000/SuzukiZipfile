import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root',
  })
  export class CacheService {
    private cache: { [key: string]: { data: any; timestamp: number } } = {};
  
    set(key: string, value: any, expiresInMilliseconds: number): void {
      const expirationTime = Date.now() + expiresInMilliseconds;
      this.cache[key] = { data: value, timestamp: expirationTime };
    }
  
    get(key: string): any {
      const cachedItem = this.cache[key];
      if (cachedItem && cachedItem.timestamp > Date.now()) {
        return cachedItem.data;
      } else {
        // Clear the cache entry if it has expired
        this.clearKey(key);
        return null;
      }
    }
  
    clear(): void {
      this.cache = {};
    }
    setforhour(key: string, value: any):void{
        const expirationTime = Date.now() + 3600000;
        this.cache[key] = { data: value, timestamp: expirationTime };
    }
  
    private clearKey(key: string): void {
      delete this.cache[key];
    }
  }