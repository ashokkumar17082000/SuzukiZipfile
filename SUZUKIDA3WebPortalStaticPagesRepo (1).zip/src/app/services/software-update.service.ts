import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent, HttpHeaders, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { SoftwareUpdateCallBackResponse, SoftwareUpdatePackageResponse } from '../interfaces/iSoftwareUpdatePackageResponse';

@Injectable({
  providedIn: 'root'
})
export class SoftwareUpdateService {
  private baseUrl = environment.httpsApiUrl;
  constructor(private http: HttpClient) { }
  
  softwareUpdateRequest(file: File): Observable<HttpEvent<any>> {
    const formData: FormData = new FormData();
    formData.append('file', file);
    
    const req = new HttpRequest('POST', `${this.baseUrl}SoftwareUpdate/RequestSoftwareUpdate`, formData, {
      reportProgress: true,
      responseType: 'json'
    });
    return this.http.request(req);
  }

  reportUpdateRequest(file: File): Observable<HttpEvent<any>> {
    const formData: FormData = new FormData();
    formData.append('file', file);
    const req = new HttpRequest('POST', `${this.baseUrl}SoftwareUpdate/ReportUpload`, formData, {
      reportProgress: true,
      responseType: 'json'
    });
    return this.http.request(req);
  }


  uploadFile(file: File): Promise<any> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);

    return this.http.post(this.baseUrl + 'SoftwareUpdate/ReportUpdate', formData).toPromise();
  }
  
  //const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

  // async downloadFile(file: File): Promise<Blob> {
  //   const formData: FormData = new FormData();
  //   formData.append('file', file, file.name);
  //   return this.http.post(this.baseUrl + 'SoftwareUpdate/SoftwareUpdate', formData, { responseType: 'blob', }).toPromise();
  // }

  downloadFileLargeWithName(file: File): Observable<HttpResponse<Blob>> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post(this.baseUrl + 'SoftwareUpdate/SoftwareUpdate', formData, { responseType: 'blob', observe: 'response' });
  }

  async downloadSoftwareAlfaUpdate(file: File): Promise<{ blob: Blob, fileName: string }> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);


    const response = await this.http.post(this.baseUrl + 'SoftwareUpdate/SoftwareUpdate', formData, {
      responseType: 'blob',
      observe: 'response',
      // headers: new HttpHeaders({
      //   'Content-Type': "application/octet-stream",
      // }),
    }).toPromise();
    const contentDispositionHeader = response.headers.get('Content-Disposition');
    const fileNameMatch = /filename="?([^"]+)"?/i.exec(contentDispositionHeader);
    const fileName = fileNameMatch && fileNameMatch[1] ? fileNameMatch[1] : 'SUZUKI_Software_Update_download.zip';

    return { blob: response.body, fileName: fileName };

  }

  async downloadWithArryBuffer(file: File): Promise<ArrayBuffer> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post(this.baseUrl + 'SoftwareUpdate/SoftwareUpdate', formData, { responseType: 'arraybuffer' }).toPromise();
  }

  postBlobData(file: File): Observable<Blob> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post(this.baseUrl + 'SoftwareUpdate/SoftwareUpdate', formData, {
      headers,
      responseType: 'blob',
    }).pipe(
      catchError((error: HttpErrorResponse) => {
        return throwError(() => error);
      })
    );
  }

  public verifyUpdateAvailable(file: File,IsDealer:Boolean): Observable<SoftwareUpdateCallBackResponse> {
    const formData: FormData = new FormData();
    formData.append('file', file, file.name);
    return this.http.post<SoftwareUpdateCallBackResponse>(this.baseUrl + 'Software/CheckSoftwareUpdateAvailable?IsDealer='+IsDealer, formData);
  }

  downloadSoftwareByPackageID(packageID: string): Observable<HttpResponse<Blob>> {
    return this.http.post(this.baseUrl + 'Software/DownloadUpdate?packageID=' + packageID, packageID, { responseType: 'blob', observe: 'response' });
  }

}
