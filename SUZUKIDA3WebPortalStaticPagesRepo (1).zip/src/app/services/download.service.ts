import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { saveAs } from 'file-saver';

@Injectable({providedIn: 'root'})
export class DownloadService {
 
  constructor(private http: HttpClient) {}
 
  downloadFile(fileUrl: string) {
    return this.http.get(fileUrl, { observe:'response', responseType: 'blob' });
  }

}
