import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {

  constructor(private console: Console) { }

  log(message: string): void {
    this.console.log(message);
  }

  error(message: string): void {
    this.console.error(message);
  }

  warn(message: string): void {
    this.console.warn(message);
  }

  info(message: string): void {
    this.console.info(message);
  }
}
