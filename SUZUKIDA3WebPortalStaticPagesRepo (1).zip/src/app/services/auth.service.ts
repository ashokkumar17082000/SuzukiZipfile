import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NotFoundError, Observable, map } from 'rxjs';
import { apiUrls } from 'src/environments/api.urls';
import { JwtHelperService } from '@auth0/angular-jwt';
import {UserProfile} from '../interfaces/iUser'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  jwtHelper=new JwtHelperService();
  private _decryptedData:UserProfile={
    UserId:null,
    Email:null,
    IsActive:null,
    IsAdmin:null,
  };

  constructor(private http: HttpClient) {
    // sessionStorage.clear();
  }

  IsLoggedIn() {  
    return localStorage.getItem('token') != null;
  }

  deCodedToken(){
      
      if(this.jwtHelper.isTokenExpired(localStorage.getItem('token'))){
        this.logout();
        return null;
      }
      this._decryptedData=this.jwtHelper.decodeToken(localStorage.getItem('token'));
      return this._decryptedData;
  }

  isAdminIn() {
    this.deCodedToken();
    return this._decryptedData.IsAdmin == "True";
  }

  AuthenticateUser(userdata: any) {
    return this.http.post(apiUrls._auth.authenticate, userdata).pipe(
      map(response => {
        localStorage.setItem("token", response.valueOf()['token']);
        this._decryptedData=this.jwtHelper.decodeToken(localStorage.getItem('token'));
        localStorage.setItem("IsAdmin",this._decryptedData.IsAdmin);
        localStorage.setItem("UserName",this._decryptedData.UserId);
      })
    )
  }

  logout() {
    // localStorage.removeItem("token");
    localStorage.clear()

  }


}
