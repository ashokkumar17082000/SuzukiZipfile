import { LocalService } from './local.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';

const LOGIN_ATTEMPTS_KEY = 'LGOIN_ATTEMPTS';
const BLOCK_DURATION = 1 * 60 * 60 * 1000;
const TEMP_LOGIN_STATUS="TEMPLOGIN";
@Injectable({
  providedIn: 'root'
})
export class TempAuthGuardService {

  constructor(private router: Router, private readonly route: ActivatedRoute, private _localService: LocalService) {

    this.setupBeforeUnloadListener();
   }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    const isAllowed = this.isUserAllowed();

    if (isAllowed) {
      return true;
    } else {
      // Navigate away or redirect to another route
      this.router.navigate(["entry"]);
      // this.router.navigate(['entry'], { relativeTo: this.route });
      return false;
    }
  }

  private isUserAllowed(): boolean {
    let isValid = this._localService.getBool(TEMP_LOGIN_STATUS);
    return isValid;
  }

public IsUserCodeValidated():boolean{
  let isSessionExpired:boolean  = (sessionStorage.getItem(TEMP_LOGIN_STATUS)&&sessionStorage.getItem(TEMP_LOGIN_STATUS)=="1")?false:true;
return !isSessionExpired&&this.isUserAllowed(); ;
}



  public SetLoginAttemp(attemptCount: number): void {

    const loginAttempts = this.getLoginAttempts() || new ClsLoginAttemptsStore(0, 0);
    let timestamp = new Date().getTime();
    const data: ClsLoginAttemptsStore = new ClsLoginAttemptsStore(attemptCount, timestamp);
    if (attemptCount && attemptCount > 15) {
      this._localService.setObject(LOGIN_ATTEMPTS_KEY, data)
    }


  }
  private getLoginAttempts(): ClsLoginAttemptsStore | null {
    const data: ClsLoginAttemptsStore = this._localService.getObject(LOGIN_ATTEMPTS_KEY) as ClsLoginAttemptsStore;
    return data ? data : null;
  }

  public getIsLoginAttemptInvalid(): boolean {
    let loginAttempts = this.getLoginAttempts() as ClsLoginAttemptsStore;
    if(loginAttempts||'')
    {
      const currentTime = new Date().getTime();
      let durationNotCompleted = currentTime - loginAttempts.timestamp < BLOCK_DURATION;
      return durationNotCompleted;
    }
    return false;
  }

  public clearLoginAttempts():void{

      this._localService.removeData(LOGIN_ATTEMPTS_KEY);
  }
  private setupBeforeUnloadListener(): void {
    window.addEventListener('beforeunload', () => {
      // Perform cleanup operations before the browser is closed
      // For example, clear all data from localStorage
      if(sessionStorage.getItem(TEMP_LOGIN_STATUS)!="1")
      {
        this.clearValidateCodeData();
      }
    });
  }


  private clearValidateCodeData(){

    this._localService.removeData(TEMP_LOGIN_STATUS);

  }



}

class ClsLoginAttemptsStore {
  public attempts: number;
  public timestamp: number;

  constructor(attempts: number, timestamp: number) {
    this.attempts = attempts;
    this.timestamp = timestamp;
  }
}
