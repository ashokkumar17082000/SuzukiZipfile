import { Injectable } from '@angular/core';
// import  *  as CryptoJS from  'crypto-js';
@Injectable({
  providedIn: 'root'
})
export class LocalService {

  constructor() { }

  key='DA3';
  menuItems: { [key: string]: boolean } = {
    'home': true,    
    'manual': true,  
    'device': true,  
    'software': true,   
    'certificate': true,   
    'oss': true,   
    'faq': true  
  };

  
  // public saveData(key: string, value: string) {
  //   localStorage.setItem(key, this.encrypt(value));
  // }

  // public getData(key: string) {
  //   let data = localStorage.getItem(key)
  //   return this.decrypt(data);
  // }
  public removeData(key: string) {
    localStorage.removeItem(key);
  }

  public clearData() {
    localStorage.clear();
  }

  setItem(key: string, value: any) {
    localStorage.setItem(key, value);
  }

  getItem(key: string): any {
    return localStorage.getItem(key);
  }

  setBool(key: string, value: boolean) {
    localStorage.setItem(key, String(value));
  }

  getBool(key: string): boolean {
    return localStorage.getItem(key) === 'true';
  }

  setObject(key: string, value: object) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  getObject(key: string): object {
    return JSON.parse(localStorage.getItem(key));
  }

  setForHour(key:string):void{
    return null;
  }

  setMenuItemVisibility(item: string, isVisible: boolean) {
    this.menuItems[item] = isVisible;
  }

  getMenuItemVisibility(item: string): boolean {
    return this.menuItems[item];
  }


  // private encrypt(txt: string): string {
  //   return CryptoJS.AES.encrypt(txt, this.key).toString();
  // }

  // private decrypt(txtToDecrypt: string) {
  //   return CryptoJS.AES.decrypt(txtToDecrypt, this.key).toString(CryptoJS.enc.Utf8);
  // }
}
