import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService<T>{

  constructor(private http: HttpClient) { }


  getActiveStates(): string[] {
    let data: any = [{
      Value: 'Active',
      DisplayValue: 'Active'
    }, {
      Value: 'Archived',
      DisplayValue: 'In-Active'
    }];
    return data;
  }

  getData<T>(url: string): Observable<T> {
    return this.http.get<T>(url);
  }

  get<T>(url: string): Observable<T> {
    return this.http.get<T>(url);
  }

  post(url: string, data: T): Observable<T> {
    return this.http.post<T>(url, data);
  }

  put(url: string, data: T): Observable<T> {
    return this.http.put<T>(url, data);
  }

  delete<T>(url: string, options?: any): Observable<T> {
    return this.http.delete<T>(url);
  }

  
  download(url: string): Observable<any> {
    return this.http.get(url, {
      reportProgress: true,
      responseType: 'blob',
      observe: 'events'
    })
  }
  
  // getAllLanguages(): Observable<any> {
  //   return this.http.get<any>(this.endPoint + "Language");
  // }
}
