import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})
export class EmailCommunicationService {
  private baseUrl = environment.httpsApiUrl;
  constructor(private http: HttpClient) { }
  public SendEmail(email: string): Observable<any> {
    let url = this.baseUrl + `UserCodeValidation/SendMail?ToMail=`;
    return this.http.post(url + email, null);
    // this.http.post(environment.httpsApiUrl + 'UserCodeValidation/SendMail/', email);
    // const req = new HttpRequest('POST', `${this.baseUrl}UserCodeValidation/SendMail`, email);
    // this.http.post<any>(`${this.baseUrl}UserCodeValidation/SendMail`, email).subscribe(result => {
    //   console.log(result);
    // });

  }
}
