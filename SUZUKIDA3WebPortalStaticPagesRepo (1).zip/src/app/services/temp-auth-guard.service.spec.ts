import { TestBed } from '@angular/core/testing';

import { TempAuthGuardService } from './temp-auth-guard.service';

describe('TempAuthGuardService', () => {
  let service: TempAuthGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TempAuthGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
