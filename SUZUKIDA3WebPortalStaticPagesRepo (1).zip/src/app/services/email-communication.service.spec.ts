import { TestBed } from '@angular/core/testing';

import { EmailCommunicationService } from './email-communication.service';

describe('EmailCommunicationService', () => {
  let service: EmailCommunicationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailCommunicationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
