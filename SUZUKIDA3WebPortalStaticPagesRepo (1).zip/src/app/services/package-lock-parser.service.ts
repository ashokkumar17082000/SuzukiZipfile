import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PackageLockParserService {

  constructor() { }

  parsePackageLock(json: any): string {
    const dependencies = this.extractDependencies(json);
    return this.convertToCSV(dependencies);
  }

  private extractDependencies(json: any): Array<{ name: string, version: string, license: string }> {
    const deps = [];
    const packages = json.packages;
    for (const key in packages) {
      if (packages.hasOwnProperty(key)) {
        const pkg = packages[key];
        if (pkg.version && pkg.license) {
          console.log(pkg)
          for (const dependencie in  pkg['dependencies']) {
            
            deps.push({
              name: dependencie,
              version: pkg['dependencies'][dependencie],
              license: pkg.license
            });
          }
        }
      }
    }
    return deps;
  }

  private convertToCSV(data: Array<{ name: string, version: string, license: string }>): string {
    const headers = 'Name,Version,License\n';
    const rows = data.map(dep => `${dep.name},${dep.version},${dep.license}`).join('\n');
    return headers + rows;
  }
}
