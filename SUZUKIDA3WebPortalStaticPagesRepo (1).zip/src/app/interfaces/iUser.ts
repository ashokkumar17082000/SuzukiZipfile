export interface UserProfile{
    UserId?:string,
    Email?:string,
    IsActive?:string,
    IsAdmin?:string
}