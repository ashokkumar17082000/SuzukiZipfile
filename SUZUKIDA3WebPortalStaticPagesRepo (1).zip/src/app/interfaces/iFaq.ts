export interface FaqModel {
    partitionKey: string;
    languageCode:string;
    faqOrderCode:number;
    question: string;
    answer: string;
    hasContent:boolean;
    content: string;
    entityStatus:number;
}