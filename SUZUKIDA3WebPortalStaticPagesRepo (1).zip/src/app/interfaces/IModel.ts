export interface iModel{
    modeId?:number;
    modelName:string;
    modelCode: string;
    modelGroup:string;
    modelGroupOrder:number;
    entityStatus:number;
    partitionKey:number;
    order:number;
}