
export interface FeatureModel{
    featureGroup?:string,
    featureName?:string,
    languageCode?:string,
    IsActive?:string,
    workedBy?:string
}
