
export interface ManufacturerModel {
    manufacturerName?:string,
    isActive?:string,
    order?:number,
    workedBy?:string
}
