export interface IModelData{
    modelName: string;
    modelCode: string;
    order: number;
    modelGroup: string;
    modelGroupOrder: number;
    ModelID:number;
}