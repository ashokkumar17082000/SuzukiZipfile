
    export class LanguageModel {
        languageCode: string;
        languageDisplayName: string;
        entityStatus:number;
        order:number;
    }

  