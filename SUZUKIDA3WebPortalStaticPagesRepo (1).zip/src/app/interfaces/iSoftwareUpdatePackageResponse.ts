export interface SoftwareUpdatePackageResponse{
    packageID: string;
}

export interface SoftwareUpdateCallBackResponse{
    packageID: string;
    softwareName: string;
    softwareVersion: string;
    downloadUri: string;
    errorCode: string;
    errorMessage: string;
}