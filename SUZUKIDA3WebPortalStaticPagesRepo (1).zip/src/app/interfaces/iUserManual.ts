
export interface iUserManual {
    name: string;
    document: string;
    modified_date: string;
  }