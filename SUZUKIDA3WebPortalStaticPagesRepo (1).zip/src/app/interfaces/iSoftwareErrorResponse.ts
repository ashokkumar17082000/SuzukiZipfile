export enum ErrorCode {
    BadRequest = 400,
    Unauthorized = 401,
    Forbidden = 403,
    NotFound = 404,
    InternalServerError = 500,

    FileNotFound = 550,
    UpdateNotAvailable = 551,
    CorruptedFile = 552,
    ServerAuthFail = 553,
    FetchCredentialsFailed = 559,
    ClientAuthenticationFailed = 560,

    ResponseLoadFailed=590,


    DownloadFailed = 600
}

export interface SoftwaerErrorResponse {
    errorCode: ErrorCode;
    customErrorCode?:string;
    message: string;
}
