import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private _snackBar: MatSnackBar) { }
  message: any = "";

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const localtoken = localStorage.getItem('token');
    request = request.clone({ headers: request.headers.set('Authorization', `Bearer ${localtoken}`) })
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {

        if (error instanceof HttpErrorResponse) {

          if (error.status == 0) {
            this.message = " No response from Server";
          } else if (error.error instanceof ErrorEvent) {
            this.message = error.error.message;
          } else if(error.error instanceof Blob){
            return throwError(() => error);
          }
          else {
            let temperror: string = "";
            if (typeof (error.error) == 'object') {
              const validationErrors = error.error.errors;
              for (let k in validationErrors) {
                temperror = temperror + '\n' + validationErrors[k]
              }
            } else {
              temperror = error.error
            }
            this.message = temperror;
          }
        } else {

          this._snackBar.open('NetWork Error Occured! Please check your connectivity.', 'close', {
            horizontalPosition: "end",
            verticalPosition: "top",
            panelClass: 'app-notification-error',
          });
        }
        return throwError(() => error);
      })
    );
  }


}
