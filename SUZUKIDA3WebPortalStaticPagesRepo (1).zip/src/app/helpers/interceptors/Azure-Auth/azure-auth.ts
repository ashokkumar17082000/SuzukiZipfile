import { MsalService } from '@azure/msal-angular';
import { Injectable, OnInit } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Route, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationResult } from '@azure/msal-browser';

@Injectable({
  providedIn: 'root'
})
export class AzureAuthGuard implements OnInit,CanActivate {

  constructor(private authService: MsalService,private _route:Router) {

  }

  ngOnInit(): void {
    // this.ActivateAccount();
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if (this.authService.instance.getActiveAccount() == null) {
      console.log('not logged in!')
      this.login();
     // this._route.navigate(['/role']);
      return false;
    }else{
      this.ActivateAccount();
    }

    return true;
  }

  ActivateAccount(){
    this.authService.instance.handleRedirectPromise().then( (res: AuthenticationResult | null) => {
      console.log(res)
      if (res != null && res.account != null) {
        this.authService.instance.setActiveAccount(res.account)
      }else{
        const currentAccounts = this.authService.instance.getAllAccounts();
        console.log(currentAccounts);
        if (currentAccounts === null || currentAccounts.length === 0) {
          this.authService.loginRedirect(); // Automatically initiate login if no account is found
        } else {
          this.authService.instance.setActiveAccount(currentAccounts[0]);
        }

      }
    }).catch((error) => {
      console.error(error);
    });
  }

  login() {
      this.authService.loginRedirect();

    //  this.authService.loginPopup()
    //   .subscribe((response: AuthenticationResult) => {
    //     this.authService.instance.setActiveAccount(response.account);
    //   });
  }

}
