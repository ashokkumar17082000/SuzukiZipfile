import { TestBed } from '@angular/core/testing';
import { AzureAuthGuard } from './azure-auth';


describe('MicrosoftLoginGuard', () => {
  let guard: AzureAuthGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(AzureAuthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
