import {
  provideTransloco,
  TranslocoModule
} from '@ngneat/transloco';
import { NgModule } from '@angular/core';
import { TranslocoHttpLoader } from './transloco-loader';
import { environment } from "../environments/environment";

@NgModule({
  exports: [ TranslocoModule ],
  providers: [
      provideTransloco({
        config: {
          availableLangs: ['en', 'hu', 'pl', 'da', 'cs', 'no', 'sv', 'tr', 'gr', 'ru', 'th', 'ja', 'id', 'ar', 'sk', 'ro', 'ua', 'en_gb', 'en_au', 'tw_zh', 'fi', 'sl', 'de', 'he', 'nl_be', 'hr', 'nl', 'fr', 'it', 'es_es', 'es_xl', 'pt'],
          defaultLang: sessionStorage.getItem("current_Lang")==null?'en':sessionStorage.getItem("current_Lang"),
          // Remove this option if your application doesn't support changing language in runtime.
          reRenderOnLangChange: true,
          prodMode: environment.production,
        },
        loader: TranslocoHttpLoader
      }),
  ],
})
export class TranslocoRootModule {}
